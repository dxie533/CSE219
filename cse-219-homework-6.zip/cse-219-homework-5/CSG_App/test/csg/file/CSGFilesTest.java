/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.file;

import csg.CSGApp;
import csg.data.CSGData;
import static csg.file.CSGFiles.JSON_BANNER_SCHOOL_IMAGE;
import static csg.file.CSGFiles.JSON_COLOR;
import static csg.file.CSGFiles.JSON_CRITERIA;
import static csg.file.CSGFiles.JSON_DATE;
import static csg.file.CSGFiles.JSON_DAY;
import static csg.file.CSGFiles.JSON_DAY_AND_TIME;
import static csg.file.CSGFiles.JSON_EMAIL;
import static csg.file.CSGFiles.JSON_ENDING_FRIDAY;
import static csg.file.CSGFiles.JSON_END_HOUR;
import static csg.file.CSGFiles.JSON_END_HOUR_ONLY_HOUR;
import static csg.file.CSGFiles.JSON_EXPORT_DIR;
import static csg.file.CSGFiles.JSON_FILE_NAME;
import static csg.file.CSGFiles.JSON_FIRST_NAME;
import static csg.file.CSGFiles.JSON_INSTRUCTOR;
import static csg.file.CSGFiles.JSON_INSTRUCTOR_HOME;
import static csg.file.CSGFiles.JSON_INSTRUCTOR_NAME;
import static csg.file.CSGFiles.JSON_IN_USE;
import static csg.file.CSGFiles.JSON_LAST_NAME;
import static csg.file.CSGFiles.JSON_LEFT_FOOTER_IMAGE;
import static csg.file.CSGFiles.JSON_LINK;
import static csg.file.CSGFiles.JSON_LOCATION;
import static csg.file.CSGFiles.JSON_NAME;
import static csg.file.CSGFiles.JSON_NAVBAR_TITLE;
import static csg.file.CSGFiles.JSON_NUMBER;
import static csg.file.CSGFiles.JSON_OFFICE_HOURS;
import static csg.file.CSGFiles.JSON_RECITATIONS;
import static csg.file.CSGFiles.JSON_RIGHT_FOOTER_IMAGE;
import static csg.file.CSGFiles.JSON_ROLE;
import static csg.file.CSGFiles.JSON_SCHEDULES;
import static csg.file.CSGFiles.JSON_SCRIPT;
import static csg.file.CSGFiles.JSON_SECTION;
import static csg.file.CSGFiles.JSON_SEMESTER;
import static csg.file.CSGFiles.JSON_SITE_PAGES;
import static csg.file.CSGFiles.JSON_SITE_TEMPLATE_DIR;
import static csg.file.CSGFiles.JSON_STARTING_MONDAY;
import static csg.file.CSGFiles.JSON_START_HOUR;
import static csg.file.CSGFiles.JSON_START_HOUR_ONLY_HOUR;
import static csg.file.CSGFiles.JSON_STUDENTS;
import static csg.file.CSGFiles.JSON_STYLESHEET;
import static csg.file.CSGFiles.JSON_SUBJECT;
import static csg.file.CSGFiles.JSON_TA_ONE;
import static csg.file.CSGFiles.JSON_TA_TWO;
import static csg.file.CSGFiles.JSON_TEAM;
import static csg.file.CSGFiles.JSON_TEAMS;
import static csg.file.CSGFiles.JSON_TEXT_COLOR;
import static csg.file.CSGFiles.JSON_TIME;
import static csg.file.CSGFiles.JSON_TITLE;
import static csg.file.CSGFiles.JSON_TOPIC;
import static csg.file.CSGFiles.JSON_TYPE;
import static csg.file.CSGFiles.JSON_UNDERGRAD;
import static csg.file.CSGFiles.JSON_UNDERGRAD_TAS;
import static csg.file.CSGFiles.JSON_YEAR;
import djf.components.AppDataComponent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author David Xie
 */
public class CSGFilesTest {
    
    public CSGFilesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of loadData method, of class CSGFiles.
     */
    @Test
    public void testLoadDataOne() throws Exception {
        File newFile = new File(System.getProperty("user.dir"));
        File fromFile = new File(newFile.getParentFile() + File.separator + "CSG_App" + File.separator + "work" + File.separator + "SiteSaveTest");
        //LOAD JSON FILE
        InputStream is = new FileInputStream(fromFile);
	JsonReader jsonReader = Json.createReader(is);
	JsonObject json = jsonReader.readObject();
	jsonReader.close();
	is.close();
        //TEST
        testVariables(json);
        testPages(json);
        testTAs(json);
        testOfficeHours(json);
        testRecitations(json);
        testSchedules(json);
        testTeams(json);
        testStudents(json);
    }
    public void testVariables(JsonObject json) throws Exception {
        assertEquals("9", json.getString(JSON_START_HOUR));
        assertEquals("20", json.getString(JSON_END_HOUR));
        assertTrue(json.getBoolean(JSON_START_HOUR_ONLY_HOUR));
        assertTrue(json.getBoolean(JSON_END_HOUR_ONLY_HOUR));
        assertEquals("CSE", json.getString(JSON_SUBJECT));
        assertEquals("Fall", json.getString(JSON_SEMESTER));
        assertEquals(219, json.getInt(JSON_NUMBER));
        assertEquals(2017, json.getInt(JSON_YEAR));
        assertEquals("CSE 219 - Java", json.getString(JSON_TITLE));
        assertEquals("Richard McKenna", json.getString(JSON_INSTRUCTOR_NAME));
        assertEquals("http://www3.cs.stonybrook.edu/~cse219/Section02/syllabus.html", json.getString(JSON_INSTRUCTOR_HOME));
        assertEquals("ExportDirString", json.getString(JSON_EXPORT_DIR));
        assertEquals("SiteTemplateDirString", json.getString(JSON_SITE_TEMPLATE_DIR));
        assertEquals("./work/brands/SBUDarkRedShieldLogo.png", json.getString(JSON_BANNER_SCHOOL_IMAGE));
        assertEquals("./work/brands/SBUWhiteShieldLogo.jpg", json.getString(JSON_LEFT_FOOTER_IMAGE));
        assertEquals("./work/brands/CSLogo.png", json.getString(JSON_RIGHT_FOOTER_IMAGE));
        assertEquals("sea_wolf", json.getString(JSON_STYLESHEET));
        assertEquals("04/10/2017", json.getString(JSON_STARTING_MONDAY));
        assertEquals("04/14/2017", json.getString(JSON_ENDING_FRIDAY));
    }
    
    public void testPages(JsonObject json) throws Exception {
        JsonArray jsonPagesArray = json.getJsonArray(JSON_SITE_PAGES);
        assertTrue(jsonPagesArray.getJsonObject(0).getBoolean(JSON_IN_USE));
        assertEquals("Home", jsonPagesArray.getJsonObject(0).getString(JSON_NAVBAR_TITLE));
        assertEquals("index.html", jsonPagesArray.getJsonObject(0).getString(JSON_FILE_NAME));
        assertEquals("HomeBuilder.js", jsonPagesArray.getJsonObject(0).getString(JSON_SCRIPT));
        assertTrue(jsonPagesArray.getJsonObject(1).getBoolean(JSON_IN_USE));
        assertEquals("Syllabus", jsonPagesArray.getJsonObject(1).getString(JSON_NAVBAR_TITLE));
        assertEquals("syllabus.html", jsonPagesArray.getJsonObject(1).getString(JSON_FILE_NAME));
        assertEquals("SyllabusBuilder.js", jsonPagesArray.getJsonObject(1).getString(JSON_SCRIPT));
        assertTrue(jsonPagesArray.getJsonObject(2).getBoolean(JSON_IN_USE));
        assertEquals("Schedule", jsonPagesArray.getJsonObject(2).getString(JSON_NAVBAR_TITLE));
        assertEquals("schedule.html", jsonPagesArray.getJsonObject(2).getString(JSON_FILE_NAME));
        assertEquals("ScheduleBuilder.js", jsonPagesArray.getJsonObject(2).getString(JSON_SCRIPT));
        assertTrue(jsonPagesArray.getJsonObject(3).getBoolean(JSON_IN_USE));
        assertEquals("HWs", jsonPagesArray.getJsonObject(3).getString(JSON_NAVBAR_TITLE));
        assertEquals("hws.html", jsonPagesArray.getJsonObject(3).getString(JSON_FILE_NAME));
        assertEquals("HWsBuilder.js", jsonPagesArray.getJsonObject(3).getString(JSON_SCRIPT));
        assertTrue(jsonPagesArray.getJsonObject(4).getBoolean(JSON_IN_USE));
        assertEquals("Projects", jsonPagesArray.getJsonObject(4).getString(JSON_NAVBAR_TITLE));
        assertEquals("projects.html", jsonPagesArray.getJsonObject(4).getString(JSON_FILE_NAME));
        assertEquals("ProjectsBuilder.js", jsonPagesArray.getJsonObject(4).getString(JSON_SCRIPT));
    }
    
    public void testTAs(JsonObject json) throws Exception {
        JsonArray jsonTAArray = json.getJsonArray(JSON_UNDERGRAD_TAS);
        assertEquals("Daniel", jsonTAArray.getJsonObject(0).getString(JSON_NAME));
        assertEquals("Daniel@gmail.com", jsonTAArray.getJsonObject(0).getString(JSON_EMAIL));
        assertFalse(jsonTAArray.getJsonObject(0).getBoolean(JSON_UNDERGRAD));
        assertEquals("John", jsonTAArray.getJsonObject(1).getString(JSON_NAME));
        assertEquals("John@Stonybrook.edu", jsonTAArray.getJsonObject(1).getString(JSON_EMAIL));
        assertTrue(jsonTAArray.getJsonObject(1).getBoolean(JSON_UNDERGRAD));
    }
    
    public void testOfficeHours(JsonObject json) throws Exception {
        JsonArray jsonOfficeArray = json.getJsonArray(JSON_OFFICE_HOURS);
        assertEquals("TUESDAY", jsonOfficeArray.getJsonObject(0).getString(JSON_DAY));
        assertEquals("9_00am", jsonOfficeArray.getJsonObject(0).getString(JSON_TIME));
        assertEquals("Daniel", jsonOfficeArray.getJsonObject(0).getString(JSON_NAME));
        assertEquals("THURSDAY", jsonOfficeArray.getJsonObject(1).getString(JSON_DAY));
        assertEquals("5_00pm", jsonOfficeArray.getJsonObject(1).getString(JSON_TIME));
        assertEquals("John", jsonOfficeArray.getJsonObject(1).getString(JSON_NAME));
    }
    
    public void testRecitations(JsonObject json) throws Exception {
        JsonArray jsonRecitationArray = json.getJsonArray(JSON_RECITATIONS);
        assertEquals("section", jsonRecitationArray.getJsonObject(0).getString(JSON_SECTION));
        assertEquals("instrutor", jsonRecitationArray.getJsonObject(0).getString(JSON_INSTRUCTOR));
        assertEquals("dayandtime", jsonRecitationArray.getJsonObject(0).getString(JSON_DAY_AND_TIME));
        assertEquals("location", jsonRecitationArray.getJsonObject(0).getString(JSON_LOCATION));
        assertEquals("ta1", jsonRecitationArray.getJsonObject(0).getString(JSON_TA_ONE));
        assertEquals("ta2", jsonRecitationArray.getJsonObject(0).getString(JSON_TA_TWO));
        assertEquals("sectionz", jsonRecitationArray.getJsonObject(1).getString(JSON_SECTION));
        assertEquals("instrutorz", jsonRecitationArray.getJsonObject(1).getString(JSON_INSTRUCTOR));
        assertEquals("dayandtimez", jsonRecitationArray.getJsonObject(1).getString(JSON_DAY_AND_TIME));
        assertEquals("location", jsonRecitationArray.getJsonObject(1).getString(JSON_LOCATION));
        assertEquals("taz1", jsonRecitationArray.getJsonObject(1).getString(JSON_TA_ONE));
        assertEquals("taz2", jsonRecitationArray.getJsonObject(1).getString(JSON_TA_TWO));
    }
    
    public void testSchedules(JsonObject json) throws Exception {
        JsonArray jsonScheduleArray = json.getJsonArray(JSON_SCHEDULES);
        assertEquals("Holiday", jsonScheduleArray.getJsonObject(0).getString(JSON_TYPE));
        assertEquals("04/11/2017", jsonScheduleArray.getJsonObject(0).getString(JSON_DATE));
        assertEquals("3:30 - 4:00", jsonScheduleArray.getJsonObject(0).getString(JSON_TIME));
        assertEquals("SNOW DAY", jsonScheduleArray.getJsonObject(0).getString(JSON_TITLE));
        assertEquals("Nice Topic", jsonScheduleArray.getJsonObject(0).getString(JSON_TOPIC));
        assertEquals("Nice Link", jsonScheduleArray.getJsonObject(0).getString(JSON_LINK));
        assertEquals("Nice Criteria", jsonScheduleArray.getJsonObject(0).getString(JSON_CRITERIA));
        assertEquals("Homework", jsonScheduleArray.getJsonObject(1).getString(JSON_TYPE));
        assertEquals("04/14/2017", jsonScheduleArray.getJsonObject(1).getString(JSON_DATE));
        assertEquals("3:00 - 4:00", jsonScheduleArray.getJsonObject(1).getString(JSON_TIME));
        assertEquals("Homework", jsonScheduleArray.getJsonObject(1).getString(JSON_TITLE));
        assertEquals("Cool Topic", jsonScheduleArray.getJsonObject(1).getString(JSON_TOPIC));
        assertEquals("Cool Link", jsonScheduleArray.getJsonObject(1).getString(JSON_LINK));
        assertEquals("Cool Criteria", jsonScheduleArray.getJsonObject(1).getString(JSON_CRITERIA));
    }
    
    public void testTeams(JsonObject json) throws Exception {
        JsonArray jsonTeamArray = json.getJsonArray(JSON_TEAMS);
        assertEquals("Teal", jsonTeamArray.getJsonObject(0).getString(JSON_NAME));
        assertEquals("#008080", jsonTeamArray.getJsonObject(0).getString(JSON_COLOR));
        assertEquals("#000000", jsonTeamArray.getJsonObject(0).getString(JSON_TEXT_COLOR));
        assertEquals("link", jsonTeamArray.getJsonObject(0).getString(JSON_LINK));
        assertEquals("White", jsonTeamArray.getJsonObject(1).getString(JSON_NAME));
        assertEquals("#FFFFFF", jsonTeamArray.getJsonObject(1).getString(JSON_COLOR));
        assertEquals("#000000", jsonTeamArray.getJsonObject(1).getString(JSON_TEXT_COLOR));
        assertEquals("link2", jsonTeamArray.getJsonObject(1).getString(JSON_LINK));
    }
    
    public void testStudents(JsonObject json) throws Exception {
        JsonArray jsonStudentArray = json.getJsonArray(JSON_STUDENTS);
        assertEquals("Raymond", jsonStudentArray.getJsonObject(0).getString(JSON_FIRST_NAME));
        assertEquals("Xue", jsonStudentArray.getJsonObject(0).getString(JSON_LAST_NAME));
        assertEquals("Teal", jsonStudentArray.getJsonObject(0).getString(JSON_TEAM));
        assertEquals("Lead Programmer", jsonStudentArray.getJsonObject(0).getString(JSON_ROLE));
        assertEquals("Karl", jsonStudentArray.getJsonObject(1).getString(JSON_FIRST_NAME));
        assertEquals("Jean Brice", jsonStudentArray.getJsonObject(1).getString(JSON_LAST_NAME));
        assertEquals("Teal", jsonStudentArray.getJsonObject(1).getString(JSON_TEAM));
        assertEquals("Project Manager", jsonStudentArray.getJsonObject(1).getString(JSON_ROLE));
        assertEquals("Eric", jsonStudentArray.getJsonObject(2).getString(JSON_FIRST_NAME));
        assertEquals("Li", jsonStudentArray.getJsonObject(2).getString(JSON_LAST_NAME));
        assertEquals("Teal", jsonStudentArray.getJsonObject(2).getString(JSON_TEAM));
        assertEquals("Lead Designer", jsonStudentArray.getJsonObject(2).getString(JSON_ROLE));
        assertEquals("Xiangbin", jsonStudentArray.getJsonObject(3).getString(JSON_FIRST_NAME));
        assertEquals("Zeng", jsonStudentArray.getJsonObject(3).getString(JSON_LAST_NAME));
        assertEquals("Teal", jsonStudentArray.getJsonObject(3).getString(JSON_TEAM));
        assertEquals("Data Designer", jsonStudentArray.getJsonObject(3).getString(JSON_ROLE));
        assertEquals("Lee", jsonStudentArray.getJsonObject(4).getString(JSON_FIRST_NAME));
        assertEquals("Aaron", jsonStudentArray.getJsonObject(4).getString(JSON_LAST_NAME));
        assertEquals("White", jsonStudentArray.getJsonObject(4).getString(JSON_TEAM));
        assertEquals("Lead Programmer", jsonStudentArray.getJsonObject(4).getString(JSON_ROLE));
        assertEquals("Kamin", jsonStudentArray.getJsonObject(5).getString(JSON_FIRST_NAME));
        assertEquals("Punjarojanakul", jsonStudentArray.getJsonObject(5).getString(JSON_LAST_NAME));
        assertEquals("White", jsonStudentArray.getJsonObject(5).getString(JSON_TEAM));
        assertEquals("Project Manager", jsonStudentArray.getJsonObject(5).getString(JSON_ROLE));
        assertEquals("Wilson", jsonStudentArray.getJsonObject(6).getString(JSON_FIRST_NAME));
        assertEquals("Tang", jsonStudentArray.getJsonObject(6).getString(JSON_LAST_NAME));
        assertEquals("White", jsonStudentArray.getJsonObject(6).getString(JSON_TEAM));
        assertEquals("Lead Designer", jsonStudentArray.getJsonObject(6).getString(JSON_ROLE));
        assertEquals("David", jsonStudentArray.getJsonObject(7).getString(JSON_FIRST_NAME));
        assertEquals("Lin", jsonStudentArray.getJsonObject(7).getString(JSON_LAST_NAME));
        assertEquals("White", jsonStudentArray.getJsonObject(7).getString(JSON_TEAM));
        assertEquals("Data Designer", jsonStudentArray.getJsonObject(7).getString(JSON_ROLE));
    }
}
