/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TATransactions;

import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class AddToTA_UpdateTransaction implements jTPS_Transaction{
 
    //CURRENT STUFF
    private TAUpdateState currentTAState;
    //VALUES BEFORE
    String previousName;
    String previousEmail;
    //VALUES AFTER
    String futureName;
    String futureEmail;
    
    public AddToTA_UpdateTransaction(TAUpdateState taState, String nameToBe, String emailToBe)
    {
        currentTAState = taState;
        previousName = taState.getCurrentName();
        previousEmail = taState.getCurrentEmail();
        futureName = nameToBe;
        futureEmail = emailToBe;
    }
    
    public void doTransaction()
    {
        currentTAState.setName(futureName);
        currentTAState.setEmail(futureEmail);
    }
    
    public void undoTransaction()
    {
        currentTAState.setName(previousName);
        currentTAState.setEmail(previousEmail);
    }
}
