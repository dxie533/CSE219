/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TATransactions;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jtps.jTPS_Transaction;
import csg.data.TeachingAssistant;
import csg.file.TimeSlot;

/**
 *
 * @author David Xie
 */
public class AddToTA_Transaction implements jTPS_Transaction {
    //CURRENT STUFF
    private WorkState CurrentState;
    //VALUES BEFORE
    int previousStartTime;
    int previousEndTime;
    boolean previousStartHourOnly;
    boolean previousEndHourOnly;
    ObservableList<TeachingAssistant> previousTeachingAssistances;
    ArrayList<TimeSlot> previousReservations;
    
    //VALUES AFTER
    int newStartTime;
    int newEndTime;
    boolean newStartHourOnly;
    boolean newEndHourOnly;
    ObservableList<TeachingAssistant> newTeachingAssistances;
    ArrayList<TimeSlot> newReservations;
    
    public AddToTA_Transaction(WorkState state, int newStart, int newEnd, boolean newStartHour, boolean newEndHour, ObservableList<TeachingAssistant> newTAs, ArrayList<TimeSlot> newRes) {
    //SET STATE
    CurrentState = state;
    
    //SET PREVIOUS VALUES TO STATE
    previousStartTime = state.getStartTime();
    previousEndTime = state.getEndTime();
    previousStartHourOnly = state.getStartHourOnly();
    previousEndHourOnly = state.getEndHourOnly();
    previousTeachingAssistances = FXCollections.observableArrayList();
    for(int i = 0; i < state.getTeachingAssistances().size(); i++)
    {
        previousTeachingAssistances.add(state.getTeachingAssistances().get(i));
    }
    previousReservations = state.getReservations();
    
    //SET NEW VALUES
    newStartTime = newStart;
    newEndTime = newEnd;
    newStartHourOnly = newStartHour;
    newEndHourOnly = newEndHour;
    newTeachingAssistances = FXCollections.observableArrayList();
    for(int i = 0; i < newTAs.size(); i++)
    {
        newTeachingAssistances.add(newTAs.get(i));
    }
    newReservations = newRes;
    }

    @Override
    public void doTransaction() {        
        //SET CURRENT STATE TO THE NEW VALUES
        CurrentState.setStartTime(newStartTime);
        CurrentState.setEndTime(newEndTime);
        CurrentState.setStartHourOnly(newStartHourOnly);
        CurrentState.setEndHourOnly(newEndHourOnly);
        CurrentState.setTeachingAssistances(newTeachingAssistances);
        CurrentState.setReservations(newReservations);
    }

    @Override
    public void undoTransaction() {
        //SET CURRENT STATE TO THE OLD VALUES
        CurrentState.setStartTime(previousStartTime);
        CurrentState.setEndTime(previousEndTime);
        CurrentState.setStartHourOnly(previousStartHourOnly);
        CurrentState.setEndHourOnly(previousEndHourOnly);
        CurrentState.setTeachingAssistances(previousTeachingAssistances);
        CurrentState.setReservations(previousReservations);

    }
    
    /*SCREW THESE STRINGS
    @Override
    public String toString() {
        return "Add " + amountToAdd;
    }
*/
}
