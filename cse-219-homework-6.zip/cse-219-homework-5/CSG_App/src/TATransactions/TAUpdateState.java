/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TATransactions;

import csg.data.TeachingAssistant;

/**
 *
 * @author David Xie
 */
public class TAUpdateState {
    private TeachingAssistant theAssistant;
    private String currentName;
    private String currentEmail;
    
    public TAUpdateState(TeachingAssistant assistant, String nameNow, String emailNow)
    {
        theAssistant = assistant;
        currentName = nameNow;
        currentEmail = emailNow;
    }
    
    public TeachingAssistant getCurrentTa()
    {
        return theAssistant;
    }
    
    public String getCurrentName()
    {
        return currentName;
    }
    
    public String getCurrentEmail()
    {
        return currentEmail;
    }
    
    public void setTa(TeachingAssistant newAssistant)
    {
        theAssistant = newAssistant;
    }
    
    public void setName(String taName)
    {
        currentName = taName;
    }
    
    public void setEmail(String taEmail)
    {
        currentEmail = taEmail;
    }
}
