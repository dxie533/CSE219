/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TATransactions;

import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import csg.data.TeachingAssistant;
import csg.file.TimeSlot;

/**
 *
 * @author David Xie
 */
public class WorkState {
    //ALL THE VARIABLES/DATA FOR THE WORKPLACE
    private int startTime;
    private int endTime;
    private boolean startHourOnly;
    private boolean endHourOnly;
    private ObservableList<TeachingAssistant> TeachingAssistances;
    private ArrayList<TimeSlot> Reservations;
    
    public WorkState(int startingTime, int endingTime, boolean startingHour, boolean endingHour, ObservableList<TeachingAssistant> teaching, ArrayList<TimeSlot> reserved)
    {
        startTime = startingTime;
        endTime = endingTime;
        startHourOnly = startingHour;
        endHourOnly = endingHour;
        TeachingAssistances = FXCollections.observableArrayList();
        for(int i = 0; i < teaching.size(); i++)
        {
            TeachingAssistances.add(teaching.get(i));
        }
        Reservations = reserved;
    }
    
    public int getStartTime()
    {
        return startTime;
    }
    
    public int getEndTime()
    {
        return endTime;
    }
    
    public boolean getStartHourOnly()
    {
        return startHourOnly;
    }
    
    public boolean getEndHourOnly()
    {
        return endHourOnly;
    }
    
    public ObservableList<TeachingAssistant> getTeachingAssistances()
    {
        return TeachingAssistances;
    }
    
    public ArrayList<TimeSlot> getReservations()
    {
        return Reservations;
    }
    
    public void setStartTime(int currentStartTime)
    {
        startTime = currentStartTime;
    }
    
    public void setEndTime(int currentEndTime)
    {
        endTime = currentEndTime;
    }
    
    public void setStartHourOnly(boolean currentStartHourOnly)
    {
        startHourOnly = currentStartHourOnly;
    }
    
    public void setEndHourOnly(boolean currentEndHourOnly)
    {
        endHourOnly = currentEndHourOnly;
    }
    
    public void setTeachingAssistances(ObservableList<TeachingAssistant> currentTeachingAssistances)
    {
        TeachingAssistances = currentTeachingAssistances;
    }
    
    public void setReservations(ArrayList<TimeSlot> currentReservations)
    {
        Reservations = currentReservations;
    }
}
