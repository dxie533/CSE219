package csg.workspace;

import djf.components.AppDataComponent;
import djf.components.AppWorkspaceComponent;
import static djf.settings.AppPropertyType.COMBO_BOX_MESSAGE;
import static djf.settings.AppPropertyType.COMBO_BOX_TITLE;
import djf.ui.AppYesNoCancelDialogSingleton;
import java.util.ArrayList;
import java.util.HashMap;
import javafx.beans.property.StringProperty;
import csg.CSGApp;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import properties_manager.PropertiesManager;
import csg.CSGProp;
import csg.style.CSGStyle;
import csg.data.CSGData;
import csg.data.Page;
import csg.data.Recitation;
import csg.data.Schedule;
import csg.data.Student;
import csg.data.TeachingAssistant;
import csg.data.Team;
import csg.file.TimeSlot;
import static djf.settings.AppPropertyType.APP_LOGO;
import static djf.settings.AppStartupConstants.FILE_PROTOCOL;
import static djf.settings.AppStartupConstants.PATH_IMAGES;
import static djf.settings.AppStartupConstants.PATH_WORK;
import java.io.File;
import java.net.MalformedURLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventType;
import javafx.geometry.Orientation;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.scene.paint.Color;


/**
 * This class serves as the workspace component for the TA Manager
 * application. It provides all the user interface controls in 
 * the workspace area.
 * 
 * @author Richard McKenna
 */
public class CSGWorkspace extends AppWorkspaceComponent {
    // THIS PROVIDES US WITH ACCESS TO THE APP COMPONENTS
    CSGApp app;

    // THIS PROVIDES RESPONSES TO INTERACTIONS WITH THIS WORKSPACE
    CSGController controller;

    //TAB PANE
    TabPane tabPane;
    
    //TABS
    Tab courseTab;
    Tab taTab;
    Tab recitationTab;
    Tab scheduleTab;
    Tab projectTab;
    
    //--COURSE DETAILS TAB--//
    //
    
    //THE CONTAINERS
    FlowPane courseDetailsBox;
    GridPane courseInfoPane;
    VBox siteTemplateBox;
    GridPane pageStylePane;
    
    //COURSE INFO SECTION//
    //LABELS
    Label courseInfoLabel;
    HBox courseInfoLabelBox;
    Label courseSubjectLabel;
    HBox courseSubjectLabelBox;
    Label courseNumberLabel;
    HBox courseNumberLabelBox;
    Label courseSemesterLabel;
    HBox courseSemesterLabelBox;
    Label courseYearLabel;
    HBox courseYearLabelBox;
    Label courseTitleLabel;
    HBox courseTitleLabelBox;
    Label courseInstructorNameLabel;
    HBox courseInstructorNameLabelBox;
    Label courseHomeLabel;
    HBox courseHomeLabelBox;
    Label courseExportDirLabel;
    HBox courseExportDirLabelBox;
    Label courseExportDirFileLabel;
    HBox courseExportDirFileLabelBox;
    //COMBOBOXES
    ComboBox courseSubjectComboBox;
    ComboBox courseNumberComboBox;
    ComboBox courseSemesterComboBox;
    ComboBox courseYearComboBox;
    //TEXTFIELDS
    TextField courseTitleField;
    TextField courseInstructorNameField;
    TextField courseInstructorHomeField;
    //BUTTONS
    Button courseChangeExportDirButton;
    
    //SITE TEMPLATE SECTION//
    Label courseSiteTemplateLabel;
    HBox courseSiteTemplateLabelBox;
    Label courseSiteTemplateTextLabel;
    HBox courseSiteTemplateTextLabelBox;
    Label courseSiteTemplateDirectoryLocationLabel;
    HBox courseSiteTemplateDirectoryLocationLabelBox;
    Label courseSitePagesLabel;
    HBox courseSitePagesLabelBox;
    //BUTTONS
    Button courseSelectTemplateButton;
    //FOR THE SITEPAGE TABLE
    TableView<Page> sitePageTable;
    TableColumn<Page, String> navbarTitleColumn;
    TableColumn<Page, String> fileNameColumn;
    TableColumn<Page, String> scriptNameColumn;
    TableColumn isUsedColumn;
    
    //PAGE STYLE SECTION//
    //STRING
    String courseExportDirFileText;
    
    //LABELS
    Label coursePageStyleLabel;
    HBox coursePageStyleLabelBox;
    Label courseBannerSchoolImageLabel;
    HBox courseBannerSchoolImageLabelBox;
    Label courseLeftFooterImageLabel;
    HBox courseLeftFooterImageLabelBox;
    Label courseRightFooterImageLabel;
    HBox courseRightFooterImageLabelBox;
    Label courseStylesheetLabel;
    HBox courseStylesheetLabelBox;
    Label courseNoteLabel;
    HBox courseNoteLabelBox;
    
    //IMAGES
    ImageView bannerImageView;
    ImageView bannerLeftImageView;
    ImageView bannerRightImageView;
    
    //BUTTONS
    Button courseChangeBannerButton;
    Button courseChangeLeftFooterButton;
    Button courseChangeRightFooterButton;
    
    //COMBOBOXES
    ComboBox courseStyleSheetComboBox;
    
    //--RECITATION DATA TAB--//

    
    //THE CONTAINERS
    VBox recitationDataPane;
    Pane recitationAddEditPane;
    GridPane reciationAddEditFieldsPane;
    
    //THE LABELS
    Label recitationHeaderLabel;
    HBox recitationHeaderLabelBox;
    Label recitationAddEditHeaderLabel;
    HBox recitationAddEditHeaderLabelBox;
    Label recitationSectionLabel;
    HBox recitationSectionLabelBox;
    Label recitationInstructorLabel;
    HBox recitationInstructorLabelBox;
    Label recitationDayTimeLabel;
    HBox recitationDayTimeLabelBox;
    Label recitationLocationLabel;
    HBox recitationLocationLabelBox;
    Label recitationSupervisingTaLabel;
    HBox recitationSupervisingTaLabelBox1;
    Label recitationSupervisingTaLabel2;
    HBox recitationSupervisingTaLabelBox2;
    
    //THE TEXTFIELDS
    TextField recitationSectionField;
    TextField recitationInstructorField;
    TextField recitationDayTimeField;
    TextField recitationLocationField;
    
    //THE COMBOBOXES
    ComboBox recitationTA1;
    ComboBox recitationTA2;
    
    //THE BUTTONS
    Button recitationAddUpdateButton;
    Button recitationClearButton;
    Button recitationDeleteButton;
    
    //THE TABLE
    TableView<Recitation> recitationTable;
    TableColumn<Recitation, String> recitationSectionColumn;
    TableColumn<Recitation, String> reciationInstructorColumn;
    TableColumn<Recitation, String> recitationDayTimeColumn;
    TableColumn<Recitation, String> recitationLocationColumn;
    TableColumn<Recitation, String> recitationTAOneColumn;
    TableColumn<Recitation, String> recitationTATwoColumn;
    
    //--SCHEDULE TAB--//
    VBox scheduleBox;
    VBox scheduleTopBox;
    HBox scheduleTopBoxHorizontal;
    VBox scheduleItemsBox;
    GridPane scheduleInputPane;
    
    //THE LABELS
    Label scheduleHeaderLabel;
    HBox scheduleHeaderLabelBox;
    Label scheduleCalendarBoundariesLabel;
    HBox scheduleCalendarBoundariesLabelBox;
    Label scheduleStartingMondayLabel;
    HBox scheduleStartingMondayLabelBox;
    Label scheduleEndingFridayLabel;
    HBox scheduleEndingFridayLabelBox;
    Label scheduleItemsLabel;
    HBox scheduleItemsLabelBox;
    Label scheduleAddAndEditLabel;
    HBox scheduleAddAndEditLabelBox;
    Label scheduleTypeLabel;
    HBox scheduleTypeLabelBox;
    Label scheduleDateLabel;
    HBox scheduleDateLabelBox;
    Label scheduleTimeLabel;
    HBox scheduleTimeLabelBox;
    Label scheduleTitleLabel;
    HBox scheduleTitleLabelBox;
    Label scheduleTopicLabel;
    HBox scheduleTopicLabelBox;
    Label scheduleLinkLabel;
    HBox scheduleLinkLabelBox;
    Label scheduleCriteriaLabel;
    HBox scheduleCriteriaLabelBox;
    
    //THE TEXTFIELDS
    TextField scheduleTimeField;
    TextField scheduleTitleField;
    TextField scheduleTopicField;
    TextField scheduleLinkField;
    TextField scheduleCriteriaField;
    
    //OOMBOBOXES
    ComboBox scheduleTypeComboBox;
    
    //DATEPICKER
    DatePicker startingMonday;
    DatePicker endingFriday;
    DatePicker scheduleDateDatePicker;
    
    //BUTTONS
    Button scheduleAddUpdateButton;
    Button scheduleClearButton;
    Button scheduleDeleteButton;
    
    //THE SCHEDULE TABLE
    TableView<Schedule> scheduleTable;
    TableColumn<Schedule, String> scheduleTypeColumn;
    TableColumn<Schedule, LocalDate> scheduleDateColumn;
    TableColumn<Schedule, String> scheduleTitleColumn;
    TableColumn<Schedule, String> scheduleTopicColumn;
    
        //--PROJECTS--//
    
        //PANES
        VBox projectBox;
        VBox projectTeamsBox;
        GridPane projectTeamInputPane;
        VBox projectStudentsBox;
        GridPane projectStudentInputBox;
        
        //LABELS
        Label projectHeaderLabel;
        HBox projectHeaderLabelBox;
        Label projectTeamHeaderLabel;
        HBox projectTeamHeaderLabelBox;
        Label projectAddEditLabel;
        HBox projectAddEditLabelBox;
        Label projectNameLabel;
        HBox projectNameLabelBox;
        Label projectColorLabel;
        HBox projectColorLabelBox;
        Label projectLinkLabel;
        HBox projectLinkLabelBox;
        Label projectTextColorLabel;
        HBox projectTextColorLabelBox;
        Label projectStudentHeaderLabel;
        HBox projectStudentHeaderLabelBox;
        Label projectStudentAddEditLabel;
        HBox projectStudentAddEditLabelBox;
        Label projectFirstNameLabel;
        HBox projectFirstNameLabelBox;
        Label projectLastNameLabel;
        HBox projectLastNameLabelBox;
        Label projectTeamLabel;
        HBox projectTeamLabelBox;
        Label projectRoleLabel;
        HBox projectRoleLabelBox;

        //TEXTFIELDS
        TextField projectTeamNameField;
        TextField projectTeamLinkField;
        TextField projectStudentFirstNameField;
        TextField projectStudentLastNameField;
        TextField projectStudentRoleField;

        //BUTTONS
        Button projectTeamAddAndUpdateButton;
        Button projectTeamClearButton;
        Button projectStudentAddAndUpdateButton;
        Button projectStudentClearButton;
        Button projectTeamDeleteButton;
        Button projectStudentDeleteButton;

        //COMBOBOX
        ComboBox projectStudentTeamComboBox;

        //COLORPICKERS
        ColorPicker projectTeamColorPicker;
        ColorPicker projectTeamTextColorPicker;

        //TABLES
        TableView<Team> teamTable;
        TableColumn<Team, String> teamNameColumn;
        TableColumn<Team, Color> teamColorColumn;
        TableColumn<Team, Color> teamTextColorColumn;
        TableColumn<Team, String> teamLinkColumn;

        TableView<Student> studentTable;
        TableColumn<Student, String> studentFirstNameColumn;
        TableColumn<Student, String> studentLastNameColumn;
        TableColumn<Student, String> studentTeamColumn;
        TableColumn<Student, String> studentRoleColumn;
        
    //--TA DATA TAB--//
    //
    // FOR THE HEADER ON THE LEFT
    HBox tasHeaderBox;
    Label tasHeaderLabel;
    
    // FOR THE TA TABLE
    TableView<TeachingAssistant> taTable;
    TableColumn<TeachingAssistant, String> nameColumn;
    TableColumn<TeachingAssistant, String> emailColumn;
    TableColumn isUndergradColumn;
    
    // THE TA INPUT
    HBox addBox;
    TextField nameTextField;
    TextField emailTextField;
    Button addButton;
    Button clearButton;
    Button taDeleteButton;

    // THE HEADER ON THE RIGHT
    HBox officeHoursHeaderBox;
    Label officeHoursHeaderLabel;
    HBox officeHoursStartLabelBox;
    Label officeHoursStartLabel;
    HBox officeHoursEndLabelBox;
    Label officeHoursEndLabel;
    
    // THE OFFICE HOURS GRID
    GridPane officeHoursGridPane;
    HashMap<String, Pane> officeHoursGridTimeHeaderPanes;
    HashMap<String, Label> officeHoursGridTimeHeaderLabels;
    HashMap<String, Pane> officeHoursGridDayHeaderPanes;
    HashMap<String, Label> officeHoursGridDayHeaderLabels;
    HashMap<String, Pane> officeHoursGridTimeCellPanes;
    HashMap<String, Label> officeHoursGridTimeCellLabels;
    HashMap<String, Pane> officeHoursGridTACellPanes;
    HashMap<String, Label> officeHoursGridTACellLabels;
    
    // THE COMBO BOX
    HBox comboBox;
    ComboBox<String> startHoursComboBox = new ComboBox<>();
    ComboBox<String> endHoursComboBox = new ComboBox<>();
    Button comboButton;
    
    //UNDO REDO CONTROLS
    boolean controlPressed = false;
    boolean zPressed = false;
    boolean yPressed = false;
    
    //INCLUDE THE DEFAULT VALUES
    ArrayList<TimeSlot> temp = new ArrayList();
        
    

    /**
     * The contstructor initializes the user interface, except for
     * the full office hours grid, since it doesn't yet know what
     * the hours will be until a file is loaded or a new one is created.
     */
    public CSGWorkspace(CSGApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;

        // WE'LL NEED THIS TO GET LANGUAGE PROPERTIES FOR OUR UI
        PropertiesManager props = PropertiesManager.getPropertiesManager();

        //INIT THE TABPANE AND TABS
        tabPane = new TabPane();
        //SET TABS TO NOT BE CLOSABLE
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        courseTab = new Tab();
        taTab = new Tab();
        recitationTab = new Tab();
        scheduleTab = new Tab();
        projectTab = new Tab();
        
        //PUT TABS IN TABPANE
        tabPane.getTabs().add(courseTab);
        tabPane.getTabs().add(taTab);
        tabPane.getTabs().add(recitationTab);
        tabPane.getTabs().add(scheduleTab);
        tabPane.getTabs().add(projectTab);
        
        String courseTabText = props.getProperty(CSGProp.COURSE_TAB_HEADER_TEXT.toString());
        courseTab.setText(courseTabText);
        String taTabText = props.getProperty(CSGProp.TA_TAB_HEADER_TEXT.toString());
        taTab.setText(taTabText);
        String recitationTabText = props.getProperty(CSGProp.RECITATION_TAB_HEADER_TEXT.toString());
        recitationTab.setText(recitationTabText);
        String scheduleTabText = props.getProperty(CSGProp.SCHEDULE_TAB_HEADER_TEXT.toString());
        scheduleTab.setText(scheduleTabText);
        String projectTabText = props.getProperty(CSGProp.PROJECT_TAB_HEADER_TEXT.toString());
        projectTab.setText(projectTabText);
        
        //
        //COURSE DETAILS TAB
        //
        CSGData data = (CSGData) app.getDataComponent();
        
        //INIT THE STACKPANE FOR EVERYTHING
        courseDetailsBox = new FlowPane(Orientation.VERTICAL);
        
        //INIT THE GRIDPANE FOR COURSE INFO BOX
        courseInfoPane = new GridPane();
        
        //SET COLUMN WIDTH FOR COURSE INFO
        ColumnConstraints col1 = new ColumnConstraints(200);
        //col1.setPercentWidth(75/4);
        ColumnConstraints col2 = new ColumnConstraints(200);
        //col2.setPercentWidth(75/4);
        ColumnConstraints col3 = new ColumnConstraints(200);
        //col3.setPercentWidth(75/4);
        ColumnConstraints col4 = new ColumnConstraints(200);
        //col4.setPercentWidth(75/4);
        
        //SET COLUMN WIDTH FOR COURSE STYLE BOX
        ColumnConstraints col300 = new ColumnConstraints(300);

        //col4.setPercentWidth(75/4);
        
        //SET ROW HEIGHT FOR PAGE STYLE

        courseInfoPane.getColumnConstraints().addAll(col1, col2, col3, col4);
        
        //INIT THE HBOX FOR SITE TEMPLATE BOX
        siteTemplateBox = new VBox();
        
        //INIT THE GRIDPANE FOR PAGE STYLE
        pageStylePane = new GridPane();
        
        //INIT THE LABELS AND BOXES
        courseInfoLabelBox = new HBox();
        String courseInfoText = props.getProperty(CSGProp.COURSE_INFO_HEADER_TEXT.toString());
        courseInfoLabel = new Label(courseInfoText);
        courseInfoLabelBox.getChildren().add(courseInfoLabel);
        
        courseSubjectLabelBox = new HBox();
        String courseSubjectText = props.getProperty(CSGProp.SUBJECT_TEXT.toString());
        courseSubjectLabel = new Label(courseSubjectText);
        courseSubjectLabelBox.getChildren().add(courseSubjectLabel);
        
        courseNumberLabelBox = new HBox();
        String courseNumberText = props.getProperty(CSGProp.NUMBER_TEXT.toString());
        courseNumberLabel = new Label(courseNumberText);
        courseNumberLabelBox.getChildren().add(courseNumberLabel);
        
        courseSemesterLabelBox = new HBox();
        String courseSemesterText = props.getProperty(CSGProp.SEMESTER_TEXT.toString());
        courseSemesterLabel = new Label(courseSemesterText);
        courseSemesterLabelBox.getChildren().add(courseSemesterLabel);
        
        courseYearLabelBox = new HBox();
        String courseYearText = props.getProperty(CSGProp.YEAR_TEXT.toString());
        courseYearLabel = new Label(courseYearText);
        courseYearLabelBox.getChildren().add(courseYearLabel);
        
        courseTitleLabelBox = new HBox();
        String courseTitleText = props.getProperty(CSGProp.TITLE_TEXT.toString());
        courseTitleLabel = new Label(courseTitleText);
        courseTitleLabelBox.getChildren().add(courseTitleLabel);
        
        courseInstructorNameLabelBox = new HBox();
        String courseInstructorText = props.getProperty(CSGProp.INSTRUCTOR_NAME_TEXT.toString());
        courseInstructorNameLabel = new Label(courseInstructorText);
        courseInstructorNameLabelBox.getChildren().add(courseInstructorNameLabel);
        
        courseHomeLabelBox = new HBox();
        String courseHomeText = props.getProperty(CSGProp.INSTRUCTOR_HOME_TEXT.toString());
        courseHomeLabel = new Label(courseHomeText);
        courseHomeLabelBox.getChildren().add(courseHomeLabel);
        
        courseExportDirLabelBox = new HBox();
        String courseExportText = props.getProperty(CSGProp.EXPORT_DIR_TEXT.toString());
        courseExportDirLabel = new Label(courseExportText);
        courseExportDirLabelBox.getChildren().add(courseExportDirLabel);
        
        courseExportDirFileLabelBox = new HBox();
        courseExportDirFileText = data.getExportDir();
        courseExportDirFileLabel = new Label(courseExportDirFileText);
        courseExportDirFileLabelBox.getChildren().add(courseExportDirFileLabel);
        
        courseSiteTemplateLabelBox = new HBox();
        String courseTemplateText = props.getProperty(CSGProp.SITE_TEMPLATE_HEADER_TEXT.toString());
        courseSiteTemplateLabel = new Label(courseTemplateText);
        courseSiteTemplateLabelBox.getChildren().add(courseSiteTemplateLabel);
        
        courseSiteTemplateTextLabelBox = new HBox();
        String courseAboutText = props.getProperty(CSGProp.SITE_TEMPLATE_ABOUT_TEXT.toString());
        courseSiteTemplateTextLabel = new Label(courseAboutText);
        courseSiteTemplateTextLabelBox.getChildren().add(courseSiteTemplateTextLabel);
        
        courseSiteTemplateDirectoryLocationLabelBox = new HBox();
        courseSiteTemplateDirectoryLocationLabel = new Label(data.getSiteTemplate());
        courseSiteTemplateDirectoryLocationLabelBox.getChildren().add(courseSiteTemplateDirectoryLocationLabel);
        
        courseSitePagesLabelBox = new HBox();
        String courseSitePagesText = props.getProperty(CSGProp.SITE_PAGES_TEXT.toString());
        courseSitePagesLabel = new Label(courseSitePagesText);
        courseSitePagesLabelBox.getChildren().add(courseSitePagesLabel);
        
        coursePageStyleLabelBox = new HBox();
        String coursePageStyleText = props.getProperty(CSGProp.PAGE_STYLE_HEADER_TEXT.toString());
        coursePageStyleLabel = new Label(coursePageStyleText);
        coursePageStyleLabelBox.getChildren().add(coursePageStyleLabel);
        
        courseBannerSchoolImageLabelBox = new HBox();
        String courseBannerSchoolText = props.getProperty(CSGProp.BANNER_SCHOOL_IMAGE_TEXT.toString());
        courseBannerSchoolImageLabel = new Label(courseBannerSchoolText);
        courseBannerSchoolImageLabelBox.getChildren().add(courseBannerSchoolImageLabel);
        
        courseLeftFooterImageLabelBox = new HBox();
        String courseLeftFooterText = props.getProperty(CSGProp.LEFT_FOOTER_IMAGE_TEXT.toString());
        courseLeftFooterImageLabel = new Label(courseLeftFooterText);
        courseLeftFooterImageLabelBox.getChildren().add(courseLeftFooterImageLabel);
        
        courseRightFooterImageLabelBox = new HBox();
        String courseRightFooterText = props.getProperty(CSGProp.RIGHT_FOOTER_IMAGE_TEXT.toString());
        courseRightFooterImageLabel = new Label(courseRightFooterText);
        courseRightFooterImageLabelBox.getChildren().add(courseRightFooterImageLabel);
        
        courseStylesheetLabelBox = new HBox();
        String courseStylesheetText = props.getProperty(CSGProp.STYLESHEET_TEXT.toString());
        courseStylesheetLabel = new Label(courseStylesheetText);
        courseStylesheetLabelBox.getChildren().add(courseStylesheetLabel);
        
        courseNoteLabelBox = new HBox();
        String courseNoteText = props.getProperty(CSGProp.NOTE_TEXT.toString());
        courseNoteLabel = new Label(courseNoteText);
        courseNoteLabelBox.getChildren().add(courseNoteLabel);
        

        //INIT THE COMBOBOXES
        courseSubjectComboBox = new ComboBox();
        courseNumberComboBox = new ComboBox();
        courseSemesterComboBox = new ComboBox();
        courseYearComboBox = new ComboBox();
        courseStyleSheetComboBox = new ComboBox();
        
        //ADD THE STUFF TO THE COMBOBOXES
        courseSubjectComboBox.getItems().addAll(data.getAllSubjects());
        courseNumberComboBox.getItems().addAll(data.getAllNumbers());
        courseSemesterComboBox.getItems().addAll(data.getAllSemesters());
        courseYearComboBox.getItems().addAll(data.getAllYears());
        courseStyleSheetComboBox.getItems().addAll(data.getAllCss());
        
        //SET THE DEFAULT VALUE TO THE START AND END TIMES
        courseSubjectComboBox.getSelectionModel().select(data.getSubject());
        courseNumberComboBox.getSelectionModel().select(data.getNumber() + "");
        courseSemesterComboBox.getSelectionModel().select(data.getSemester());
        courseYearComboBox.getSelectionModel().select(data.getYear() + "");
        courseStyleSheetComboBox.getSelectionModel().select(data.getStylesheet());
        
        //SET WHAT HAPPENS WHEN SOMETHING IS CHANGED
        courseSubjectComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override public void changed(ObservableValue ov, String t, String t1) {
                if(t != null && t1 != null)
                    if(courseSubjectComboBox.getValue().toString().compareTo(data.getSubject()) != 0)
                    {
                        data.setSubject(courseSubjectComboBox.getValue().toString());
                        controller.markWorkAsEdited();
                    }
            }    
        });
        
        courseNumberComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override public void changed(ObservableValue ov, String t, String t1) {
                if(t != null && t1 != null)
                    if(courseNumberComboBox.getValue().toString().compareTo(data.getNumber() + "") != 0)
                    {
                        data.setNumber(Integer.parseInt(courseNumberComboBox.getValue().toString()));
                        controller.markWorkAsEdited();
                    }
            }    
        });
        
        courseSemesterComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override public void changed(ObservableValue ov, String t, String t1) {
                if(t != null && t1 != null)
                    if(courseSemesterComboBox.getValue().toString().compareTo(data.getSemester()) != 0)
                    {
                        data.setSemester(courseSemesterComboBox.getValue().toString());
                        controller.markWorkAsEdited();
                    }
            }    
        });
        
        courseYearComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override public void changed(ObservableValue ov, String t, String t1) {
                if(t != null && t1 != null)
                    if(courseYearComboBox.getValue().toString().compareTo(data.getNumber() + "") != 0)
                    {
                        data.setYear(Integer.parseInt(courseYearComboBox.getValue().toString()));
                        controller.markWorkAsEdited();
                    }
            }    
        });
        
        courseStyleSheetComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override public void changed(ObservableValue ov, String t, String t1) {
                if(t != null && t1 != null)
                    if(courseStyleSheetComboBox.getValue().toString().compareTo(data.getSubject()) != 0)
                    {
                        data.setStylesheet(courseStyleSheetComboBox.getValue().toString());
                        controller.markWorkAsEdited();
                    }
            }    
        });
        
        
        
        //INIT THE TEXTFIELDS
        courseTitleField = new TextField();
        courseTitleField.prefWidthProperty().bind(courseDetailsBox.widthProperty().multiply(.2));
        courseTitleField.setPromptText(data.getTitle());
        courseTitleField.textProperty().addListener(new ChangeListener<String>() {
        @Override
        public void changed(ObservableValue observable, String oldTitle, String newTitle) {
            if(oldTitle.compareTo("") != 0 && newTitle.compareTo("") != 0)
            {
                data.setTitle(newTitle);
                controller.markWorkAsEdited();
            }
        }
    });
        courseInstructorNameField = new TextField();
        courseInstructorNameField.prefWidthProperty().bind(courseDetailsBox.widthProperty().multiply(.2));
        courseInstructorNameField.setPromptText(data.getInstructorName());
        courseInstructorNameField.textProperty().addListener(new ChangeListener<String>() {
        @Override
        public void changed(ObservableValue observable, String oldName, String newName) {
            if(oldName.compareTo("") != 0 && newName.compareTo("") != 0)
            {
                data.setInstructorName(newName);
                controller.markWorkAsEdited();
            }
        }
    });
        courseInstructorHomeField = new TextField();
        courseInstructorHomeField.prefWidthProperty().bind(courseDetailsBox.widthProperty().multiply(.2));
        courseInstructorHomeField.setPromptText(data.getInstructorHome());
        courseInstructorHomeField.textProperty().addListener(new ChangeListener<String>() {
        @Override
        public void changed(ObservableValue observable, String oldHome, String newHome) {
            if(oldHome.compareTo("") != 0 && newHome.compareTo("") != 0)
            {
                data.setInstructorHome(newHome);
                controller.markWorkAsEdited();
            }
        }
    });
        
        //INIT THE BUTTONS
        courseChangeExportDirButton = new Button(props.getProperty(CSGProp.CHANGE_TEXT.toString()));
        courseSelectTemplateButton = new Button(props.getProperty(CSGProp.SELECT_TEMPLATE_DIRECTORY_TEXT.toString()));
        courseChangeBannerButton = new Button(props.getProperty(CSGProp.CHANGE_TEXT.toString()));
        courseChangeLeftFooterButton = new Button(props.getProperty(CSGProp.CHANGE_TEXT.toString()));
        courseChangeRightFooterButton = new Button(props.getProperty(CSGProp.CHANGE_TEXT.toString()));
        
        courseChangeExportDirButton.setOnAction(e -> {
            controller.handleChangeExportDirectory();
        });
        
        courseSelectTemplateButton.setOnAction(e -> {
            controller.handleChangeSiteTemplate();
        });
        
        courseChangeBannerButton.setOnAction(e -> {
            controller.handleBannerSchoolChange();
        });
        
        courseChangeLeftFooterButton.setOnAction(e -> {
            controller.handleBannerLeftSchoolChange();
        });
        
        courseChangeRightFooterButton.setOnAction(e -> {
            controller.handleBannerRightSchoolChange();
        });
        //INIT THE IMAGES
        /*
        String bannerString = data.getBannerSchoolImage();
        Image bannerImage = new Image(bannerString);
        bannerImageView = new ImageView(bannerImage);
        
        String bannerLeftString = data.getBannerLeftFooterImage();
        Image bannerLeftImage = new Image(bannerLeftString);
        bannerLeftImageView = new ImageView(bannerLeftImage);
        
        String bannerRightString = data.getBannerRightFooterImage();
        Image bannerRightImage = new Image(bannerRightString);
        bannerRightImageView = new ImageView(bannerRightImage);
        */
        bannerImageView = new ImageView();
        bannerLeftImageView = new ImageView();
        bannerRightImageView = new ImageView();
        
        //INIT THE SITE TEMPLATE TABLE
        sitePageTable = new TableView();
        ObservableList<Page> siteTableData = data.getSitePages();
        sitePageTable.setItems(siteTableData);
        String useColumnText = props.getProperty(CSGProp.USE_COLUMN_TEXT.toString());
        String navbarColumnText = props.getProperty(CSGProp.NAV_BAR_COLUMN_TEXT.toString());
        String fileNameColumnText = props.getProperty(CSGProp.FILE_NAME_COLUMN_TEXT.toString());
        String scriptColumnText = props.getProperty(CSGProp.SCRIPT_COLUMN_TEXT.toString());
        isUsedColumn = new TableColumn(useColumnText);
        navbarTitleColumn = new TableColumn(navbarColumnText);
        fileNameColumn = new TableColumn(fileNameColumnText);
        scriptNameColumn = new TableColumn(scriptColumnText);
        /*
        isUsedColumn.setCellValueFactory(
        new Callback<CellDataFeatures<Page, Boolean>, ObservableValue<Boolean>>()
        {
            public ObservableValue<Boolean> call(CellDataFeatures<Page, Boolean> param)
            {
                return param.getValue().beingUsed();
            }
        });
        isUsedColumn.setCellFactory(CheckBoxTableCell.forTableColumn(isUsedColumn));
        */
        isUsedColumn.setCellValueFactory(
        new Callback<CellDataFeatures<Page, Boolean>, ObservableValue<Boolean>>()
        {
            public ObservableValue<Boolean> call(CellDataFeatures<Page, Boolean> param)
            {
                return param.getValue().beingUsed();
            }
        });
        isUsedColumn.setCellFactory(CheckBoxTableCell.forTableColumn(isUsedColumn));
        //SET WHEN SOMETHING ENTERS THE NODE
        isUsedColumn.setCellFactory(new Callback<TableColumn<Page, Boolean>, TableCell<Page, Boolean>>() {
                    @Override
                    public TableCell<Page, Boolean> call(TableColumn<Page, Boolean> p) {
                        final CheckBoxTableCell ctCell = new CheckBoxTableCell<>();
                        ctCell.setOnMouseEntered(e -> {
                                controller.markWorkAsEdited();
                                //controller.updateSitesCheck();
                        });
                        ctCell.setOnMouseExited(e -> {
                                controller.markWorkAsEdited();
                        });
                        return ctCell;
                    }
                });
        navbarTitleColumn.setCellValueFactory(
                new PropertyValueFactory<Page, String>("titleName")
        );
        fileNameColumn.setCellValueFactory(
                new PropertyValueFactory<Page, String>("fileName")
        );
        scriptNameColumn.setCellValueFactory(
                new PropertyValueFactory<Page, String>("scriptName")
        );
        sitePageTable.getColumns().add(isUsedColumn);
        sitePageTable.getColumns().add(navbarTitleColumn);
        sitePageTable.getColumns().add(fileNameColumn);
        sitePageTable.getColumns().add(scriptNameColumn);
        sitePageTable.setEditable(true);
        isUsedColumn.setEditable(true);
        /*
        //SET THE TABLE TO BE AS TALL AS THE AMOUNT OF ITEMS IN IT
        sitePageTable.setFixedCellSize(25);
        sitePageTable.prefHeightProperty().bind((sitePageTable.fixedCellSizeProperty().multiply(Bindings.size(sitePageTable.getItems()).add(1.01))));
        sitePageTable.minHeightProperty().bind(sitePageTable.prefHeightProperty());
        sitePageTable.maxHeightProperty().bind(sitePageTable.prefHeightProperty());
        */
        //SET UP COURSE INFO BOX
        courseInfoPane.add(courseInfoLabelBox, 0, 0);
        courseInfoPane.add(courseSubjectLabelBox, 0, 1);
        courseInfoPane.add(courseSemesterLabelBox, 0, 2);
        courseInfoPane.add(courseTitleLabelBox, 0, 3);
        courseInfoPane.add(courseInstructorNameLabelBox, 0, 4);
        courseInfoPane.add(courseHomeLabelBox, 0, 5);
        courseInfoPane.add(courseExportDirLabelBox, 0, 6);
        courseInfoPane.add(courseSubjectComboBox, 1, 1);
        courseInfoPane.add(courseSemesterComboBox, 1, 2);
        courseInfoPane.add(courseTitleField, 1, 3, 3, 1);
        courseInfoPane.add(courseInstructorNameField, 1, 4, 3, 1);
        courseInfoPane.add(courseInstructorHomeField, 1, 5, 3, 1);
        courseInfoPane.add(courseExportDirFileLabelBox, 1, 6, 3, 1);
        courseInfoPane.add(courseNumberLabelBox, 2, 1);
        courseInfoPane.add(courseYearLabelBox, 2, 2);
        courseInfoPane.add(courseNumberComboBox, 3, 1);
        courseInfoPane.add(courseYearComboBox, 3, 2);
        courseInfoPane.add(courseChangeExportDirButton, 3, 6);
        
        //SET UP THE SITE PAGE BOX
        siteTemplateBox.getChildren().add(courseSiteTemplateLabelBox);
        siteTemplateBox.getChildren().add(courseSiteTemplateTextLabelBox);
        siteTemplateBox.getChildren().add(courseSiteTemplateDirectoryLocationLabelBox);
        siteTemplateBox.getChildren().add(courseSelectTemplateButton);
        siteTemplateBox.getChildren().add(sitePageTable);
        
        //SET UP THE PAGE STYLE BOX
        //pageStylePane.getColumnConstraints().addAll(col1, col2, col3);
        pageStylePane.add(coursePageStyleLabelBox, 0, 0);
        pageStylePane.add(courseBannerSchoolImageLabelBox, 0, 1);
        pageStylePane.add(courseLeftFooterImageLabelBox, 0, 2);
        pageStylePane.add(courseRightFooterImageLabelBox, 0, 3);
        pageStylePane.add(courseStylesheetLabelBox, 0, 4);
        pageStylePane.add(bannerImageView, 1, 1);
        pageStylePane.add(bannerLeftImageView, 1, 2);
        pageStylePane.add(bannerRightImageView, 1, 3);
        pageStylePane.add(courseStyleSheetComboBox, 1, 4);
        pageStylePane.add(courseChangeBannerButton, 3, 1);
        pageStylePane.add(courseChangeLeftFooterButton, 3, 2);
        pageStylePane.add(courseChangeRightFooterButton, 3, 3);
        pageStylePane.add(courseNoteLabelBox, 0, 5, 3, 1);
        
        
        //PUT IT IN A STACKPANE
        courseDetailsBox.getChildren().add(courseInfoPane);
        courseInfoPane.prefHeightProperty().bind(courseDetailsBox.heightProperty().multiply(.3));
        courseDetailsBox.getChildren().add(siteTemplateBox);
        siteTemplateBox.prefHeightProperty().bind(courseDetailsBox.heightProperty().multiply(.3));
        courseDetailsBox.getChildren().add(pageStylePane);
        pageStylePane.prefHeightProperty().bind(courseDetailsBox.heightProperty().multiply(.3));
        
        //PUT IT IN THE TAB
        courseTab.setContent(courseDetailsBox);
        
        //
        //RECITATION DATA TAB
        //
        
        //INIT THE CONTAINERS
        recitationDataPane = new VBox();
        recitationAddEditPane = new Pane();
        reciationAddEditFieldsPane = new GridPane();
        
        //INIT THE LABELS
        recitationHeaderLabelBox = new HBox();
        String recitationHeaderText = props.getProperty(CSGProp.RECITATION_HEADER_TEXT.toString());
        recitationHeaderLabel = new Label(recitationHeaderText);
        recitationHeaderLabelBox.getChildren().add(recitationHeaderLabel);
        
        recitationAddEditHeaderLabelBox = new HBox();
        String recitationAddEditText = props.getProperty(CSGProp.ADD_AND_EDIT_TEXT.toString());
        recitationAddEditHeaderLabel = new Label(recitationAddEditText);
        recitationAddEditHeaderLabelBox.getChildren().add(recitationAddEditHeaderLabel);
        
        recitationSectionLabelBox = new HBox();
        String recitationSectionText = props.getProperty(CSGProp.SECTION_TEXT.toString());
        recitationSectionLabel = new Label(recitationSectionText);
        recitationSectionLabelBox.getChildren().add(recitationSectionLabel);
        
        recitationInstructorLabelBox = new HBox();
        String recitationInstructorText = props.getProperty(CSGProp.INSTRUCTOR_TEXT.toString());
        recitationInstructorLabel = new Label(recitationInstructorText);
        recitationInstructorLabelBox.getChildren().add(recitationInstructorLabel);
        
        recitationDayTimeLabelBox = new HBox();
        String recitationDayTimeText = props.getProperty(CSGProp.DAY_AND_TIME_TEXT.toString());
        recitationDayTimeLabel = new Label(recitationDayTimeText);
        recitationDayTimeLabelBox.getChildren().add(recitationDayTimeLabel);
        
        recitationLocationLabelBox = new HBox();
        String recitationLocationText = props.getProperty(CSGProp.LOCATION_TEXT.toString());
        recitationLocationLabel = new Label(recitationLocationText);
        recitationLocationLabelBox.getChildren().add(recitationLocationLabel);
        
        recitationSupervisingTaLabelBox1 = new HBox();
        recitationSupervisingTaLabelBox2 = new HBox();
        String recitationSupervisingTaText = props.getProperty(CSGProp.SUPERVISING_TA_TEXT.toString());
        recitationSupervisingTaLabel = new Label(recitationSupervisingTaText);
        recitationSupervisingTaLabel2 = new Label(recitationSupervisingTaText);
        recitationSupervisingTaLabelBox1.getChildren().add(recitationSupervisingTaLabel);
        recitationSupervisingTaLabelBox2.getChildren().add(recitationSupervisingTaLabel2);
        
        //INIT THE RECITATION TABLE
        recitationTable = new TableView();
        ObservableList<Recitation> recitationData = data.getRecitations();
        recitationTable.setItems(recitationData);
        String sectionColumnText = props.getProperty(CSGProp.SECTION_TEXT.toString());
        String instructorColumnText = props.getProperty(CSGProp.INSTRUCTOR_TEXT.toString());
        String dayAndTimeColumnText = props.getProperty(CSGProp.DAY_AND_TIME_TEXT.toString());
        String locationColumnText = props.getProperty(CSGProp.LOCATION_TEXT.toString());
        String taColumnText = props.getProperty(CSGProp.TA_TEXT.toString());
        recitationSectionColumn = new TableColumn(sectionColumnText);
        reciationInstructorColumn = new TableColumn(instructorColumnText);
        recitationDayTimeColumn = new TableColumn(dayAndTimeColumnText);
        recitationLocationColumn = new TableColumn(locationColumnText);
        recitationTAOneColumn = new TableColumn(taColumnText);
        recitationTATwoColumn = new TableColumn(taColumnText);
        recitationSectionColumn.setCellValueFactory(
                new PropertyValueFactory<Recitation, String>("section")
        );
        reciationInstructorColumn.setCellValueFactory(
                new PropertyValueFactory<Recitation, String>("instructor")
        );
        recitationDayTimeColumn.setCellValueFactory(
                new PropertyValueFactory<Recitation, String>("dayAndTime")
        );
        recitationLocationColumn.setCellValueFactory(
                new PropertyValueFactory<Recitation, String>("location")
        );
        recitationTAOneColumn.setCellValueFactory(
                new PropertyValueFactory<Recitation, String>("taOne")
        );
        recitationTATwoColumn.setCellValueFactory(
                new PropertyValueFactory<Recitation, String>("taTwo")
        );
        recitationTable.getColumns().add(recitationSectionColumn);
        recitationTable.getColumns().add(reciationInstructorColumn);
        recitationTable.getColumns().add(recitationDayTimeColumn);
        recitationTable.getColumns().add(recitationLocationColumn);
        recitationTable.getColumns().add(recitationTAOneColumn);
        recitationTable.getColumns().add(recitationTATwoColumn);
        //SET THE WIDTH
        recitationSectionColumn.prefWidthProperty().bind(recitationTable.widthProperty().multiply(0.16));
        reciationInstructorColumn.prefWidthProperty().bind(recitationTable.widthProperty().multiply(0.16));
        recitationDayTimeColumn.prefWidthProperty().bind(recitationTable.widthProperty().multiply(0.16));
        recitationLocationColumn.prefWidthProperty().bind(recitationTable.widthProperty().multiply(0.16));
        recitationTAOneColumn.prefWidthProperty().bind(recitationTable.widthProperty().multiply(0.16));
        recitationTATwoColumn.prefWidthProperty().bind(recitationTable.widthProperty().multiply(0.16));
        /*
        //SET THE TABLE TO BE AS TALL AS THE AMOUNT OF ITEMS IN IT
        recitationTable.setFixedCellSize(25);
        recitationTable.prefHeightProperty().bind((recitationTable.fixedCellSizeProperty().multiply(Bindings.size(recitationTable.getItems()).add(1.01))));
        recitationTable.minHeightProperty().bind(recitationTable.prefHeightProperty());
        recitationTable.maxHeightProperty().bind(recitationTable.prefHeightProperty());
        */
        //SET THE KEYPRESS
        recitationTable.setOnKeyPressed(e -> {
            controller.handleDeleteRecitation(e.getCode());
        });
        //SET EDIT
        recitationTable.setOnMouseClicked(e -> {
            controller.handleEditRecitation();
        });
        //INIT THE TEXTFIELDS
        recitationSectionField = new TextField();
        recitationSectionField.setPromptText(props.getProperty(CSGProp.SECTION_TEXT.toString()));
        recitationSectionField.prefWidthProperty().bind(reciationAddEditFieldsPane.widthProperty().multiply(.2));
        recitationInstructorField = new TextField();
        recitationInstructorField.setPromptText(props.getProperty(CSGProp.INSTRUCTOR_TEXT.toString()));
        recitationInstructorField.prefWidthProperty().bind(reciationAddEditFieldsPane.widthProperty().multiply(.2));
        recitationDayTimeField = new TextField();
        recitationDayTimeField.setPromptText(props.getProperty(CSGProp.DAY_AND_TIME_TEXT.toString()));
        recitationDayTimeField.prefWidthProperty().bind(reciationAddEditFieldsPane.widthProperty().multiply(.2));
        recitationLocationField = new TextField();
        recitationLocationField.setPromptText(props.getProperty(CSGProp.LOCATION_TEXT.toString()));
        recitationLocationField.prefWidthProperty().bind(reciationAddEditFieldsPane.widthProperty().multiply(.2));
        
        //INIT THE COMBOBOXES
        recitationTA1 = new ComboBox();
        recitationTA2 = new ComboBox();
        
        //ADD THE STUFF TO THE COMBOBOXES
        
        recitationTA1.setOnMouseClicked(e -> {
            //recitationTA2.getItems().retainAll(data.getTeachingAssistants());
           recitationTA1.getItems().clear();
           recitationTA1.getItems().addAll(data.getTeachingAssistants());
           if(!recitationTA1.getItems().contains(recitationTA1.getValue()))
           {
                recitationTA1.getSelectionModel().clearSelection();
           }
           if(recitationTA2.getValue() != null)
           {
                if(recitationTA1.getItems().contains(recitationTA2.getValue()))
                {
                    recitationTA1.getItems().remove(recitationTA2.getValue());
                }
           }
        });
        
        recitationTA2.setOnMouseClicked(e -> {
            //recitationTA2.getItems().retainAll(data.getTeachingAssistants());
           recitationTA2.getItems().clear();
           recitationTA2.getItems().addAll(data.getTeachingAssistants());
           if(!recitationTA2.getItems().contains(recitationTA2.getValue()))
           {
               recitationTA2.getSelectionModel().clearSelection();
           }
           if(recitationTA1.getValue() != null)
           {
                if(recitationTA2.getItems().contains(recitationTA1.getValue()))
                {
                    recitationTA2.getItems().remove(recitationTA1.getValue());
                }
           }
        });
        
        //INIT THE BUTTONS
        recitationAddUpdateButton = new Button(props.getProperty(CSGProp.ADD_RECITATION_BUTTON_TEXT.toString()));
        recitationClearButton = new Button(props.getProperty(CSGProp.CLEAR_BUTTON_TEXT.toString()));
        recitationDeleteButton = new Button();
        Image buttonImage = new Image(FILE_PROTOCOL + PATH_IMAGES + props.getProperty(CSGProp.DELETE_ICON.toString()));
        recitationDeleteButton.setGraphic(new ImageView(buttonImage));
        
        //SET THE EVENT HANDLING
        recitationSectionField.setOnAction(e -> {
            controller.handleAddRecitation();
        });
        recitationInstructorField.setOnAction(e -> {
            controller.handleAddRecitation();
        });
        recitationDayTimeField.setOnAction(e -> {
            controller.handleAddRecitation();
        });
        recitationLocationField.setOnAction(e -> {
            controller.handleAddRecitation();
        });
        recitationAddUpdateButton.setOnAction(e -> {
            controller.handleAddRecitation();
        });
        recitationClearButton.setOnAction(e -> {
            controller.clearRecitation();
        });
        recitationDeleteButton.setOnAction(e -> {
            controller.handleDeleteRecitation();
        });
        
        //START ASSEMBLING THE RECITATION TAB COMPONENTS
        reciationAddEditFieldsPane.add(recitationAddEditHeaderLabelBox, 0, 0);
        reciationAddEditFieldsPane.add(recitationSectionLabelBox, 0, 1);
        reciationAddEditFieldsPane.add(recitationInstructorLabelBox, 0, 2);
        reciationAddEditFieldsPane.add(recitationDayTimeLabelBox, 0, 3);
        reciationAddEditFieldsPane.add(recitationLocationLabelBox, 0, 4);
        reciationAddEditFieldsPane.add(recitationSupervisingTaLabelBox1, 0, 5);
        reciationAddEditFieldsPane.add(recitationSupervisingTaLabelBox2, 0, 6);
        reciationAddEditFieldsPane.add(recitationAddUpdateButton, 0, 7, 2, 1);
        reciationAddEditFieldsPane.add(recitationSectionField, 1, 1);
        reciationAddEditFieldsPane.add(recitationInstructorField, 1, 2);
        reciationAddEditFieldsPane.add(recitationDayTimeField, 1, 3);
        reciationAddEditFieldsPane.add(recitationLocationField, 1, 4);
        reciationAddEditFieldsPane.add(recitationTA1, 1, 5);
        reciationAddEditFieldsPane.add(recitationTA2, 1, 6);
        reciationAddEditFieldsPane.add(recitationClearButton, 2, 7);
        //SET WIDTH OF THE GRIDCOLUMNS
        reciationAddEditFieldsPane.getColumnConstraints().addAll(new ColumnConstraints(150), new ColumnConstraints(150));
        
        //PUT IT ALL TOGETHER
        recitationHeaderLabelBox.getChildren().add(recitationDeleteButton);
        recitationDataPane.getChildren().add(recitationHeaderLabelBox);
        recitationDataPane.getChildren().add(recitationTable);
        recitationAddEditPane.getChildren().add(reciationAddEditFieldsPane);
        recitationDataPane.getChildren().add(recitationAddEditPane);
        recitationTab.setContent(recitationDataPane);
        
        //
        //SCHEDULE TAB
        //
        //--SCHEDULE TAB--//
        
        //INIT THE TEXT
        scheduleHeaderLabelBox = new HBox();
        String scheduleHeaderText = props.getProperty(CSGProp.SCHEDULE_HEADER_TEXT.toString());
        scheduleHeaderLabel = new Label(scheduleHeaderText);
        scheduleHeaderLabelBox.getChildren().add(scheduleHeaderLabel);
        
        scheduleCalendarBoundariesLabelBox = new HBox();
        String scheduleCalendarBoundariesText = props.getProperty(CSGProp.CALENDAR_BOUNDARIES_TEXT.toString());
        scheduleCalendarBoundariesLabel = new Label(scheduleCalendarBoundariesText);
        scheduleCalendarBoundariesLabelBox.getChildren().add(scheduleCalendarBoundariesLabel);
        
        scheduleStartingMondayLabelBox = new HBox();
        String scheduleStartingMondayText = props.getProperty(CSGProp.STARTING_MONDAY_TEXT.toString());
        scheduleStartingMondayLabel = new Label(scheduleStartingMondayText);
        scheduleStartingMondayLabelBox.getChildren().add(scheduleStartingMondayLabel);
        
        scheduleEndingFridayLabelBox = new HBox();
        String scheduleEndingFridayText = props.getProperty(CSGProp.ENDING_FRIDAY_TEXT.toString());
        scheduleEndingFridayLabel = new Label(scheduleEndingFridayText);
        scheduleEndingFridayLabelBox.getChildren().add(scheduleEndingFridayLabel);
        
        scheduleItemsLabelBox = new HBox();
        String scheduleItemsText = props.getProperty(CSGProp.SCHEDULE_ITEMS_TEXT.toString());
        scheduleItemsLabel = new Label(scheduleItemsText);
        scheduleItemsLabelBox.getChildren().add(scheduleItemsLabel);
        
        scheduleAddAndEditLabelBox = new HBox();
        String scheduleAddAndEditText = props.getProperty(CSGProp.ADD_AND_EDIT_TEXT.toString());
        scheduleAddAndEditLabel = new Label(scheduleAddAndEditText);
        scheduleAddAndEditLabelBox.getChildren().add(scheduleAddAndEditLabel);
        
        scheduleTypeLabelBox = new HBox();
        String scheduleTypeText = props.getProperty(CSGProp.TYPE_TEXT.toString());
        scheduleTypeLabel = new Label(scheduleTypeText);
        scheduleTypeLabelBox.getChildren().add(scheduleTypeLabel);
        
        scheduleDateLabelBox = new HBox();
        String scheduleDateText = props.getProperty(CSGProp.DATE_TEXT.toString());
        scheduleDateLabel = new Label(scheduleDateText);
        scheduleDateLabelBox.getChildren().add(scheduleDateLabel);
        
        scheduleTimeLabelBox = new HBox();
        String scheduleTimeText = props.getProperty(CSGProp.TIME_TEXT.toString());
        scheduleTimeLabel = new Label(scheduleTimeText);
        scheduleTimeLabelBox.getChildren().add(scheduleTimeLabel);
        
        scheduleTitleLabelBox = new HBox();
        String scheduleTitleText = props.getProperty(CSGProp.TITLE_TEXT.toString());
        scheduleTitleLabel = new Label(scheduleTitleText);
        scheduleTitleLabelBox.getChildren().add(scheduleTitleLabel);
        
        scheduleTopicLabelBox = new HBox();
        String scheduleTopicText = props.getProperty(CSGProp.TOPIC_TEXT.toString());
        scheduleTopicLabel = new Label(scheduleTopicText);
        scheduleTopicLabelBox.getChildren().add(scheduleTopicLabel);
        
        scheduleLinkLabelBox = new HBox();
        String scheduleLinkText = props.getProperty(CSGProp.LINK_TEXT.toString());
        scheduleLinkLabel = new Label(scheduleLinkText);
        scheduleLinkLabelBox.getChildren().add(scheduleLinkLabel);
        
        scheduleCriteriaLabelBox = new HBox();
        String scheduleCriteriaText = props.getProperty(CSGProp.CRITERIA_TEXT.toString());
        scheduleCriteriaLabel = new Label(scheduleCriteriaText);
        scheduleCriteriaLabelBox.getChildren().add(scheduleCriteriaLabel);
        
        //INIT THE TEXTFIELDS
        scheduleTimeField = new TextField();
        scheduleTimeField.setPromptText(props.getProperty(CSGProp.TIME_TEXT.toString()));
        scheduleTitleField = new TextField();
        scheduleTitleField.setPromptText(props.getProperty(CSGProp.TITLE_TEXT.toString()));
        scheduleTopicField = new TextField();
        scheduleTopicField.setPromptText(props.getProperty(CSGProp.TOPIC_TEXT.toString()));
        scheduleLinkField = new TextField();
        scheduleLinkField.setPromptText(props.getProperty(CSGProp.LINK_TEXT.toString()));
        scheduleCriteriaField = new TextField();
        scheduleCriteriaField.setPromptText(props.getProperty(CSGProp.CRITERIA_TEXT.toString()));
        
        //INIT THE DATEPICKERS
        startingMonday = new DatePicker();
        endingFriday = new DatePicker();
        scheduleDateDatePicker = new DatePicker();
        
        //THE EVENT HANDLING
        startingMonday.setOnAction(e -> {
            controller.changeStartingMonday();
        });
        
        endingFriday.setOnAction(e -> {
            controller.changeEndingFriday();
        });
        
        //INIT THE COMBOBOXES
        scheduleTypeComboBox = new ComboBox();
        scheduleTypeComboBox.getItems().addAll(data.getAllTypes());
        
        //INIT THE BUTTONS
        scheduleAddUpdateButton = new Button(props.getProperty(CSGProp.ADD_SCHEDULE_BUTTON_TEXT.toString()));
        scheduleClearButton = new Button(props.getProperty(CSGProp.CLEAR_BUTTON_TEXT.toString()));
        scheduleDeleteButton = new Button();
        Image buttonImage2 = new Image(FILE_PROTOCOL + PATH_IMAGES + props.getProperty(CSGProp.DELETE_ICON.toString()));
        scheduleDeleteButton.setGraphic(new ImageView(buttonImage2));
        //SET THE EVENT HANDLING
        scheduleAddUpdateButton.setOnAction(e -> {
            controller.handleAddSchedule();
        });
        
        scheduleDeleteButton.setOnAction(e -> {
            controller.handleDeleteSchedule();
        });
        
        scheduleClearButton.setOnAction(e -> {
            controller.clearSchedule();
        });
        
        //INIT THE SCHEDULE TABLE
        scheduleTable = new TableView();
        ObservableList<Schedule> scheduleData = data.getSchedules();
        scheduleTable.setItems(scheduleData);
        String scheduleTypeColumnText = props.getProperty(CSGProp.TYPE_TEXT.toString());
        String scheduleDateColumnText = props.getProperty(CSGProp.DATE_TEXT.toString());
        String scheduleTitleColumnText = props.getProperty(CSGProp.TITLE_TEXT.toString());
        String scheduleTopicColumnText = props.getProperty(CSGProp.TOPIC_TEXT.toString());
        scheduleTypeColumn = new TableColumn(scheduleTypeColumnText);
        scheduleDateColumn = new TableColumn(scheduleDateColumnText);
        scheduleTitleColumn = new TableColumn(scheduleTitleColumnText);
        scheduleTopicColumn = new TableColumn(scheduleTopicColumnText);
        scheduleTypeColumn.setCellValueFactory(
                new PropertyValueFactory<Schedule, String>("type")
        );
        scheduleDateColumn.setCellValueFactory(
                new PropertyValueFactory<Schedule, LocalDate>("date")
        );
        scheduleTitleColumn.setCellValueFactory(
                new PropertyValueFactory<Schedule, String>("title")
        );
        scheduleTopicColumn.setCellValueFactory(
                new PropertyValueFactory<Schedule, String>("topic")
        );
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        scheduleDateColumn.setCellFactory(TextFieldTableCell.forTableColumn(new StringConverter<LocalDate>()
        {
            public String toString(LocalDate d) {
                if (d == null) {
                    return "" ;
                } else {
                    return dateFormatter.format(d);
                }
            }

            public LocalDate fromString(String str) {
                try {
                    return LocalDate.parse(str, dateFormatter);
                } catch (DateTimeParseException exception) {
                    return null ;
                }
            }
        }
        ));
        scheduleTable.getColumns().add(scheduleTypeColumn);
        scheduleTable.getColumns().add(scheduleDateColumn);
        scheduleTable.getColumns().add(scheduleTitleColumn);
        scheduleTable.getColumns().add(scheduleTopicColumn);
        //SET THE WIDTH
        scheduleTypeColumn.prefWidthProperty().bind(scheduleTable.widthProperty().multiply(0.25));
        scheduleDateColumn.prefWidthProperty().bind(scheduleTable.widthProperty().multiply(0.25));
        scheduleTitleColumn.prefWidthProperty().bind(scheduleTable.widthProperty().multiply(0.25));
        scheduleTopicColumn.prefWidthProperty().bind(scheduleTable.widthProperty().multiply(0.25));
        /*
        //SET THE TABLE TO BE AS TALL AS THE AMOUNT OF ITEMS IN IT
        scheduleTable.setFixedCellSize(25);
        scheduleTable.prefHeightProperty().bind((scheduleTable.fixedCellSizeProperty().multiply(Bindings.size(scheduleTable.getItems()).add(1.01))));
        scheduleTable.minHeightProperty().bind(scheduleTable.prefHeightProperty());
        scheduleTable.maxHeightProperty().bind(scheduleTable.prefHeightProperty());
        */
        
        //THE EVENT HANDLING
        scheduleTable.setOnKeyPressed(e -> {
            controller.handleDeleteSchedule(e.getCode());
        });
        
        scheduleTable.setOnMouseClicked(e -> {
            controller.handleEditSchedule();
        });
        //INIT THE BOXES AND PANES
        scheduleBox = new VBox();
        scheduleTopBox = new VBox();
        scheduleTopBoxHorizontal = new HBox();
        scheduleItemsBox = new VBox();
        scheduleInputPane = new GridPane();
        
        //ORGANIZE THE PANES
        scheduleBox.getChildren().add(scheduleHeaderLabelBox);
        scheduleTopBox.getChildren().add(scheduleCalendarBoundariesLabelBox);
        scheduleTopBox.getChildren().add(scheduleTopBoxHorizontal);
        scheduleBox.getChildren().add(scheduleTopBox);
        scheduleItemsLabelBox.getChildren().add(scheduleDeleteButton);
        scheduleItemsBox.getChildren().add(scheduleItemsLabelBox);
        scheduleItemsBox.getChildren().add(scheduleTable);
        scheduleItemsBox.getChildren().add(scheduleInputPane);
        scheduleBox.getChildren().add(scheduleItemsBox);
        
        //PUT THE COMPONENTS IN THE PANES
        scheduleTopBoxHorizontal.getChildren().add(scheduleStartingMondayLabelBox);
        scheduleTopBoxHorizontal.getChildren().add(startingMonday);
        scheduleTopBoxHorizontal.getChildren().add(scheduleEndingFridayLabelBox);
        scheduleTopBoxHorizontal.getChildren().add(endingFriday);
        
        scheduleInputPane.add(scheduleAddAndEditLabelBox, 0, 0, 3, 1);
        scheduleInputPane.add(scheduleTypeLabelBox, 0, 1);
        scheduleInputPane.add(scheduleDateLabelBox, 0, 2);
        scheduleInputPane.add(scheduleTimeLabelBox, 0, 3);
        scheduleInputPane.add(scheduleTitleLabelBox, 0, 4);
        scheduleInputPane.add(scheduleTopicLabelBox, 0, 5);
        scheduleInputPane.add(scheduleLinkLabelBox, 0, 6);
        scheduleInputPane.add(scheduleCriteriaLabelBox, 0, 7);
        scheduleInputPane.add(scheduleAddUpdateButton, 0, 8, 2, 1);
        scheduleInputPane.add(scheduleTypeComboBox, 1, 1);
        scheduleInputPane.add(scheduleDateDatePicker, 1, 2);
        scheduleInputPane.add(scheduleTimeField, 1, 3);
        scheduleInputPane.add(scheduleTitleField, 1, 4);
        scheduleInputPane.add(scheduleTopicField, 1, 5);
        scheduleInputPane.add(scheduleLinkField, 1, 6);
        scheduleInputPane.add(scheduleCriteriaField, 1, 7);
        scheduleInputPane.add(scheduleClearButton, 2, 8);
        //SET THE COLUMN WIDTH
        scheduleInputPane.getColumnConstraints().addAll(new ColumnConstraints(100), new ColumnConstraints(200));
        //PUT IT ALL IN THE SCHEDULE TAB
        scheduleTab.setContent(scheduleBox);

        //
        //PROJECT DATA TAB
        //
        
        //INIT THE LABELS
        
        projectHeaderLabelBox = new HBox();
        String projectHeaderLabelText = props.getProperty(CSGProp.PROJECTS_HEADER_TEXT.toString());
        projectHeaderLabel = new Label(projectHeaderLabelText);
        projectHeaderLabelBox.getChildren().add(projectHeaderLabel);
                
        projectTeamHeaderLabelBox = new HBox();
        String projectTeamHeaderText = props.getProperty(CSGProp.TEAMS_TEXT.toString());
        projectTeamHeaderLabel = new Label(projectTeamHeaderText);
        projectTeamHeaderLabelBox.getChildren().add(projectTeamHeaderLabel);
        
        projectAddEditLabelBox = new HBox();
        String projectAddEditText = props.getProperty(CSGProp.ADD_AND_EDIT_TEXT.toString());
        projectAddEditLabel = new Label(projectAddEditText);
        projectAddEditLabelBox.getChildren().add(projectAddEditLabel);
        
        projectNameLabelBox = new HBox();
        String projectNameText = props.getProperty(CSGProp.NAME_TEXT.toString());
        projectNameLabel = new Label(projectNameText);
        projectNameLabelBox.getChildren().add(projectNameLabel);
        
        projectColorLabelBox = new HBox();
        String projectColorLabelText = props.getProperty(CSGProp.COLOR_TEXT.toString());
        projectColorLabel = new Label(projectColorLabelText);
        projectColorLabelBox.getChildren().add(projectColorLabel);
        
        projectLinkLabelBox = new HBox();
        String projectLinkLabelText = props.getProperty(CSGProp.LINK_TEXT.toString());
        projectLinkLabel = new Label(projectLinkLabelText);
        projectLinkLabelBox.getChildren().add(projectLinkLabel);
        
        projectTextColorLabelBox = new HBox();
        String projectTextColorLabelText = props.getProperty(CSGProp.COLOR_TEXT.toString());
        projectTextColorLabel = new Label(projectTextColorLabelText);
        projectTextColorLabelBox.getChildren().add(projectTextColorLabel);
        
        projectStudentHeaderLabelBox = new HBox();
        String projectStudentHeaderText = props.getProperty(CSGProp.STUDENTS_TEXT.toString());
        projectStudentHeaderLabel = new Label(projectStudentHeaderText);
        projectStudentHeaderLabelBox.getChildren().add(projectStudentHeaderLabel);
        
        projectStudentAddEditLabelBox = new HBox();
        String projectStudentAddEditLabelText = props.getProperty(CSGProp.ADD_AND_EDIT_TEXT.toString());
        projectStudentAddEditLabel = new Label(projectStudentAddEditLabelText);
        projectStudentAddEditLabelBox.getChildren().add(projectStudentAddEditLabel);
        
        projectFirstNameLabelBox = new HBox();
        String projectFirstNameLabelText = props.getProperty(CSGProp.FIRST_NAME_TEXT.toString());
        projectFirstNameLabel = new Label(projectFirstNameLabelText);
        projectFirstNameLabelBox.getChildren().add(projectFirstNameLabel);
        
        projectLastNameLabelBox = new HBox();
        String projectLastNameLabelText = props.getProperty(CSGProp.LAST_NAME_TEXT.toString());
        projectLastNameLabel = new Label(projectLastNameLabelText);
        projectLastNameLabelBox.getChildren().add(projectLastNameLabel);
        
        projectTeamLabelBox = new HBox();
        String projectTeamLabelText = props.getProperty(CSGProp.TEAM_TEXT.toString());
        projectTeamLabel = new Label(projectTeamLabelText);
        projectTeamLabelBox.getChildren().add(projectTeamLabel);
        
        projectRoleLabelBox = new HBox();
        String projectRoleLabelText = props.getProperty(CSGProp.ROLE_TEXT.toString());
        projectRoleLabel = new Label(projectRoleLabelText);
        projectRoleLabelBox.getChildren().add(projectRoleLabel);
        
        //INIT THE TEXTFIELDS
        projectTeamNameField = new TextField();
        projectTeamNameField.setPromptText(props.getProperty(CSGProp.TEAM_TEXT.toString()));
        projectTeamLinkField = new TextField();
        projectTeamLinkField.setPromptText(props.getProperty(CSGProp.LINK_TEXT.toString()));
        projectStudentFirstNameField = new TextField();
        projectStudentFirstNameField.setPromptText(props.getProperty(CSGProp.FIRST_NAME_TEXT.toString()));
        projectStudentLastNameField = new TextField();
        projectStudentLastNameField.setPromptText(props.getProperty(CSGProp.FIRST_NAME_TEXT.toString()));
        projectStudentRoleField = new TextField();
        projectStudentRoleField.setPromptText(props.getProperty(CSGProp.ROLE_TEXT.toString()));
        
        //INIT THE BUTTONS
        projectTeamAddAndUpdateButton = new Button(props.getProperty(CSGProp.ADD_TEAM_BUTTON_TEXT.toString()));
        projectTeamClearButton = new Button(props.getProperty(CSGProp.CLEAR_BUTTON_TEXT.toString()));
        projectStudentAddAndUpdateButton = new Button(props.getProperty(CSGProp.ADD_STUDENT_BUTTON_TEXT.toString()));
        projectStudentClearButton = new Button(props.getProperty(CSGProp.CLEAR_BUTTON_TEXT.toString()));
        projectTeamDeleteButton = new Button();
        Image buttonImage3 = new Image(FILE_PROTOCOL + PATH_IMAGES + props.getProperty(CSGProp.DELETE_ICON.toString()));
        projectTeamDeleteButton.setGraphic(new ImageView(buttonImage3));
        projectStudentDeleteButton = new Button();
        Image buttonImage4 = new Image(FILE_PROTOCOL + PATH_IMAGES + props.getProperty(CSGProp.DELETE_ICON.toString()));
        projectStudentDeleteButton.setGraphic(new ImageView(buttonImage4));
        
        //SET THE EVENT HANDLING
        projectTeamAddAndUpdateButton.setOnAction(e -> {
            controller.handleAddTeam();
        });
        
        projectTeamClearButton.setOnAction(e -> {
            controller.clearTeam();
        });
        
        projectTeamDeleteButton.setOnAction(e -> {
            controller.handleDeleteTeam();
        });
        
        projectStudentAddAndUpdateButton.setOnAction(e -> {
            controller.handleAddStudent();
        });
        
        projectStudentClearButton.setOnAction(e -> {
            controller.clearStudent();
        });
        
        projectStudentDeleteButton.setOnAction(e -> {
            controller.handleDeleteStudent();
        });
        
        //INIT THE COMBOBOX
        projectStudentTeamComboBox = new ComboBox();
        projectStudentTeamComboBox.setOnMouseClicked(e -> {
            projectStudentTeamComboBox.getItems().clear();
            projectStudentTeamComboBox.getItems().addAll(data.getTeams());
            if(!projectStudentTeamComboBox.getItems().contains(projectStudentTeamComboBox.getValue()))
            {
                projectStudentTeamComboBox.getSelectionModel().clearSelection();
            }
        });
        
        //INIT THE COLORPICKERS
        projectTeamColorPicker = new ColorPicker();
        projectTeamTextColorPicker = new ColorPicker();
        
        //INIT THE TEAM TABLE
        teamTable = new TableView();
        ObservableList<Team> teamData = data.getTeams();
        teamTable.setItems(teamData);
        String teamNameColumnText = props.getProperty(CSGProp.NAME_TEXT.toString());
        String teamColorColumnText = props.getProperty(CSGProp.COLOR_TEXT.toString());
        String teamTextColorColumnText = props.getProperty(CSGProp.TEXT_COLOR_TEXT.toString());
        String teamLinkColumnText = props.getProperty(CSGProp.LINK_TEXT.toString());
        teamNameColumn = new TableColumn(teamNameColumnText);
        teamColorColumn = new TableColumn(teamColorColumnText);
        teamTextColorColumn = new TableColumn(teamTextColorColumnText);
        teamLinkColumn = new TableColumn(teamLinkColumnText);
        teamNameColumn.setCellValueFactory(
                new PropertyValueFactory<Team, String>("name")
        );
        teamColorColumn.setCellValueFactory(
                new PropertyValueFactory<Team, Color>("color")
        );
        teamTextColorColumn.setCellValueFactory(
                new PropertyValueFactory<Team, Color>("textColor")
        );
        teamLinkColumn.setCellValueFactory(
                new PropertyValueFactory<Team, String>("link")
        );
        teamColorColumn.setCellFactory(TextFieldTableCell.forTableColumn(new StringConverter<Color>()
        {
            public String toString(Color c) {
                if (c == null) {
                    return "" ;
                } else {
                    return String.format("#%02X%02X%02X", (int)(c.getRed() * 255), (int)(c.getGreen() * 255), (int)(c.getBlue() * 255));
                }
            }

            @Override
            public Color fromString(String str) {
                try {
                    return Color.web(str);
                } catch (IllegalArgumentException exception) {
                    return null;
                }
            }
        }
        ));
        teamTextColorColumn.setCellFactory(TextFieldTableCell.forTableColumn(new StringConverter<Color>()
        {
            public String toString(Color c) {
                if (c == null) {
                    return "" ;
                } else {
                    return String.format("#%02X%02X%02X", (int)(c.getRed() * 255), (int)(c.getGreen() * 255), (int)(c.getBlue() * 255));
                }
            }

            @Override
            public Color fromString(String str) {
                try {
                    return Color.web(str);
                } catch (IllegalArgumentException exception) {
                    return null;
                }
            }
        }
        ));
        teamTable.getColumns().add(teamNameColumn);
        teamTable.getColumns().add(teamColorColumn);
        teamTable.getColumns().add(teamTextColorColumn);
        teamTable.getColumns().add(teamLinkColumn);
        //SET THE WIDTH
        teamNameColumn.prefWidthProperty().bind(teamTable.widthProperty().multiply(0.25));
        teamColorColumn.prefWidthProperty().bind(teamTable.widthProperty().multiply(0.25));
        teamTextColorColumn.prefWidthProperty().bind(teamTable.widthProperty().multiply(0.25));
        teamLinkColumn.prefWidthProperty().bind(teamTable.widthProperty().multiply(0.25));
        //SET THE HANDLERS
        teamTable.setOnKeyPressed(e -> {
            controller.handleDeleteTeam(e.getCode());
        });
        
        teamTable.setOnMouseClicked(e -> {
            controller.handleEditTeam();
        });
        
        /*
        //SET THE TABLE TO BE AS TALL AS THE AMOUNT OF ITEMS IN IT
        teamTable.setFixedCellSize(25);
        teamTable.prefHeightProperty().bind((teamTable.fixedCellSizeProperty().multiply(Bindings.size(teamTable.getItems()).add(1.01))));
        teamTable.minHeightProperty().bind(teamTable.prefHeightProperty());
        teamTable.maxHeightProperty().bind(teamTable.prefHeightProperty());
*/
        //SET THE STUDENT TABLE
        studentTable = new TableView();
        ObservableList<Student> studentData = data.getStudents();
        studentTable.setItems(studentData);
        String studentFirstNameColumnText = props.getProperty(CSGProp.FIRST_NAME_TEXT.toString());
        String studentLastNameColumnText = props.getProperty(CSGProp.LAST_NAME_TEXT.toString());
        String studentTeamColumnText = props.getProperty(CSGProp.TEAM_TEXT.toString());
        String studentRoleColumnText = props.getProperty(CSGProp.ROLE_TEXT.toString());
        studentFirstNameColumn = new TableColumn(studentFirstNameColumnText);
        studentLastNameColumn = new TableColumn(studentLastNameColumnText);
        studentTeamColumn = new TableColumn(studentTeamColumnText);
        studentRoleColumn = new TableColumn(studentRoleColumnText);
        studentFirstNameColumn.setCellValueFactory(
                new PropertyValueFactory<Student, String>("firstName")
        );
        studentLastNameColumn.setCellValueFactory(
                new PropertyValueFactory<Student, String>("lastName")
        );
        studentTeamColumn.setCellValueFactory(
                new PropertyValueFactory<Student, String>("team")
        );
        studentRoleColumn.setCellValueFactory(
                new PropertyValueFactory<Student, String>("role")
        );
        studentTable.getColumns().add(studentFirstNameColumn);
        studentTable.getColumns().add(studentLastNameColumn);
        studentTable.getColumns().add(studentTeamColumn);
        studentTable.getColumns().add(studentRoleColumn);
        //SET THE WIDTH
        studentFirstNameColumn.prefWidthProperty().bind(studentTable.widthProperty().multiply(0.25));
        studentLastNameColumn.prefWidthProperty().bind(studentTable.widthProperty().multiply(0.25));
        studentTeamColumn.prefWidthProperty().bind(studentTable.widthProperty().multiply(0.25));
        studentRoleColumn.prefWidthProperty().bind(studentTable.widthProperty().multiply(0.25));
        
        //SET THE TABLE TO BE AS TALL AS THE AMOUNT OF ITEMS IN IT
        /*
        studentTable.setFixedCellSize(25);
        studentTable.prefHeightProperty().bind((studentTable.fixedCellSizeProperty().multiply(Bindings.size(studentTable.getItems()).add(1.01))));
        studentTable.minHeightProperty().bind(studentTable.prefHeightProperty());
        studentTable.maxHeightProperty().bind(studentTable.prefHeightProperty());
        */
        
        studentTable.setOnKeyPressed(e -> {
            controller.handleDeleteStudent(e.getCode());
        });
        
        studentTable.setOnMouseClicked(e -> {
            controller.handleEditStudent();
        });
        
        //THE EVENT HANDLERS
        //INIT THE PANES AND ORGANIZE EVERYTHING
        projectBox = new VBox();
        projectTeamsBox = new VBox();
        projectTeamInputPane = new GridPane();
        projectStudentsBox = new VBox();
        projectStudentInputBox = new GridPane();
        
        projectBox.getChildren().add(projectHeaderLabelBox);
        projectBox.getChildren().add(projectTeamsBox);
        projectBox.getChildren().add(projectStudentsBox);
        projectTeamHeaderLabelBox.getChildren().add(projectTeamDeleteButton);
        projectTeamsBox.getChildren().add(projectTeamHeaderLabelBox);
        projectTeamsBox.getChildren().add(teamTable);
        projectTeamsBox.getChildren().add(projectTeamInputPane);
        projectStudentHeaderLabelBox.getChildren().add(projectStudentDeleteButton);
        projectStudentsBox.getChildren().add(projectStudentHeaderLabelBox);
        projectStudentsBox.getChildren().add(studentTable);
        projectStudentsBox.getChildren().add(projectStudentInputBox);
        
        //SET THE INPUT GRID FOR TEAMS
        projectTeamInputPane.add(projectAddEditLabelBox, 0, 0);
        projectTeamInputPane.add(projectNameLabelBox, 0, 1);
        projectTeamInputPane.add(projectColorLabelBox, 0, 2);
        projectTeamInputPane.add(projectLinkLabelBox, 0, 3);
        projectTeamInputPane.add(projectTeamAddAndUpdateButton, 0, 4);
        projectTeamInputPane.add(projectTeamNameField, 1, 1);
        projectTeamInputPane.add(projectTeamColorPicker, 1, 2);
        projectTeamInputPane.add(projectTeamLinkField, 1, 3);
        projectTeamInputPane.add(projectTeamClearButton, 1, 4);
        projectTeamInputPane.add(projectTeamTextColorPicker, 2, 2);
        
        //SET THE INPUT GRID FOR Students
        projectStudentInputBox.add(projectStudentAddEditLabelBox, 0, 0);
        projectStudentInputBox.add(projectFirstNameLabelBox, 0, 1);
        projectStudentInputBox.add(projectLastNameLabelBox, 0, 2);
        projectStudentInputBox.add(projectTeamLabelBox, 0, 3);
        projectStudentInputBox.add(projectRoleLabelBox, 0, 4);
        projectStudentInputBox.add(projectStudentAddAndUpdateButton, 0, 5);
        projectStudentInputBox.add(projectStudentFirstNameField, 1, 1);
        projectStudentInputBox.add(projectStudentLastNameField, 1, 2);
        projectStudentInputBox.add(projectStudentTeamComboBox, 1, 3);
        projectStudentInputBox.add(projectStudentRoleField, 1, 4);
        projectStudentInputBox.add(projectStudentClearButton, 1, 5);
        
        //SET IT IN THE TAB
        projectTab.setContent(projectBox);
        
        //
        //TA DATA TAB
        //
        
        // INIT THE HEADER ON THE LEFT
        tasHeaderBox = new HBox();
        String tasHeaderText = props.getProperty(CSGProp.TAS_HEADER_TEXT.toString());
        tasHeaderLabel = new Label(tasHeaderText);
        tasHeaderBox.getChildren().add(tasHeaderLabel);

        // MAKE THE TABLE AND SETUP THE DATA MODEL
        taTable = new TableView();
        taTable.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        ObservableList<TeachingAssistant> tableData = data.getTeachingAssistants();
        taTable.setItems(tableData);
        String nameColumnText = props.getProperty(CSGProp.NAME_COLUMN_TEXT.toString());
        String emailColumnText = props.getProperty(CSGProp.EMAIL_COLUMN_TEXT.toString());
        String underGradColumnText = props.getProperty(CSGProp.UNDERGRAD_COLUMN_TEXT.toString());
        nameColumn = new TableColumn(nameColumnText);
        emailColumn = new TableColumn(emailColumnText);
        isUndergradColumn = new TableColumn(underGradColumnText);
        nameColumn.setCellValueFactory(
                new PropertyValueFactory<TeachingAssistant, String>("name")
        );
        emailColumn.setCellValueFactory(
                new PropertyValueFactory<TeachingAssistant, String>("email")
        );
        
        isUndergradColumn.setCellValueFactory(
        new Callback<CellDataFeatures<TeachingAssistant, Boolean>, ObservableValue<Boolean>>()
        {
            public ObservableValue<Boolean> call(CellDataFeatures<TeachingAssistant, Boolean> param)
            {
                return param.getValue().undergraduateStudent();
            }
        });
        
        isUndergradColumn.setCellFactory(CheckBoxTableCell.forTableColumn(isUndergradColumn));
        //SET THE UNDO REDO
        isUndergradColumn.setCellFactory(new Callback<TableColumn<TeachingAssistant, Boolean>, TableCell<TeachingAssistant, Boolean>>() {
                    @Override
                    public TableCell<TeachingAssistant, Boolean> call(TableColumn<TeachingAssistant, Boolean> p) {
                        final CheckBoxTableCell ctCell = new CheckBoxTableCell<>();
                        ctCell.setOnMouseEntered(e -> {
                                controller.markWorkAsEdited();
                        });
                        /*
                        ctCell.setOnMouseExited(e -> {
                                //controller.updateTACheck();
                        });
                        */
                        return ctCell;
                    }
                });

        taTable.getColumns().add(isUndergradColumn);
        taTable.getColumns().add(nameColumn);
        taTable.getColumns().add(emailColumn);
        taTable.setEditable(true);
        isUndergradColumn.setEditable(true);

        // ADD BOX FOR ADDING A TA
        String namePromptText = props.getProperty(CSGProp.NAME_PROMPT_TEXT.toString());
        String emailPromptText = props.getProperty(CSGProp.EMAIL_PROMPT_TEXT.toString());
        String addButtonText = props.getProperty(CSGProp.ADD_BUTTON_TEXT.toString());
        String clearButtonText = props.getProperty(CSGProp.CLEAR_BUTTON_TEXT.toString());
        nameTextField = new TextField();
        emailTextField = new TextField();
        nameTextField.setPromptText(namePromptText);
        emailTextField.setPromptText(emailPromptText);
        addButton = new Button(addButtonText);
        clearButton = new Button(clearButtonText);
        taDeleteButton = new Button();
        Image buttonImage5 = new Image(FILE_PROTOCOL + PATH_IMAGES + props.getProperty(CSGProp.DELETE_ICON.toString()));
        taDeleteButton.setGraphic(new ImageView(buttonImage5));
        addBox = new HBox();
        nameTextField.prefWidthProperty().bind(addBox.widthProperty().multiply(.3));
        emailTextField.prefWidthProperty().bind(addBox.widthProperty().multiply(.3));
        addButton.prefWidthProperty().bind(addBox.widthProperty().multiply(.2));
        clearButton.prefWidthProperty().bind(addBox.widthProperty().multiply(.2));
        addBox.getChildren().add(nameTextField);
        addBox.getChildren().add(emailTextField);
        addBox.getChildren().add(addButton);
        addBox.getChildren().add(clearButton);

        // INIT THE HEADER ON THE RIGHT        
        officeHoursHeaderBox = new HBox();
        String officeHoursGridText = props.getProperty(CSGProp.OFFICE_HOURS_SUBHEADER.toString());
        officeHoursHeaderLabel = new Label(officeHoursGridText);
        officeHoursStartLabelBox = new HBox();
        String officeHoursStartText = props.getProperty(CSGProp.START_TEXT.toString());
        officeHoursStartLabel = new Label(officeHoursStartText);
        officeHoursStartLabelBox.getChildren().add(officeHoursStartLabel);
        officeHoursEndLabelBox = new HBox();
        String officeHoursEndText = props.getProperty(CSGProp.END_TEXT.toString());
        officeHoursEndLabel = new Label(officeHoursEndText);
        officeHoursEndLabelBox.getChildren().add(officeHoursEndLabel);
        officeHoursHeaderBox.getChildren().add(officeHoursHeaderLabel);
        officeHoursHeaderBox.getChildren().add(officeHoursStartLabelBox);
        officeHoursHeaderBox.getChildren().add(startHoursComboBox);
        officeHoursHeaderBox.getChildren().add(officeHoursEndLabelBox);
        officeHoursHeaderBox.getChildren().add(endHoursComboBox);
        // THESE WILL STORE PANES AND LABELS FOR OUR OFFICE HOURS GRID
        officeHoursGridPane = new GridPane();
        officeHoursGridTimeHeaderPanes = new HashMap();
        officeHoursGridTimeHeaderLabels = new HashMap();
        officeHoursGridDayHeaderPanes = new HashMap();
        officeHoursGridDayHeaderLabels = new HashMap();
        officeHoursGridTimeCellPanes = new HashMap();
        officeHoursGridTimeCellLabels = new HashMap();
        officeHoursGridTACellPanes = new HashMap();
        officeHoursGridTACellLabels = new HashMap();

        // ORGANIZE THE LEFT AND RIGHT PANES
        VBox leftPane = new VBox();
        tasHeaderBox.getChildren().add(taDeleteButton);
        leftPane.getChildren().add(tasHeaderBox);        
        leftPane.getChildren().add(taTable);
        leftPane.getChildren().add(addBox);
        VBox rightPane = new VBox();
        rightPane.getChildren().add(officeHoursHeaderBox);
        rightPane.getChildren().add(officeHoursGridPane);
        
        // BOTH PANES WILL NOW GO IN A SPLIT PANE
        SplitPane sPane = new SplitPane(leftPane, new ScrollPane(rightPane));
        workspace = new BorderPane();
        
        // AND PUT EVERYTHING IN THE WORKSPACE
        //((BorderPane) workspace).setCenter(sPane);
        taTab.setContent(sPane);
        // AND PUT EVERYTHING IN THE WORKSPACE
        ((BorderPane) workspace).setCenter(tabPane);
        // MAKE SURE THE TABLE EXTENDS DOWN FAR ENOUGH
        taTable.prefHeightProperty().bind(workspace.heightProperty().multiply(1.9));
        
        // ADD THE COMBO BOXES
        //comboBox = new HBox();
        startHoursComboBox.getItems().addAll(data.getAllHours());
        endHoursComboBox.getItems().addAll(data.getAllHours());
        //SET THE DEFAULT VALUE TO THE START AND END TIMES
        startHoursComboBox.getSelectionModel().select(data.getTimeString(data.getStartHour(), data.getStartOnlyHour()));
        endHoursComboBox.getSelectionModel().select(data.getTimeString(data.getEndHour(), data.getEndOnlyHour()));
        
        // NOW LET'S SETUP THE EVENT HANDLING
        controller = new CSGController(app);

        // CONTROLS FOR ADDING TAs
        nameTextField.setOnAction(e -> {
            controller.handleAddTA();
        });
        emailTextField.setOnAction(e -> {
            controller.handleAddTA();
        });
        addButton.setOnAction(e -> {
            controller.handleAddTA();
        });

        taTable.setFocusTraversable(true);
        taTable.setOnKeyPressed(e -> {
            controller.handleKeyPress(e.getCode());
        });
        taTable.setOnMouseClicked(e -> {
            controller.handleEdit();
        });
        //CLEAR BUTTON
        clearButton.setOnAction(e -> {
            controller.clear();
        });
        //CONTROLS FOR DELETING TA
        taDeleteButton.setOnAction(e -> {
            controller.handleKeyPress();
        });
        workspace.setOnKeyPressed(e -> {
            if(e.getCode() == KeyCode.CONTROL)
            {
                controlPressed = true;
            }
            else
            {
                if(e.getCode() == KeyCode.Z)
                {
                    zPressed = true;
                }
                else
                {
                    if(e.getCode() == KeyCode.Y)
                    {
                        yPressed = true;
                    }
                }
            }
            if(zPressed == true && controlPressed == true && yPressed == false)
            {
                //UNDO
                    System.out.println("undo");
                    controller.Undo();
            }
            else
            {
                if(zPressed == false && controlPressed == true && yPressed == true)
                {
                    //REDO
                        System.out.println("redo");
                        controller.Redo();
                }
            }
        });
        workspace.setOnKeyReleased(e -> {
            if(e.getCode() == KeyCode.CONTROL)
            {
                controlPressed = false;
            }
            else
            {
                if(e.getCode() == KeyCode.Z)
                {
                    zPressed = false;
                }
                else
                {
                    if(e.getCode() == KeyCode.Y)
                    {
                        yPressed = false;
                    }
                }
            }
        });
        //COMBO BOX
        startHoursComboBox.getSelectionModel().select(data.getStartHour());
        startHoursComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override public void changed(ObservableValue ov, String t, String t1) {
                if(t != null && t1 != null)
                    /*
                    if(startHoursComboBox.getSelectionModel().getSelectedIndex() != data.getStartHour())
                    */
                    if(startHoursComboBox.getValue().compareTo(data.getTimeString(data.getStartHour(), data.getStartOnlyHour())) != 0)
                        controller.changeTime();
            }
        });
        endHoursComboBox.setPrefWidth(150);
        endHoursComboBox.getSelectionModel().select(data.getEndHour());
        endHoursComboBox.valueProperty().addListener(new ChangeListener<String>() {
            @Override public void changed(ObservableValue ov, String t, String t1) {
                if(t != null && t1 != null)
                    /*
                    if(endHoursComboBox.getSelectionModel().getSelectedIndex() != data.getEndHour())
                    */
                    if(endHoursComboBox.getValue().compareTo(data.getTimeString(data.getEndHour(), data.getEndOnlyHour())) != 0)
                        controller.changeTime();
            }    
        });
        
    }
    
    
    
    // WE'LL PROVIDE AN ACCESSOR METHOD FOR EACH VISIBLE COMPONENT
    // IN CASE A CONTROLLER OR STYLE CLASS NEEDS TO CHANGE IT
    
    //TABPANE
    public TabPane getTabPane() {
        return tabPane;
    }
    
    public Tab getCourseTab() {
        return courseTab;
    }
    
    public Tab getTaTab() {
        return taTab;
    }
    
    public Tab getRecitationTab() {
        return recitationTab;
    }
    
    public Tab getScheduleTab() {
        return scheduleTab;
    }
    
    public Tab getProjectTab() {
        return projectTab;
    }
    
    //COURSE DETAILS TAB
    
    public FlowPane getCourseDetailsBox()
    {
        return courseDetailsBox;
    }
    public GridPane getCourseInfoPane() {
        return courseInfoPane;
    }
    
    public VBox getSiteTemplateBox() {
        return siteTemplateBox;
    }
    
    public GridPane getPageStylePane() {
        return pageStylePane;
    }
    
    public Label getCourseInfoLabel()
    {
        return courseInfoLabel;
    }
    
    public Label getCourseSiteTemplateLabel()
    {
        return courseSiteTemplateLabel;
    }
    
    public Label getCourseExportDirFileLabel()
    {
        return courseExportDirFileLabel;
    }
    
    public Label getPageStyleLabel()
    {
        return coursePageStyleLabel;
    }
    
    public Label getCourseSiteTemplateDirectoryLocationLabel()
    {
        return courseSiteTemplateDirectoryLocationLabel;
    }
    
    public HBox getTAsHeaderBox() {
        return tasHeaderBox;
    }
    
    public Button getCourseSelectTemplateButton() {
        return courseSelectTemplateButton;
    }
    
    public Button getCourseChangeExportDirButton() {
        return courseChangeExportDirButton;
    }
    
    public Button getCourseChangeBannerButton() {
        return courseChangeBannerButton;
    }
    
    public Button getCourseChangeLeftFooterButton() {
        return courseChangeLeftFooterButton;
    }
    
    public Button getCourseChangeRightFooterButton() {
        return courseChangeRightFooterButton;
    }
    
    public TableView getSitePageTable() {
        return sitePageTable;
    }
    
    public ImageView getBannerImageView()
    {
        return bannerImageView;
    }
    
    public ImageView getLeftbannerImageView()
    {
        return bannerLeftImageView;
    }
    
    public ImageView getRightbannerImageView()
    {
        return bannerRightImageView;
    }
    
    //RECITATION TAB
    
    public VBox getRecitationDataPane() {
        return recitationDataPane;
    }
    
    public Pane getRecitationAddEditPane() {
        return recitationAddEditPane;
    }
    
    public GridPane getReciationAddEditFieldsPane() {
        return reciationAddEditFieldsPane;
    }
    
    public Button getRecitationAddUpdateButton() {
        return recitationAddUpdateButton;
    }
    
    public Button getRecitationClearButton() {
        return recitationClearButton;
    }
    
    public Label getRecitationHeaderLabel() {
        return recitationHeaderLabel;
    }
    
    public Label getRecitationAddEditHeaderLabel() {
        return recitationAddEditHeaderLabel;
    }
    
    public TextField getRecitationSectionField()
    {
        return recitationSectionField;
    }
    
    public TextField getRecitationInstructorField()
    {
        return recitationInstructorField;
    }
    
    public TextField getRecitationDayTimeField()
    {
        return recitationDayTimeField;
    }
    
    public TextField getRecitationLocationField()
    {
        return recitationLocationField;
    }
    
    public TableView getRecitationTable() {
        return recitationTable;
    }
    
    public ComboBox getRecitationTA1() {
        return recitationTA1;
    }
    
    public ComboBox getRecitationTA2() {
        return recitationTA2;
    }
    
    public Button recitationAddUpdateButton() {
        return recitationAddUpdateButton;
    }
    
    public VBox getScheduleBox() {
        return scheduleBox;
    }
    
    public VBox getScheduleTopBox() {
        return scheduleTopBox;
    }
    
    public HBox getScheduleTopBoxHorizontal() {
        return scheduleTopBoxHorizontal;
    }
    
    public VBox getScheduleItemsBox() {
        return scheduleItemsBox;
    }
    
    public GridPane getScheduleInputPane() {
        return scheduleInputPane;
    }
    
    public Label getScheduleHeaderLabel() {
        return scheduleHeaderLabel;
    }
    
    public Label getScheduleCalendarBoundariesLabel() {
        return scheduleCalendarBoundariesLabel;
    }
    
    public Label getScheduleItemsLabel() {
        return scheduleItemsLabel;
    }
    
    public Label getScheduleAddAndEditLabel() {
        return scheduleAddAndEditLabel;
    }
    
    public Button getScheduleAddUpdateButton() {
        return scheduleAddUpdateButton;
    }
    
    public Button getScheduleClearButton() {
        return scheduleClearButton;
    }
    
    public TextField getScheduleTimeField()
    {
        return scheduleTimeField;
    }
    
    public TextField getScheduleTitleField()
    {
        return scheduleTitleField;
    }
    
    public TextField getScheduleTopicField()
    {
        return scheduleTopicField;
    }
    
    public TextField getScheduleLinkField()
    {
        return scheduleLinkField;
    }
    
    public TextField getScheduleCriteriaField()
    {
        return scheduleCriteriaField;
    }
    
    public DatePicker getScheduleDateDatePicker()
    {
        return scheduleDateDatePicker;
    }
    
    public ComboBox getScheduleTypeComboBox()
    {
        return scheduleTypeComboBox;
    }
    
    public TableView getScheduleTable()
    {
        return scheduleTable;
    }
    
    public DatePicker getStartingMonday()
    {
        return startingMonday;
    }
    
    public DatePicker getEndingFriday()
    {
        return endingFriday;
    }
    //PROJECT TAB
    
    public VBox getProjectBox()
    {
        return projectBox;
    }
    
    public VBox getProjectTeamsBox()
    {
        return projectTeamsBox;
    }
    
    public GridPane getProjectTeamInputPane()
    {
        return projectTeamInputPane;
    }
    
    public VBox getProjectStudentsBox()
    {
        return projectStudentsBox;
    }
    
    public GridPane getProjectStudentInputBox()
    {
        return projectStudentInputBox;
    }
    
    public Label getProjectHeaderLabel()
    {
        return projectHeaderLabel;
    }
    
    public Label getProjectTeamHeaderLabel()
    {
        return projectTeamHeaderLabel;
    }
    
    public Label getProjectAddEditLabel()
    {
        return projectAddEditLabel;
    }
    
    public Label getProjectStudentHeaderLabel()
    {
        return projectStudentHeaderLabel;
    }
    
    public Label getProjectStudentAddEditLabel()
    {
        return projectStudentAddEditLabel;
    }
    
    public Button getProjectTeamAddAndUpdateButton()
    {
        return projectTeamAddAndUpdateButton;
    }
    
    public Button getProjectTeamClearButton()
    {
        return projectTeamClearButton;
    }
    
    public Button getProjectStudentAddAndUpdateButton()
    {
        return projectStudentAddAndUpdateButton;
    }
    
    public Button getProjectStudentClearButton()
    {
        return projectStudentClearButton;
    }
    
    public TextField getProjectTeamNameField()
    {
        return projectTeamNameField;
    }
    
    public TextField getProjectTeamLinkField()
    {
        return projectTeamLinkField;
    }
    
    public TextField getProjectStudentFirstNameField()
    {
        return projectStudentFirstNameField;
    }
    
    public TextField getProjectStudentLastNameField()
    {
        return projectStudentLastNameField;
    }
    
    public TextField getProjectStudentRoleField()
    {
        return projectStudentRoleField;
    }
    
    public ColorPicker getProjectTeamColorPicker()
    {
        return projectTeamColorPicker;
    }
    
    public ColorPicker getProjectTeamTextColorPicker()
    {
        return projectTeamTextColorPicker;
    }
    
    public TableView getTeamTable()
    {
        return teamTable;
    }
    
    public ComboBox getProjectStudentTeamComboBox()
    {
        return projectStudentTeamComboBox;
    }
    
    public TableView getStudentTable()
    {
        return studentTable;
    }
    
    //TA TAB
    public Label getTAsHeaderLabel() {
        return tasHeaderLabel;
    }

    public TableView getTATable() {
        return taTable;
    }

    public HBox getAddBox() {
        return addBox;
    }

    public TextField getNameTextField() {
        return nameTextField;
    }

    public TextField getEmailTextField() {
        return emailTextField;
    }

    public Button getAddButton() {
        return addButton;
    }
    
    public Button getClearButton()
    {
        return clearButton;
    }
    
    public ComboBox getOfficeHour(boolean start){
        if(start)
            return startHoursComboBox;
        return endHoursComboBox;
    }

    public HBox getOfficeHoursSubheaderBox() {
        return officeHoursHeaderBox;
    }

    public Label getOfficeHoursSubheaderLabel() {
        return officeHoursHeaderLabel;
    }
    
    public Label getOfficeHoursEndLabel() {
        return officeHoursEndLabel;
    }
    
    public Label getOfficeHourStartLabel() {
        return officeHoursStartLabel;
    }

    public GridPane getOfficeHoursGridPane() {
        return officeHoursGridPane;
    }

    public HashMap<String, Pane> getOfficeHoursGridTimeHeaderPanes() {
        return officeHoursGridTimeHeaderPanes;
    }

    public HashMap<String, Label> getOfficeHoursGridTimeHeaderLabels() {
        return officeHoursGridTimeHeaderLabels;
    }

    public HashMap<String, Pane> getOfficeHoursGridDayHeaderPanes() {
        return officeHoursGridDayHeaderPanes;
    }

    public HashMap<String, Label> getOfficeHoursGridDayHeaderLabels() {
        return officeHoursGridDayHeaderLabels;
    }

    public HashMap<String, Pane> getOfficeHoursGridTimeCellPanes() {
        return officeHoursGridTimeCellPanes;
    }

    public HashMap<String, Label> getOfficeHoursGridTimeCellLabels() {
        return officeHoursGridTimeCellLabels;
    }

    public HashMap<String, Pane> getOfficeHoursGridTACellPanes() {
        return officeHoursGridTACellPanes;
    }

    public HashMap<String, Label> getOfficeHoursGridTACellLabels() {
        return officeHoursGridTACellLabels;
    }
    
    public String getCellKey(Pane testPane) {
        for (String key : officeHoursGridTACellLabels.keySet()) {
            if (officeHoursGridTACellPanes.get(key) == testPane) {
                return key;
            }
        }
        return null;
    }

    public Label getTACellLabel(String cellKey) {
        return officeHoursGridTACellLabels.get(cellKey);
    }

    public Pane getTACellPane(String cellPane) {
        return officeHoursGridTACellPanes.get(cellPane);
    }

    public String buildCellKey(int col, int row) {
        return "" + col + "_" + row;
    }

    public String buildCellText(int militaryHour, String minutes) {
        // FIRST THE START AND END CELLS
        int hour = militaryHour;
        if (hour > 12) {
            hour -= 12;
        }
        String cellText = "" + hour + ":" + minutes;
        if (militaryHour < 12) {
            cellText += "am";
        } else {
            cellText += "pm";
        }
        return cellText;
    }
    
    public void checkValidHours()
    {
        CSGData data = (CSGData) app.getDataComponent();
        String startComboBoxHour = startHoursComboBox.getValue();
        String endComboBoxHour = endHoursComboBox.getValue();
        int startIndex = 0;
        int endIndex = 0;
        for(int i = 0; i < data.getAllHours().size(); i++)
        {
            if(data.getAllHours().get(i).compareTo(startComboBoxHour) == 0)
            {
                startIndex = i;
            }
            if(data.getAllHours().get(i).compareTo(endComboBoxHour) == 0)
            {
                endIndex = i;
            }
        }
        if(startIndex < endIndex)
        {
            comboButton.setDisable(false);
        }
        else
        {
            comboButton.setDisable(true);
        }
    }

    @Override
    public void resetWorkspace() {
        // CLEAR OUT THE GRID PANE
        officeHoursGridPane.getChildren().clear();
        
        // AND THEN ALL THE GRID PANES AND LABELS
        officeHoursGridTimeHeaderPanes.clear();
        officeHoursGridTimeHeaderLabels.clear();
        officeHoursGridDayHeaderPanes.clear();
        officeHoursGridDayHeaderLabels.clear();
        officeHoursGridTimeCellPanes.clear();
        officeHoursGridTimeCellLabels.clear();
        officeHoursGridTACellPanes.clear();
        officeHoursGridTACellLabels.clear();
    }
    
    @Override
    public void reloadWorkspace(AppDataComponent dataComponent) {
        CSGData data = (CSGData)dataComponent;
        //reloadOfficeHoursGrid(taData);
        comboBoxUpdateOfficeHoursGrid(data);
        //RELOAD THE COMBOBOXES
        courseSubjectComboBox.getSelectionModel().select(data.getSubject());
        courseNumberComboBox.getSelectionModel().select(data.getNumber() + "");
        courseSemesterComboBox.getSelectionModel().select(data.getSemester());
        courseYearComboBox.getSelectionModel().select(data.getYear() + "");
        courseStyleSheetComboBox.getSelectionModel().select(data.getStylesheet());
        //RELOAD TEXT FIELDS
        courseTitleField.setPromptText(data.getTitle());
        courseInstructorHomeField.setPromptText(data.getInstructorHome());
        courseInstructorNameField.setPromptText(data.getInstructorName());
        //RELOAD THE LABELS
        courseExportDirFileLabel.setText(data.getExportDir());
        courseSiteTemplateDirectoryLocationLabel.setText(data.getSiteTemplate());
        try {
            //RELOAD THE IMAGES
            bannerImageView.setImage(new Image(new File(data.getBannerSchoolImage()).toURI().toURL().toExternalForm()));
        } catch (MalformedURLException ex) {
            System.out.println("MalformedUrl");
        }
        try {
            bannerLeftImageView.setImage(new Image(new File(data.getBannerLeftFooterImage()).toURI().toURL().toExternalForm()));
        } catch (MalformedURLException ex) {
             System.out.println("MalformedUrl");
        }
        try {
            bannerRightImageView.setImage(new Image(new File(data.getBannerRightFooterImage()).toURI().toURL().toExternalForm()));
        } catch (MalformedURLException ex) {
            System.out.println("MalformedUrl");
        }
        //CLEAR EVERYTHING IN INPUT
        controller.clear();
        controller.clearRecitation();
        controller.clearSchedule();
        controller.clearTeam();
        controller.clearStudent();
        //RELOAD THE RECITATION COMBOBOXES
        recitationTA1.getItems().addAll(data.getTeachingAssistants());
        recitationTA2.getItems().addAll(data.getTeachingAssistants());
        projectStudentTeamComboBox.getItems().addAll(data.getTeams());
        //RELOAD THE STARTING MONDAY AND ENDING FRIDAY
        startingMonday.setValue(data.getStartingMonday());
        endingFriday.setValue(data.getEndingFriday());
        //INITIALIZE UNDO REDO
        controller.initializeButtons();
    }
    public void comboReloadWorkspace(AppDataComponent dataComponent) {
        CSGData taData = (CSGData)dataComponent;
        comboBoxUpdateOfficeHoursGrid(taData);
    }

    public void reloadOfficeHoursGrid(CSGData dataComponent) {
        ArrayList<String> gridHeaders = dataComponent.getGridHeaders();

        // ADD THE TIME HEADERS
        for (int i = 0; i < 2; i++) {
            addCellToGrid(dataComponent, officeHoursGridTimeHeaderPanes, officeHoursGridTimeHeaderLabels, i, 0);
            dataComponent.getCellTextProperty(i, 0).set(gridHeaders.get(i));
        }
        
        // THEN THE DAY OF WEEK HEADERS
        for (int i = 2; i < 7; i++) {
            addCellToGrid(dataComponent, officeHoursGridDayHeaderPanes, officeHoursGridDayHeaderLabels, i, 0);
            dataComponent.getCellTextProperty(i, 0).set(gridHeaders.get(i));            
        }
        
        // THEN THE TIME AND TA CELLS
        int row = 1;
        for (int i = dataComponent.getStartHour(); i < dataComponent.getEndHour(); i++) {
            // START TIME COLUMN
            int col = 0;
            
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(i, "00"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(i, "30"));
            

            // END TIME COLUMN
            col++;
            int endHour = i;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(endHour, "30"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(endHour+1, "00"));
            col++;

            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row+1);
                col++;
            }
            row += 2;
        }

        // CONTROLS FOR TOGGLING TA OFFICE HOURS
        for (Pane p : officeHoursGridTACellPanes.values()) {
            p.setFocusTraversable(true);
            p.setOnKeyPressed(e -> {
                controller.handleKeyPress(e.getCode());
            });
            p.setOnMouseClicked(e -> {
                controller.handleCellToggle((Pane) e.getSource());
            });
            p.setOnMouseExited(e -> {
                controller.handleGridCellMouseExited((Pane) e.getSource());
            });
            p.setOnMouseEntered(e -> {
                controller.handleGridCellMouseEntered((Pane) e.getSource());
            });
        }
        
        // AND MAKE SURE ALL THE COMPONENTS HAVE THE PROPER STYLE
        CSGStyle CSGStyle = (CSGStyle)app.getStyleComponent();
        CSGStyle.initTabPaneStyle();
        CSGStyle.initCourseDetailsStyle();
        CSGStyle.initOfficeHoursGridStyle();
        CSGStyle.initRecitationStyle();
        CSGStyle.initScheduleStyle();
        CSGStyle.initProjectStyle();
    }
    
    public void comboBoxUpdateOfficeHoursGrid(CSGData dataComponent) 
    {
        //CLEAR REMNANTS OF PANES
        officeHoursGridPane.getChildren().clear();
        ArrayList<String> gridHeaders = dataComponent.getGridHeaders();
        // ADD THE TIME HEADERS
        for (int i = 0; i < 2; i++) {
            addCellToGrid(dataComponent, officeHoursGridTimeHeaderPanes, officeHoursGridTimeHeaderLabels, i, 0);
            dataComponent.getCellTextProperty(i, 0).set(gridHeaders.get(i));
        }
        
        // THEN THE DAY OF WEEK HEADERS
        for (int i = 2; i < 7; i++) {
            addCellToGrid(dataComponent, officeHoursGridDayHeaderPanes, officeHoursGridDayHeaderLabels, i, 0);
            dataComponent.getCellTextProperty(i, 0).set(gridHeaders.get(i));            
        }
        
        int row = 1;
        int startIndexNumber = 0;
        int endIndexNumber = 48;
        
        for(int i = 0; i < dataComponent.getAllHours().size(); i++)
        {
            if(dataComponent.getAllHours().get(i).compareTo(dataComponent.getTimeString(dataComponent.getStartHour(), dataComponent.getStartOnlyHour())) == 0)
            {
                startIndexNumber = i;
            }
        }
        for(int l = 0; l < dataComponent.getAllHours().size(); l++)
        {
            if(dataComponent.getAllHours().get(l).compareTo(dataComponent.getTimeString(dataComponent.getEndHour(), dataComponent.getEndOnlyHour())) == 0)
            {
                endIndexNumber = l;
            }
        }
        /*
        for(int i = startIndexNumber; i < endIndexNumber - 1; i++)
        {
            //START TIME COLUMN
            int col = 0;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(dataComponent.getAllHours().get(i));
            row++;
        }
        row = 1;
        for(int i = startIndexNumber + 1; i <= endIndexNumber - 1; i++)
        {
            // END TIME COLUMN
            int col = 1;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(dataComponent.getAllHours().get(i + 1));
            row++;
        }
        int col = 3;
        row = 1;
            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                col++;
            }
            row += 1;
        */
        
        for(int i = startIndexNumber; i <= endIndexNumber - 1; i++)
        {
            //START TIME COLUMN
            int col = 0;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(dataComponent.getAllHours().get(i));
            
            // END TIME COLUMN
            col++;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(dataComponent.getAllHours().get(i + 1));
            col++;
            
            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                col++;
            }
            row += 1;
        }
        
         /*
        for(int i = startIndexNumber; i < endIndexNumber - 2; i++)
        {
            //START TIME COLUMN
            int col = 0;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(dataComponent.getAllHours().get(i));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(dataComponent.getAllHours().get(i + 1));
            
            // END TIME COLUMN
            col++;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(dataComponent.getAllHours().get(i + 1));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(dataComponent.getAllHours().get(i + 2));
            col++;
            
            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row+1);
                col++;
            }
            row += 2;
        }
         */
         // CONTROLS FOR TOGGLING TA OFFICE HOURS
        for (Pane p : officeHoursGridTACellPanes.values()) {
            p.setFocusTraversable(true);
            //SET THE BACKGROUND COLOR
            p.setStyle("-fx-background-color: #e6e6e6;");
            p.setOnKeyPressed(e -> {
                CSGData data = (CSGData) app.getDataComponent();
                controller.handleKeyPress(e.getCode());
            });
            p.setOnMouseClicked(e -> {
                CSGData data = (CSGData) app.getDataComponent();
                controller.handleCellToggle((Pane) e.getSource());
            });
            p.setOnMouseExited(e -> {
                controller.handleGridCellMouseExited((Pane) e.getSource());
            });
            p.setOnMouseEntered(e -> {
                controller.handleGridCellMouseEntered((Pane) e.getSource());
            });
        }
        
        // AND MAKE SURE ALL THE COMPONENTS HAVE THE PROPER STYLE
        CSGStyle taStyle = (CSGStyle)app.getStyleComponent();
        taStyle.initOfficeHoursGridStyle();
        
        /*
        // THEN THE TIME AND TA CELLS
        int row = 1;
        //ADD START HOUR IN CASE IT IS ON A HOUR
        if(dataComponent.getStartOnlyHour() == true)
        {
            // START TIME COLUMN
            int col = 0;
            
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(dataComponent.getStartHour(), "00"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(dataComponent.getStartHour(), "30"));
            

            // END TIME COLUMN
            col++;
            int endHour = dataComponent.getStartHour();
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(endHour, "30"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(endHour+1, "00"));
            col++;

            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row+1);
                col++;
            }
            row += 2;
        }
        else
        {
            int col = 0;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(dataComponent.getStartHour(), "30"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(dataComponent.getStartHour(), "00"));
            
            // END TIME COLUMN
            col++;
            int endHour = dataComponent.getStartHour();
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(endHour, "00"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(endHour+1, "30"));
            col++;
            
            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row+1);
                col++;
            }
            row += 2;
        }
        for (int i = dataComponent.getStartHour() + 1; i < dataComponent.getEndHour(); i++) {
            // START TIME COLUMN
            int col = 0;
            
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(i, "00"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(i, "30"));
            

            // END TIME COLUMN
            col++;
            int endHour = i;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(endHour, "30"));
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(endHour+1, "00"));
            col++;

            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row+1);
                col++;
            }
            row += 2;
        }
        //IF THE END HOURS IS NOT EXACTLY AN HOUR
        
        if(dataComponent.getEndOnlyHour() == false)
        {
            int col = 0;
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row);
            dataComponent.getCellTextProperty(col, row).set(buildCellText(dataComponent.getEndHour() - 1, "00"));
            
            // END TIME COLUMN
            col++;
            int endHour = dataComponent.getEndHour();
            addCellToGrid(dataComponent, officeHoursGridTimeCellPanes, officeHoursGridTimeCellLabels, col, row+1);
            dataComponent.getCellTextProperty(col, row+1).set(buildCellText(endHour + 1, "30"));
            col++;
            
            // AND NOW ALL THE TA TOGGLE CELLS
            while (col < 7) {
                addCellToGrid(dataComponent, officeHoursGridTACellPanes, officeHoursGridTACellLabels, col, row);
                col++;
            }
            row += 1;
        }

        // CONTROLS FOR TOGGLING TA OFFICE HOURS
        for (Pane p : officeHoursGridTACellPanes.values()) {
            p.setFocusTraversable(true);
            p.setOnKeyPressed(e -> {
                controller.handleKeyPress(e.getCode());
            });
            p.setOnMouseClicked(e -> {
                controller.handleCellToggle((Pane) e.getSource());
            });
            p.setOnMouseExited(e -> {
                controller.handleGridCellMouseExited((Pane) e.getSource());
            });
            p.setOnMouseEntered(e -> {
                controller.handleGridCellMouseEntered((Pane) e.getSource());
            });
        }
        
        // AND MAKE SURE ALL THE COMPONENTS HAVE THE PROPER STYLE
        CSGStyle taStyle = (CSGStyle)app.getStyleComponent();
        taStyle.initOfficeHoursGridStyle();
*/
        //SET THE DEFAULT VALUE TO THE START AND END TIMES
        startHoursComboBox.getSelectionModel().select(dataComponent.getTimeString(dataComponent.getStartHour(), dataComponent.getStartOnlyHour()));
        endHoursComboBox.getSelectionModel().select(dataComponent.getTimeString(dataComponent.getEndHour(), dataComponent.getEndOnlyHour()));
    }
    
    public void addCellToGrid(CSGData dataComponent, HashMap<String, Pane> panes, HashMap<String, Label> labels, int col, int row) {       
        // MAKE THE LABEL IN A PANE
        Label cellLabel = new Label("");
        HBox cellPane = new HBox();
        cellPane.setAlignment(Pos.CENTER);
        cellPane.getChildren().add(cellLabel);

        // BUILD A KEY TO EASILY UNIQUELY IDENTIFY THE CELL
        String cellKey = dataComponent.getCellKey(col, row);
        cellPane.setId(cellKey);
        cellLabel.setId(cellKey);
        
        // NOW PUT THE CELL IN THE WORKSPACE GRID
        officeHoursGridPane.add(cellPane, col, row);
        
        // AND ALSO KEEP IN IN CASE WE NEED TO STYLIZE IT
        panes.put(cellKey, cellPane);
        labels.put(cellKey, cellLabel);
        
        // AND FINALLY, GIVE THE TEXT PROPERTY TO THE DATA MANAGER
        // SO IT CAN MANAGE ALL CHANGES
        dataComponent.setCellProperty(col, row, cellLabel.textProperty());        
    }
}
