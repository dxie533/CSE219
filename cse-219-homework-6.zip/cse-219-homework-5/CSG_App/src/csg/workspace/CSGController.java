package csg.workspace;

import TATransactions.AddToTA_Transaction;
import TATransactions.AddToTA_UpdateTransaction;
import TATransactions.TAUpdateState;
import TATransactions.WorkState;
import djf.controller.AppFileController;
import djf.ui.AppGUI;
import static csg.CSGProp.*;
import djf.ui.AppMessageDialogSingleton;
import java.util.Collections;
import java.util.HashMap;
import java.util.regex.*;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import properties_manager.PropertiesManager;
import csg.CSGApp;
import csg.CSGProp;
import csg.data.CSGData;
import csg.data.Page;
import csg.data.Recitation;
import csg.data.Schedule;
import csg.data.Student;
import csg.data.TeachingAssistant;
import csg.data.Team;
import csg.file.TimeSlot;
import csg.jtps.BannerImageChangeState;
import csg.jtps.BannerLeftImageChangeState;
import csg.jtps.BannerRightImageChangeState;
import csg.jtps.ExportDirectoryChangeState;
import csg.jtps.RecitationAddState;
import csg.jtps.RecitationDeleteState;
import csg.jtps.RecitationReplaceState;
import csg.jtps.ScheduleAddState;
import csg.jtps.ScheduleDeleteState;
import csg.jtps.ScheduleEndingFridayState;
import csg.jtps.ScheduleReplaceState;
import csg.jtps.ScheduleStartingMondayState;
import csg.jtps.SiteCheckState;
import csg.jtps.StudentAddState;
import csg.jtps.StudentDeleteState;
import csg.jtps.StudentReplaceState;
import csg.jtps.TAAddState;
import csg.jtps.TACheckState;
import csg.jtps.TADeleteState;
import csg.jtps.TAHoursChangeState;
import csg.jtps.TAReplaceState;
import csg.jtps.TAToggleState;
import csg.jtps.TeamAddState;
import csg.jtps.TeamDeleteState;
import csg.jtps.TeamReplaceState;
import csg.jtps.TemplateDirectoryChangeState;
import csg.style.CSGStyle;
import static csg.style.CSGStyle.CLASS_HIGHLIGHTED_GRID_CELL;
import static csg.style.CSGStyle.CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN;
import static csg.style.CSGStyle.CLASS_OFFICE_HOURS_GRID_TA_CELL_PANE;
import csg.workspace.CSGWorkspace;
import djf.components.AppDataComponent;
import static djf.settings.AppPropertyType.COMBO_BOX_MESSAGE;
import static djf.settings.AppPropertyType.COMBO_BOX_TITLE;
import static djf.settings.AppPropertyType.LOAD_ERROR_MESSAGE;
import static djf.settings.AppStartupConstants.PATH_WORK;
import djf.ui.AppYesNoCancelDialogSingleton;
import java.io.File;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import javafx.scene.control.ComboBox;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import jtps.jTPS;
import jtps.jTPS_Transaction;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class CSGController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    CSGApp app;
    PropertiesManager props = PropertiesManager.getPropertiesManager();
    //FOR UNDO REDO
    static jTPS jTPSThingy = new jTPS();

    /**
     * Constructor, note that the app must already be constructed.
     */
    public CSGController(CSGApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    /**
     * This helper method should be called every time an edit happens.
     */    
    public void markWorkAsEdited() {
        // MARK WORK AS EDITED
        AppGUI gui = app.getGUI();
        gui.getFileController().markAsEdited(gui);
    }
    
    public void noUndo()
    {
        AppGUI gui = app.getGUI();
        gui.getFileController().disableUndo(gui);
    }
    
    public void yesUndo()
    {
        AppGUI gui = app.getGUI();
        gui.getFileController().enableUndo(gui);
    }
    
    public void noRedo()
    {
        AppGUI gui = app.getGUI();
        gui.getFileController().disableRedo(gui);
    }
    
    public void yesRedo()
    {
        AppGUI gui = app.getGUI();
        gui.getFileController().endableRedo(gui);
    }
    
    /**
     * This method responds to when the user requests to add
     * a new TA via the UI. Note that it must first do some
     * validation to make sure a unique name and email address
     * has been provided.
     */
    public void handleAddTA() {
        // WE'LL NEED THE WORKSPACE TO RETRIEVE THE USER INPUT VALUES
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TextField nameTextField = workspace.getNameTextField();
        TextField emailTextField = workspace.getEmailTextField();
        String name = nameTextField.getText();
        String email = emailTextField.getText();
        String validEmailRegex = props.getProperty(CSGProp.EMAIL_VERIFICATION_REGEX.toString());
        Pattern checkRegexExpression = Pattern.compile(validEmailRegex);
        Matcher matchIt = checkRegexExpression.matcher(email);
        
        
        
        // WE'LL NEED TO ASK THE DATA SOME QUESTIONS TOO
        CSGData data = (CSGData)app.getDataComponent();
        
        // WE'LL NEED THIS IN CASE WE NEED TO DISPLAY ANY ERROR MESSAGES
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // DID THE USER NEGLECT TO PROVIDE A TA NAME?
        if (name.isEmpty()) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(MISSING_TA_NAME_TITLE), props.getProperty(MISSING_TA_NAME_MESSAGE));            
        }
        // DID THE USER NEGLECT TO PROVIDE A TA EMAIL?
        else if (email.isEmpty()) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(MISSING_TA_EMAIL_TITLE), props.getProperty(MISSING_TA_EMAIL_MESSAGE));                        
        }
        // DOES A TA ALREADY HAVE THE SAME NAME OR EMAIL?
        else if (data.containsTA(name, email)) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(TA_NAME_AND_EMAIL_NOT_UNIQUE_TITLE), props.getProperty(TA_NAME_AND_EMAIL_NOT_UNIQUE_MESSAGE));                                    
        }
        //IS THE EMAIL VALID?
        else if(!matchIt.matches())
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(TA_EMAIL_INVALID_TITLE), props.getProperty(TA_EMAIL_INVALID_MESSAGE));
        }
        // EVERYTHING IS FINE, ADD A NEW TA
        else {
            // ADD THE NEW TA TO THE DATA
            //data.addTA(name, email, false);
            jTPS_Transaction addTAState = new TAAddState(app);
            jTPSThingy.addTransaction(addTAState);
            
            // CLEAR THE TEXT FIELDS
            nameTextField.setText("");
            emailTextField.setText("");
            
            // AND SEND THE CARET BACK TO THE NAME TEXT FIELD FOR EASY DATA ENTRY
            nameTextField.requestFocus();
            
            checkUndoRedo();
            // WE'VE CHANGED STUFF
            markWorkAsEdited();
        }
    }
    
    public void handleAddRecitation() {
        // WE'LL NEED THE WORKSPACE TO RETRIEVE THE USER INPUT VALUES
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TextField dayTimeTextField = workspace.getRecitationDayTimeField();
        TextField instructorTextField = workspace.getRecitationInstructorField();
        TextField locationTextField = workspace.getRecitationLocationField();
        TextField sectionTextField = workspace.getRecitationSectionField();
        String dayTime = dayTimeTextField.getText();
        String instructor = instructorTextField.getText();
        String location = locationTextField.getText();
        String section = sectionTextField.getText();
        if(workspace.getRecitationTA1().getValue() != null)
        {
            String taOne = workspace.getRecitationTA1().getValue().toString();
        }
        else
        {
            String taOne = "";
        }
        if(workspace.getRecitationTA2().getValue() != null)
        {
            String taTwo = workspace.getRecitationTA2().getValue().toString();
        }
        else
        {
            String taTwo = "";
        }
        
        // WE'LL NEED TO ASK THE DATA SOME QUESTIONS TOO
        CSGData data = (CSGData)app.getDataComponent();
        
        // WE'LL NEED THIS IN CASE WE NEED TO DISPLAY ANY ERROR MESSAGES
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // DID THE USER NEGLECT TO PROVIDE A RECITATION SECTION?
        if (section.isEmpty()) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(MISSING_RECITATION_SECTION_TITLE), props.getProperty(MISSING_RECITATION_SECTION_MESSAGE));
        }
        // DID THE USER NEGLECT TO PROVIDE A RECITATION LOCATION?
        else if (location.isEmpty()) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(MISSING_RECITATION_LOCATION_TITLE), props.getProperty(MISSING_RECITATION_LOCATION_MESSAGE));                        
        }
        // DID THE USER NEGLECT TO PROVIDE A RECITATION TIME?
        else if (dayTime.isEmpty()) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(MISSING_RECITATION_DAYTIME_TITLE), props.getProperty(MISSING_RECITATION_DAYTIME_MESSAGE));                        
        }
        // DOES A RECITATION ALREADY HAVE THE SAME SECTION?
        else if (data.containsRecitation(section)) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(RECITATION_SECTION_NOT_UNIQUE_TITLE), props.getProperty(RECITATION_SECTION_NOT_UNIQUE_MESSAGE));                                    
        }
        // EVERYTHING IS FINE, ADD A NEW RECITATION
        else {
            // ADD THE NEW RECITATION TO THE DATA
            jTPS_Transaction addRecitationState = new RecitationAddState(app);
            jTPSThingy.addTransaction(addRecitationState);
            
            // CLEAR THE TEXT FIELDS
            dayTimeTextField.setText("");
            instructorTextField.setText("");
            locationTextField.setText("");
            sectionTextField.setText("");
            // CLEAR THE COMBO BOXES
            workspace.getRecitationTA1().getSelectionModel().clearSelection();
            workspace.getRecitationTA2().getSelectionModel().clearSelection();
            
            // AND SEND THE CARET BACK TO THE SECTION TEXT FIELD FOR EASY DATA ENTRY
            sectionTextField.requestFocus();
            
            checkUndoRedo();
            
            // WE'VE CHANGED STUFF
            markWorkAsEdited();
        }
    }
    public void handleAddSchedule() {
        // WE'LL NEED THE WORKSPACE TO RETRIEVE THE USER INPUT VALUES
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TextField timeTextField = workspace.getScheduleTimeField();
        TextField titleTextField = workspace.getScheduleTitleField();
        TextField topicTextField = workspace.getScheduleTopicField();
        TextField linkTextField = workspace.getScheduleLinkField();
        TextField criteriaTextField = workspace.getScheduleCriteriaField();
        LocalDate date = workspace.getScheduleDateDatePicker().getValue();
        String time = timeTextField.getText();
        String title = titleTextField.getText();
        String topic = topicTextField.getText();
        String link = linkTextField.getText();
        String criteria = criteriaTextField.getText();
        String type = "";
        if(workspace.getScheduleTypeComboBox().getValue() != null)
        {
            type = workspace.getScheduleTypeComboBox().getValue().toString();
        }
        // WE'LL NEED TO ASK THE DATA SOME QUESTIONS TOO
        CSGData data = (CSGData)app.getDataComponent();
        
        // WE'LL NEED THIS IN CASE WE NEED TO DISPLAY ANY ERROR MESSAGES
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // CHECK EVEEYTHING
        // DID THE USER NEGLECT TO PROVIDE A SCHEDULE TYPE?
        if(type.compareTo("") == 0)
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_SCHEDULE_TYPE_TITLE), props.getProperty(MISSING_SCHEDULE_TYPE_MESSAGE));
            return;
        }
        // DID THE USER NEGLECT TO PROVIDE A SCHEDULE DATE?
        if(date == null)
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_SCHEDULE_DATE_TITLE), props.getProperty(MISSING_SCHEDULE_DATE_MESSAGE));
            return;
        }
        // DID THE USER NEGLECT TO PROVIDE VALID SCHEDULE DATA?
        if(type.compareTo("Lecture") == 0)
        {
            if(title.isEmpty())
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                return;
            }
            else
            {
                if(topic.isEmpty())
                {
                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                    dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                    return;
                }
                else
                {
                    if(link.isEmpty())
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_SCHEDULE_LINK_TITLE), props.getProperty(MISSING_SCHEDULE_LINK_MESSAGE));
                        return;
                    }
                }
            }
        }
        
        if(type.compareTo("Reference") == 0)
        {
            if(title.isEmpty())
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                return;
            }
            else
            {
                if(topic.isEmpty())
                {
                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                    dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                    return;
                }
                else
                {
                    if(link.isEmpty())
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_SCHEDULE_LINK_TITLE), props.getProperty(MISSING_SCHEDULE_LINK_MESSAGE));
                        return;
                    }
                }
            }
        }
        
        if(type.compareTo("Recitation") == 0)
        {
            if(title.isEmpty())
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                return;
            }
            else
            {
                if(topic.isEmpty())
                {
                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                    dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                    return;
                }
            }
        }
        
        if(type.compareTo("Homework") == 0)
        {
            if(title.isEmpty())
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                return;
            }
            else
            {
                if(topic.isEmpty())
                {
                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                    dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                    return;
                }
                else
                {
                    if(link.isEmpty())
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_SCHEDULE_LINK_TITLE), props.getProperty(MISSING_SCHEDULE_LINK_MESSAGE));
                        return;
                    }
                    else
                    {
                        if(time.isEmpty())
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(MISSING_SCHEDULE_TIME_TITLE), props.getProperty(MISSING_SCHEDULE_TIME_MESSAGE));
                            return;
                        }
                        else
                        {
                            if(criteria.isEmpty())
                            {
                                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                dialog.show(props.getProperty(MISSING_SCHEDULE_CRITERIA_TITLE), props.getProperty(MISSING_SCHEDULE_CRITERIA_MESSAGE));
                                return;
                            }
                        }
                    }
                }
            }
        }
        if (data.containsSchedule(date, type)) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(SCHEDULE_NOT_UNIQUE_TITLE), props.getProperty(SCHEDULE_NOT_UNIQUE_MESSAGE));
            return;
        }
        // EVERYTHING IS FINE, ADD A NEW SCHEDULE
        else {
            // ADD THE NEW RECITATION TO THE DATA
            jTPS_Transaction addScheduleState = new ScheduleAddState(app);
            jTPSThingy.addTransaction(addScheduleState);
            
            // CLEAR THE TEXT FIELDS
            timeTextField.setText("");
            titleTextField.setText("");
            topicTextField.setText("");
            linkTextField.setText("");
            criteriaTextField.setText("");
            // CLEAR THE COMBO BOXES
            workspace.getScheduleTypeComboBox().getSelectionModel().clearSelection();
            //CLEAR THE DATEPICKER
            workspace.getScheduleDateDatePicker().setValue(null);
            
            // AND SEND THE CARET BACK TO THE SECTION TEXT FIELD FOR EASY DATA ENTRY
            workspace.getScheduleTimeField().requestFocus();
            
            checkUndoRedo();
            
            // WE'VE CHANGED STUFF
            markWorkAsEdited();
        }
    }
    
    public void handleAddTeam() {
        // WE'LL NEED THE WORKSPACE TO RETRIEVE THE USER INPUT VALUES
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TextField nameTextField = workspace.getProjectTeamNameField();
        TextField linkTextField = workspace.getProjectTeamLinkField();
        String name = nameTextField.getText();
        String link = linkTextField.getText();
        // WE'LL NEED TO ASK THE DATA SOME QUESTIONS TOO
        CSGData data = (CSGData)app.getDataComponent();
        
        // WE'LL NEED THIS IN CASE WE NEED TO DISPLAY ANY ERROR MESSAGES
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // CHECK EVEEYTHING
        // DID THE USER NEGLECT TO PROVIDE A TEAM NAME?
        if(name.compareTo("") == 0)
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_TEAM_NAME_TITLE), props.getProperty(MISSING_TEAM_NAME_MESSAGE));
            return;
        }
        // DID THE USER NEGLECT TO PROVIDE A TEAM LINK?
        if(link.compareTo("") == 0)
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_TEAM_LINK_TITLE), props.getProperty(MISSING_TEAM_LINK_MESSAGE));
            return;
        }
        if (data.containsTeam(name)) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(TEAM_NOT_UNIQUE_TITLE), props.getProperty(TEAM_NOT_UNIQUE_MESSAGE));
            return;
        }
        // EVERYTHING IS FINE, ADD A NEW SCHEDULE
        else {
            // ADD THE NEW RECITATION TO THE DATA
            jTPS_Transaction addTeamState = new TeamAddState(app);
            jTPSThingy.addTransaction(addTeamState);
            
            // CLEAR THE TEXT FIELDS
            nameTextField.setText("");
            linkTextField.setText("");
            // CLEAR THE COLOR PICKERS
            workspace.getProjectTeamColorPicker().setValue(Color.WHITE);
            workspace.getProjectTeamTextColorPicker().setValue(Color.WHITE);
            
            // AND SEND THE CARET BACK TO THE SECTION TEXT FIELD FOR EASY DATA ENTRY
            workspace.getProjectTeamNameField().requestFocus();
            
            checkUndoRedo();
            
            // WE'VE CHANGED STUFF
            markWorkAsEdited();
        }
    }
    
    public void handleAddStudent() {
        // WE'LL NEED THE WORKSPACE TO RETRIEVE THE USER INPUT VALUES
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TextField firstNameTextField = workspace.getProjectStudentFirstNameField();
        TextField lastNameTextField = workspace.getProjectStudentLastNameField();
        TextField roleTextField = workspace.getProjectStudentRoleField();
        if(workspace.getProjectStudentTeamComboBox().getValue() == null)
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_STUDENT_TEAM_TITLE), props.getProperty(MISSING_STUDENT_TEAM_MESSAGE));
            return;
        }
        else
        {
            String team = workspace.getProjectStudentTeamComboBox().getValue().toString();
        }
        String firstName = firstNameTextField.getText();
        String lastName = lastNameTextField.getText();
        String role = roleTextField.getText();
        // WE'LL NEED TO ASK THE DATA SOME QUESTIONS TOO
        CSGData data = (CSGData)app.getDataComponent();
        
        // WE'LL NEED THIS IN CASE WE NEED TO DISPLAY ANY ERROR MESSAGES
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // CHECK EVEEYTHING
        // DID THE USER NEGLECT TO PROVIDE A TEAM NAME?
        if(firstName.compareTo("") == 0)
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_STUDENT_FIRST_NAME_TITLE), props.getProperty(MISSING_STUDENT_FIRST_NAME_MESSAGE));
            return;
        }
        // DID THE USER NEGLECT TO PROVIDE A TEAM LINK?
        if(lastName.compareTo("") == 0)
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_STUDENT_LAST_NAME_TITLE), props.getProperty(MISSING_STUDENT_LAST_NAME_MESSAGE));
            return;
        }
        if(role.compareTo("Lead Programmer") == 0 || role.compareTo("Project Manager") == 0 || role.compareTo("Lead Designer") == 0 || role.compareTo("Data Designer") == 0)
        {
            
        }
        else
        {
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(MISSING_STUDENT_ROLE_TITLE), props.getProperty(MISSING_STUDENT_ROLE_MESSAGE));
            return;
        }
        if (data.containsStudent(firstName,lastName)) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(STUDENT_NOT_UNIQUE_TITLE), props.getProperty(STUDENT_NOT_UNIQUE_MESSAGE));
            return;
        }
        // EVERYTHING IS FINE, ADD A NEW SCHEDULE
        else {
            // ADD THE NEW RECITATION TO THE DATA
            jTPS_Transaction addStudentState = new StudentAddState(app);
            jTPSThingy.addTransaction(addStudentState);
            
            // CLEAR THE TEXT FIELDS
            firstNameTextField.setText("");
            lastNameTextField.setText("");
            roleTextField.setText("");
            // CLEAR THE COMBO BOX
            workspace.getProjectStudentTeamComboBox().getSelectionModel().clearSelection();
            
            // AND SEND THE CARET BACK TO THE SECTION TEXT FIELD FOR EASY DATA ENTRY
            workspace.getProjectStudentFirstNameField().requestFocus();
            
            checkUndoRedo();
            
            // WE'VE CHANGED STUFF
            markWorkAsEdited();
        }
    }
    
    public void changeTime() {
            CSGData CSGData = (CSGData)app.getDataComponent();
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            //CREATE AN ARRAYLIST OF THE RESERVATIONS
            ArrayList<TimeSlot> officeHours = TimeSlot.buildOfficeHoursList(CSGData);
            //CHECK RESERVATIONS FOR ANY DELETION/SET A PROMPT
            //FALSE = PROMPT
            boolean isFine = checkReservationDeletion(officeHours);
            boolean okToContinue = true;
            if(isFine == false)
            {
                okToContinue = promptToConfirm();
            }
            if(okToContinue == true)
            {
                //SET THE VALUES IN DATA
            ComboBox comboBox1 = workspace.getOfficeHour(true);
            ComboBox comboBox2 = workspace.getOfficeHour(false);
            String selectedStartText = (String)comboBox1.getValue();
            String selectedEndText = (String)comboBox2.getValue();
            int newStartHour = CSGData.getMilitaryTime(selectedStartText);
            int newEndHour = CSGData.getMilitaryTime(selectedEndText);
            boolean newStartHourOnlyHour = CSGData.getHourOnly(selectedStartText);
            boolean newEndHourOnlyHour = CSGData.getHourOnly(selectedEndText);
            if(checkValidHours() == false)
            {
                comboBox1.getSelectionModel().select(CSGData.getTimeString(CSGData.getStartHour(), CSGData.getStartOnlyHour()));
                comboBox2.getSelectionModel().select(CSGData.getTimeString(CSGData.getEndHour(), CSGData.getEndOnlyHour()));
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.START_OVER_END_TITLE.toString()), props.getProperty(CSGProp.START_OVER_END_MESSAGE.toString()));
                return;
            }
            //SET THE VALUE OF THE START TIME AS WELL AS THE BOOLEAN
            /*
            CSGData.setStartHour(newStartHour);
            CSGData.setStartOnlyHour(newStartHourOnlyHour);
            CSGData.setEndHour(newEndHour);
            CSGData.setEndOnlyHour(newEndHourOnlyHour);
            //CLEAR THE GRID
            workspace.getOfficeHoursGridPane().getChildren().clear();
            workspace.comboReloadWorkspace(app.getDataComponent());
            //CREATE NEW GRIDS FOR THE NEW OFFICEHOUR
            workspace.comboBoxUpdateOfficeHoursGrid(CSGData);
            //ADD THE RESERVATIONS
            for(int i = 0; i < officeHours.size(); i++)
            {
                String day = officeHours.get(i).getDay();
                String time = officeHours.get(i).getTime();
                String timeFormatted = time.replace("_", ":");
                String name = officeHours.get(i).getName();
                //VERIFY RESERVATION
                if(validateReservation(timeFormatted) == true)
                {
                    CSGData.addOfficeHoursReservation(day, time, name);
                }
            }
            */
            jTPS_Transaction changeHourState = new TAHoursChangeState(app, this);
            jTPSThingy.addTransaction(changeHourState);
            checkUndoRedo();
            //MARK AS EDITED
            markWorkAsEdited();
            }
            else
            {
                ComboBox comboBox1 = workspace.getOfficeHour(true);
                ComboBox comboBox2 = workspace.getOfficeHour(false);
                comboBox1.getSelectionModel().select(CSGData.getTimeString(CSGData.getStartHour(), CSGData.getStartOnlyHour()));
                comboBox2.getSelectionModel().select(CSGData.getTimeString(CSGData.getEndHour(), CSGData.getEndOnlyHour()));
            }
    }
    
    public boolean checkValidHours()
    {
        CSGData data = (CSGData) app.getDataComponent();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        ComboBox comboBox1 = workspace.getOfficeHour(true);
        ComboBox comboBox2 = workspace.getOfficeHour(false);
        String startComboBoxHour = (String)comboBox1.getValue();
        String endComboBoxHour = (String)comboBox2.getValue();
        int startIndex = 0;
        int endIndex = 0;
        for(int i = 0; i < data.getAllHours().size(); i++)
        {
            if(data.getAllHours().get(i).compareTo(startComboBoxHour) == 0)
            {
                startIndex = i;
            }
            if(data.getAllHours().get(i).compareTo(endComboBoxHour) == 0)
            {
                endIndex = i;
            }
        }
        if(startIndex < endIndex)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
     public boolean validateReservation(String reservationTime)
    {
        CSGData data = (CSGData) app.getDataComponent();
        String startTimeString = data.getTimeString(data.getStartHour(), data.getStartOnlyHour());
        String endTimeString = data.getTimeString(data.getEndHour(), data.getEndOnlyHour());
        int startIndex = 0;
        int endIndex = 0;
        for(int i = 0; i < data.getAllHours().size(); i++)
        {
            if(data.getAllHours().get(i).compareTo(startTimeString) == 0)
            {
                startIndex = i;
            }
            if(data.getAllHours().get(i).compareTo(endTimeString) == 0)
            {
                endIndex = i;
            }
        }
        for(int i = startIndex; i < endIndex; i++)
        {
            if(data.getAllHours().get(i).compareTo(reservationTime) == 0)
            {
                return true;
            }
        }
        return false;
    }
    
    public boolean promptToConfirm()
    {
        PropertiesManager props = PropertiesManager.getPropertiesManager();
	
	// CHECK TO SEE IF THE CURRENT WORK HAS
	// BEEN SAVED AT LEAST ONCE
	
        // PROMPT THE USER TO SAVE UNSAVED WORK
	AppYesNoCancelDialogSingleton yesNoDialog = AppYesNoCancelDialogSingleton.getSingleton();
        yesNoDialog.show(props.getProperty(COMBO_BOX_TITLE), props.getProperty(COMBO_BOX_MESSAGE));
        
        // AND NOW GET THE USER'S SELECTION
        String selection = yesNoDialog.getSelection();

        // IF THE USER SAID YES
        if (selection.equals(AppYesNoCancelDialogSingleton.YES)) {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean checkReservationDeletion(ArrayList<TimeSlot> currentHours)
    {
        CSGData data = (CSGData) app.getDataComponent();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        ComboBox comboBox1 = workspace.getOfficeHour(true);
        ComboBox comboBox2 = workspace.getOfficeHour(false);
        String startComboBoxHour = (String)comboBox1.getValue();
        String endComboBoxHour = (String)comboBox2.getValue();
        int startIndex = 0;
        int endIndex = 0;
        for(int i = 0; i < data.getAllHours().size(); i++)
        {
            if(data.getAllHours().get(i).compareTo(startComboBoxHour) == 0)
            {
                startIndex = i;
            }
            if(data.getAllHours().get(i).compareTo(endComboBoxHour) == 0)
            {
                endIndex = i;
            }
        }
        for(int l = 0; l < currentHours.size(); l++)
        {
            boolean isIn = false;
            for(int i = startIndex; i < endIndex; i++)
            {
                String formattedTime = currentHours.get(l).getTime().replace("_", ":");
                if(data.getAllHours().get(i).compareTo(formattedTime) == 0)
                {
                    isIn = true;
                }
            }
            if(isIn == false)
            {
                return false;
            }
        }
        return true;
    }
    /*
    This Method clears the Name and Email entry fields.
    It also changes the Update Ta button to a Add TA button
    */
    public void clear()
    {
    CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        //CLEAR TEXT FIELDS
        TextField nameTextField = workspace.getNameTextField();
        TextField emailTextField = workspace.getEmailTextField();
        nameTextField.setText("");
        emailTextField.setText("");
        //TOGGLE UPDATE TEXT
        if(workspace.getAddButton().getText().compareTo(props.getProperty(CSGProp.UPDATE_BUTTON_TEXT.toString())) == 0)
        {
            workspace.getAddButton().setText(props.getProperty(CSGProp.ADD_BUTTON_TEXT.toString()));
            //TOGGLE UPDATE BUTTON TO ADD BUTTON
            workspace.getAddButton().setOnAction(e -> {
            handleAddTA();
            });
        }
        //SEND FOCUS TO TEXT FIELD FOR EASY DATA ENTRY
        nameTextField.requestFocus();
    }
    
    public void clearRecitation()
    {
    CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        //CLEAR NAME AND EMAIL TEXT FIELDS
        TextField sectionTextField = workspace.getRecitationSectionField();
        TextField InstructorTextField = workspace.getRecitationInstructorField();
        TextField timeTextField = workspace.getRecitationDayTimeField();
        TextField locationTextField = workspace.getRecitationLocationField();
        sectionTextField.setText("");
        InstructorTextField.setText("");
        timeTextField.setText("");
        locationTextField.setText("");
        //CLEAR COMBO BOXES
        workspace.getRecitationTA1().getSelectionModel().clearSelection();
        workspace.getRecitationTA2().getSelectionModel().clearSelection();
        //TOGGLE UPDATE TEXT
        if(workspace.getRecitationAddUpdateButton().getText().compareTo(props.getProperty(CSGProp.UPDATE_RECITATION_BUTTON_TEXT.toString())) == 0)
        {
            workspace.getRecitationAddUpdateButton().setText(props.getProperty(CSGProp.ADD_RECITATION_BUTTON_TEXT.toString()));
            //TOGGLE UPDATE BUTTON TO ADD BUTTON
            workspace.getRecitationAddUpdateButton().setOnAction(e -> {
            handleAddRecitation();
            });
        }
        //SEND FOCUS TO TEXT FIELD FOR EASY DATA ENTRY
        sectionTextField.requestFocus();
    }
    
    public void clearSchedule()
    {
    CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        //CLEAR TEXT FIELDS
        TextField timeTextField = workspace.getScheduleTimeField();
        TextField titleTextField = workspace.getScheduleTitleField();
        TextField topicTextField = workspace.getScheduleTopicField();
        TextField linkTextField = workspace.getScheduleLinkField();
        TextField criteriaTextField = workspace.getScheduleCriteriaField();
        timeTextField.setText("");
        titleTextField.setText("");
        topicTextField.setText("");
        linkTextField.setText("");
        criteriaTextField.setText("");
        //CLEAR COMBO BOXES
        workspace.getScheduleTypeComboBox().getSelectionModel().clearSelection();
        //CLEAR THE DATEPICKER
        workspace.getScheduleDateDatePicker().setValue(null);
        //TOGGLE UPDATE TEXT
        if(workspace.getScheduleAddUpdateButton().getText().compareTo(props.getProperty(CSGProp.UPDATE_SCHEDULE_BUTTON_TEXT.toString())) == 0)
        {
            workspace.getScheduleAddUpdateButton().setText(props.getProperty(CSGProp.ADD_SCHEDULE_BUTTON_TEXT.toString()));
            //TOGGLE UPDATE BUTTON TO ADD BUTTON
            workspace.getScheduleAddUpdateButton().setOnAction(e -> {
            handleAddSchedule();
            });
        }
        //SEND FOCUS TO TEXT FIELD FOR EASY DATA ENTRY
        timeTextField.requestFocus();
    }
    
    public void clearTeam()
    {
    CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        //CLEAR TEXT FIELDS
        TextField nameTextField = workspace.getProjectTeamNameField();
        TextField linkTextField = workspace.getProjectTeamLinkField();
        nameTextField.setText("");
        linkTextField.setText("");
        //CLEAR THE COLORPICKERS
        workspace.getProjectTeamColorPicker().setValue(Color.WHITE);
        workspace.getProjectTeamTextColorPicker().setValue(Color.WHITE);
        //TOGGLE UPDATE TEXT
        if(workspace.getProjectTeamAddAndUpdateButton().getText().compareTo(props.getProperty(CSGProp.UPDATE_TEAM_BUTTON_TEXT.toString())) == 0)
        {
            workspace.getProjectTeamAddAndUpdateButton().setText(props.getProperty(CSGProp.ADD_TEAM_BUTTON_TEXT.toString()));
            //TOGGLE UPDATE BUTTON TO ADD BUTTON
            workspace.getProjectTeamAddAndUpdateButton().setOnAction(e -> {
            handleAddTeam();
            });
        }
        //SEND FOCUS TO TEXT FIELD FOR EASY DATA ENTRY
        nameTextField.requestFocus();
    }
    
    public void clearStudent()
    {
    CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        //CLEAR TEXT FIELDS
        TextField firstNameTextField = workspace.getProjectStudentFirstNameField();
        TextField lastNameTextField = workspace.getProjectStudentLastNameField();
        TextField roleTextField = workspace.getProjectStudentRoleField();
        firstNameTextField.setText("");
        lastNameTextField.setText("");
        roleTextField.setText("");
        //CLEAR THE COMBOBOX
        workspace.getProjectStudentTeamComboBox().getSelectionModel().clearSelection();
        //TOGGLE UPDATE TEXT
        if(workspace.getProjectStudentAddAndUpdateButton().getText().compareTo(props.getProperty(CSGProp.UPDATE_STUDENT_BUTTON_TEXT.toString())) == 0)
        {
            workspace.getProjectStudentAddAndUpdateButton().setText(props.getProperty(CSGProp.ADD_STUDENT_BUTTON_TEXT.toString()));
            //TOGGLE UPDATE BUTTON TO ADD BUTTON
            workspace.getProjectStudentAddAndUpdateButton().setOnAction(e -> {
            handleAddStudent();
            });
        }
        //SEND FOCUS TO TEXT FIELD FOR EASY DATA ENTRY
        firstNameTextField.requestFocus();
    }
    public void initializeButtons()
    {
        AppGUI gui = app.getGUI();
        gui.getFileController().getGuiUndoButton(gui).setOnAction(e -> {
            Undo();
        });
        gui.getFileController().getGuiRedoButton(gui).setOnAction(e -> {
            Redo();
        });
        if(jTPSThingy.getMostRecentTransactions() <= -1)
        {
            noUndo();
        }
        else
        {
            yesUndo();
        }
        if(jTPSThingy.getMostRecentTransactions() >= jTPSThingy.getTransactions())
        {
            noRedo();
        }
        else
        {
            yesRedo();
        }
    }
    
    public void Undo(){
        jTPSThingy.undoTransaction();
        if(jTPSThingy.getMostRecentTransactions() <= -1)
        {
            noUndo();
        }
        else
        {
            yesUndo();
        }
        if(jTPSThingy.getMostRecentTransactions() >= jTPSThingy.getTransactions())
        {
            noRedo();
        }
        else
        {
            yesRedo();
        }
        markWorkAsEdited();
    }
    public void Redo(){
        jTPSThingy.doTransaction();
        if(jTPSThingy.getMostRecentTransactions() <= -1)
        {
            noUndo();
        }
        else
        {
            yesUndo();
        }
        if(jTPSThingy.getMostRecentTransactions() >= jTPSThingy.getTransactions())
        {
            noRedo();
        }
        else
        {
            yesRedo();
        }
        markWorkAsEdited();
    }
    
    public void checkUndoRedo()
    {
        if(jTPSThingy.getMostRecentTransactions() <= -1)
        {
            noUndo();
        }
        else
        {
            yesUndo();
        }
        if(jTPSThingy.getMostRecentTransactions() >= jTPSThingy.getTransactions())
        {
            noRedo();
        }
        else
        {
            yesRedo();
        }
    }

    /**
     * This function provides a response for when the user presses a
     * keyboard key. Note that we're only responding to Delete, to remove
     * a TA.
     * 
     * @param code The keyboard code pressed.
     */
    public void handleKeyPress(KeyCode code) {
        // DID THE USER PRESS THE DELETE KEY?
        if (code == KeyCode.DELETE || code == KeyCode.BACK_SPACE) {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView taTable = workspace.getTATable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = taTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                TeachingAssistant ta = (TeachingAssistant)selectedItem;
                String taName = ta.getName();
                CSGData data = (CSGData)app.getDataComponent();
                //data.removeTA(taName);
                jTPS_Transaction deleteTAState = new TADeleteState(app, taName);
                jTPSThingy.addTransaction(deleteTAState);
                
                // AND BE SURE TO REMOVE ALL THE TA'S OFFICE HOURS
                HashMap<String, Label> labels = workspace.getOfficeHoursGridTACellLabels();
                for (Label label : labels.values()) {
                    if (label.getText().equals(taName)
                    || (label.getText().contains(taName + "\n"))
                    || (label.getText().contains("\n" + taName))) {
                        data.removeTAFromCell(label.textProperty(), taName);
                    }
                }
                clear();
                
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
        }
    }
    
    public void handleKeyPress() {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView taTable = workspace.getTATable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = taTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                TeachingAssistant ta = (TeachingAssistant)selectedItem;
                String taName = ta.getName();
                CSGData data = (CSGData)app.getDataComponent();
                //data.removeTA(taName);
                jTPS_Transaction deleteTAState = new TADeleteState(app, taName);
                jTPSThingy.addTransaction(deleteTAState);
                // AND BE SURE TO REMOVE ALL THE TA'S OFFICE HOURS
                HashMap<String, Label> labels = workspace.getOfficeHoursGridTACellLabels();
                for (Label label : labels.values()) {
                    if (label.getText().equals(taName)
                    || (label.getText().contains(taName + "\n"))
                    || (label.getText().contains("\n" + taName))) {
                        data.removeTAFromCell(label.textProperty(), taName);
                    }
                }
                clear();
                
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
        }
    
    public void handleDeleteRecitation(KeyCode code) {
        // DID THE USER PRESS THE DELETE KEY?
        if (code == KeyCode.DELETE || code == KeyCode.BACK_SPACE) {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView recTable = workspace.getRecitationTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = recTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Recitation rec = (Recitation)selectedItem;
                String recSection = rec.getSection();
                jTPS_Transaction deleteRecitationState = new RecitationDeleteState(app, recSection);
                jTPSThingy.addTransaction(deleteRecitationState);
                //CLEAR THE FIELDS
                clearRecitation();
                
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
        }
    }
    
    public void handleDeleteRecitation() {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView recTable = workspace.getRecitationTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = recTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Recitation rec = (Recitation)selectedItem;
                String recSection = rec.getSection();
                jTPS_Transaction deleteRecitationState = new RecitationDeleteState(app, recSection);
                jTPSThingy.addTransaction(deleteRecitationState);
                //CLEAR THE FIELDS
                clearRecitation();
                
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
    }
    
    public void handleDeleteSchedule(KeyCode code) {
        if (code == KeyCode.DELETE || code == KeyCode.BACK_SPACE) {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView schTable = workspace.getScheduleTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = schTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Schedule sch = (Schedule)selectedItem;
                String schType = sch.getType();
                LocalDate schDate = sch.getDate();
                jTPS_Transaction deleteScheduleState = new ScheduleDeleteState(app, schType, schDate);
                jTPSThingy.addTransaction(deleteScheduleState);
                //CLEAR THE FIELDS
                clearSchedule();
                
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
        }
    }
    
    public void handleDeleteSchedule() {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView schTable = workspace.getScheduleTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = schTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Schedule sch = (Schedule)selectedItem;
                String schType = sch.getType();
                LocalDate schDate = sch.getDate();
                jTPS_Transaction deleteScheduleState = new ScheduleDeleteState(app, schType, schDate);
                jTPSThingy.addTransaction(deleteScheduleState);
                //CLEAR THE FIELDS
                clearSchedule();
                
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
    }
    
    public void handleDeleteTeam(KeyCode code) {
        if (code == KeyCode.DELETE || code == KeyCode.BACK_SPACE) {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView tmTable = workspace.getTeamTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = tmTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Team tm = (Team)selectedItem;
                String tmName = tm.getName();
                jTPS_Transaction deleteTeamState = new TeamDeleteState(app, tmName);
                jTPSThingy.addTransaction(deleteTeamState);
                //CLEAR THE FIELDS
                clearTeam();
                
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
        }
    }
    
    public void handleDeleteTeam() {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView tmTable = workspace.getTeamTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = tmTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Team tm = (Team)selectedItem;
                String tmName = tm.getName();
                jTPS_Transaction deleteTeamState = new TeamDeleteState(app, tmName);
                jTPSThingy.addTransaction(deleteTeamState);
                //CLEAR THE FIELDS
                clearTeam();
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
    }
    
    public void handleDeleteStudent(KeyCode code) {
        if (code == KeyCode.DELETE || code == KeyCode.BACK_SPACE) {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView stTable = workspace.getStudentTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = stTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Student st = (Student)selectedItem;
                String stFirstName = st.getFirstName();
                String stLastName = st.getLastName();
                jTPS_Transaction deleteStudentState = new StudentDeleteState(app, stFirstName, stLastName);
                jTPSThingy.addTransaction(deleteStudentState);
                //CLEAR THE FIELDS
                clearStudent();
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
        }
    }
    
    public void handleDeleteStudent() {
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView stTable = workspace.getStudentTable();
            
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = stTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // GET THE TA AND REMOVE IT
                Student st = (Student)selectedItem;
                String stFirstName = st.getFirstName();
                String stLastName = st.getLastName();
                jTPS_Transaction deleteStudentState = new StudentDeleteState(app, stFirstName, stLastName);
                jTPSThingy.addTransaction(deleteStudentState);
                //CLEAR THE FIELDS
                clearStudent();
                checkUndoRedo();
                // WE'VE CHANGED STUFF
                markWorkAsEdited();
            }
    }
    
    public void handleChangeExportDirectory() {
        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        CSGData data = (CSGData)app.getDataComponent();
        DirectoryChooser dc = new DirectoryChooser();
	dc.setTitle(props.getProperty(CSGProp.EMAIL_VERIFICATION_REGEX.toString()));
        File selectedFile = dc.showDialog(app.getGUI().getWindow());

        // ONLY OPEN A NEW FILE IF THE USER SAYS OK
        if (selectedFile != null) {
            try {
                /*
                // CHANGE THE EXPORT DIRECTORY
                data.setExportDir(selectedFile.getAbsolutePath());
                // SET THE LABEL
                workspace.getCourseExportDirFileLabel().setText(data.getExportDir());
                */
                jTPS_Transaction changeExportState = new ExportDirectoryChangeState(app, selectedFile.getAbsolutePath());
                jTPSThingy.addTransaction(changeExportState);
                markWorkAsEdited();
            } catch (Exception e) {
                dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
            }
        }
    }
    
    public void handleChangeSiteTemplate() {
        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        CSGData data = (CSGData)app.getDataComponent();
        DirectoryChooser dc = new DirectoryChooser();
	dc.setTitle(props.getProperty(CSGProp.EMAIL_VERIFICATION_REGEX.toString()));
        File selectedFile = dc.showDialog(app.getGUI().getWindow());

        // ONLY OPEN A NEW FILE IF THE USER SAYS OK
        if (selectedFile != null) {
            try {
                //CLEAR THE LIST
                data.getSitePages().clear();
                //GET THE FILES
                File[] fileTemplates = new File(selectedFile.getAbsolutePath()).listFiles();
                for(int i = 0; i < fileTemplates.length; i++)
                {
                    if(fileTemplates[i].getName().compareTo("Home") == 0)
                    {
                        File destFile = new File(fileTemplates[i].getAbsolutePath() + File.separator + "js" + File.separator + "TeamsBuilder.js");
                        File destIndex = new File(fileTemplates[i].getAbsolutePath() + File.separator + "index.htm");
                        if(destFile.exists() && destIndex.exists())
                        {
                            Page homePage = new Page("Home", "index.html", "TeamsBuilder.js", false);
                            data.getSitePages().add(homePage);
                        }
                    }
                    if(fileTemplates[i].getName().compareTo("Syllabus") == 0)
                    {
                        File destFile = new File(fileTemplates[i].getAbsolutePath() + File.separator + "js" + File.separator + "OfficeHoursGridBuilder.js");
                        File destIndex = new File(fileTemplates[i].getAbsolutePath() + File.separator + "syllabus.html");
                        if(destFile.exists() && destIndex.exists())
                        {
                            Page syllabusPage = new Page("Syllabus", "syllabus.html", "SyllabusBuilder.js", false);
                            data.getSitePages().add(syllabusPage);
                        }
                    }
                    if(fileTemplates[i].getName().compareTo("Schedule") == 0)
                    {
                        File destFile = new File(fileTemplates[i].getAbsolutePath() + File.separator + "js" + File.separator + "ScheduleBuilder.js");
                        File destIndex = new File(fileTemplates[i].getAbsolutePath() + File.separator + "schedule.htm");
                        if(destFile.exists() && destIndex.exists())
                        {
                            Page schedulePage = new Page("Schedule", "schedule.html", "ScheduleBuilder.js", false);
                            data.getSitePages().add(schedulePage);
                        }
                    }
                    if(fileTemplates[i].getName().compareTo("HWs") == 0)
                    {
                        File destFile = new File(fileTemplates[i].getAbsolutePath() + File.separator + "js" + File.separator + "HWsBuilder.js");
                        File destIndex = new File(fileTemplates[i].getAbsolutePath() + File.separator + "hws.htm");
                        if(destFile.exists() && destIndex.exists())
                        {
                            Page homeworkPage = new Page("HWs", "hws.html", "HWsBuilder.js", false);
                            data.getSitePages().add(homeworkPage);
                        }
                    }
                    if(fileTemplates[i].getName().compareTo("Projects") == 0)
                    {
                        File destFile = new File(fileTemplates[i].getAbsolutePath() + File.separator + "js" + File.separator + "ProjectsBuilder.js");
                        File destIndex = new File(fileTemplates[i].getAbsolutePath() + File.separator + "projects.htm");
                        if(destFile.exists() && destIndex.exists())
                        {
                            Page projectPage = new Page("Projects", "projects.html", "ProjectsBuilder.js", false);
                            data.getSitePages().add(projectPage);
                        }
                    }
                }
                /*
                // CHANGE THE EXPORT DIRECTORY
                data.setSiteTemplate(selectedFile.getAbsolutePath());
                // SET THE LABEL
                workspace.getCourseSiteTemplateDirectoryLocationLabel().setText(data.getSiteTemplate());
                */
                jTPS_Transaction changeSiteTemplateState = new TemplateDirectoryChangeState(app, selectedFile.getAbsolutePath());
                jTPSThingy.addTransaction(changeSiteTemplateState);
                checkUndoRedo();
                //SORT THE PAGES
                Collections.sort(data.getSitePages());
                //REFRESH THE TABLE
                workspace.getSitePageTable().refresh();
                //MARK WORK AS EDITED
                markWorkAsEdited();
            } catch (Exception e) {
                dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
            }
        }
    }
    
    public void handleBannerSchoolChange()
    {
        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        CSGData data = (CSGData)app.getDataComponent();
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File(PATH_WORK + "brands"));
	fc.setTitle(props.getProperty(CSGProp.CHOOSE_IMAGE_TITLE.toString()));
        File selectedFile = fc.showOpenDialog(app.getGUI().getWindow());
	if (selectedFile != null) 
        {
            try
            {
                /*
                data.setBannerSchoolImage(selectedFile.toURI().toURL().toExternalForm());
                workspace.getBannerImageView().setImage(new Image(data.getBannerSchoolImage()));
                markWorkAsEdited();
                */
                jTPS_Transaction changeBannerState = new BannerImageChangeState(app, selectedFile);
                jTPSThingy.addTransaction(changeBannerState);
                checkUndoRedo();
                markWorkAsEdited();
                
            } catch(Exception e)
            {
                dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
            }
	}
    }
    
    public void handleBannerLeftSchoolChange()
    {
        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        CSGData data = (CSGData)app.getDataComponent();
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File(PATH_WORK + "brands"));
	fc.setTitle(props.getProperty(CSGProp.CHOOSE_IMAGE_TITLE.toString()));
        File selectedFile = fc.showOpenDialog(app.getGUI().getWindow());
	if (selectedFile != null) 
        {
            try
            {
                /*
                data.setBannerLeftFooterImage(selectedFile.toURI().toURL().toExternalForm());
                workspace.getLeftbannerImageView().setImage(new Image(data.getBannerLeftFooterImage()));
                markWorkAsEdited();
                */
                jTPS_Transaction changeLeftBannerState = new BannerLeftImageChangeState(app, selectedFile);
                jTPSThingy.addTransaction(changeLeftBannerState);
                checkUndoRedo();
                markWorkAsEdited();
                
            } catch(Exception e)
            {
                dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
            }
	}
    }
    
    public void handleBannerRightSchoolChange()
    {
        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        CSGData data = (CSGData)app.getDataComponent();
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File(PATH_WORK + "brands"));
	fc.setTitle(props.getProperty(CSGProp.CHOOSE_IMAGE_TITLE.toString()));
        File selectedFile = fc.showOpenDialog(app.getGUI().getWindow());
	if (selectedFile != null) 
        {
            try
            {
                /*
                data.setBannerRightFooterImage(selectedFile.toURI().toURL().toExternalForm());
                workspace.getRightbannerImageView().setImage(new Image(data.getBannerRightFooterImage()));
                markWorkAsEdited();
                */
                jTPS_Transaction changeRightBannerState = new BannerRightImageChangeState(app, selectedFile);
                jTPSThingy.addTransaction(changeRightBannerState);
                checkUndoRedo();
                markWorkAsEdited();
            } catch(Exception e)
            {
                dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
            }
	}
    }
    public void handleEdit()
    {
        //PATTERN FOR EMAIL
        String validEmailRegex = props.getProperty(CSGProp.EMAIL_VERIFICATION_REGEX.toString());
        Pattern checkRegexExpression = Pattern.compile(validEmailRegex);
        //IN CASE THERE ARE ERRORS
        PropertiesManager props = PropertiesManager.getPropertiesManager();
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView taTable = workspace.getTATable();
            //
            CSGData data = (CSGData)app.getDataComponent();
            // IS A TA SELECTED IN THE TABLE?
            Object selectedItem = taTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null)
            {
                // GET THE TA
                TeachingAssistant ta = (TeachingAssistant)selectedItem;
                String taPreviousName = ta.getName();
                String taPreviousEmail = ta.getEmail();
                // PUT IT IN THE FIELDS
                TextField nameTextField = workspace.getNameTextField();
                TextField emailTextField = workspace.getEmailTextField();
                nameTextField.setText(taPreviousName);
                emailTextField.setText(taPreviousEmail);
                TeachingAssistant selectedTa = data.getTA(taPreviousName);
                //CHANGE THE TEXT FROM "ADD TA" TO "UPDATE TA"
                workspace.getAddButton().setText(props.getProperty(CSGProp.UPDATE_BUTTON_TEXT.toString()));
                //SET THE BUTTON TO UPDATE TA
                workspace.getAddButton().setOnAction(e -> 
                {
                    //IN CASE IT WILL BE CHANGED AGAIN WITHOUT BEING SELECTED
                    String previousName = selectedTa.getName();
                    //GET THE NAME AnD EMAIL FROM THE INPUT
                    String updatedName = workspace.getNameTextField().getText();
                    String updatedEmail = workspace.getEmailTextField().getText();
                    //EMAIL CHECK
                    Matcher matchIt = checkRegexExpression.matcher(updatedEmail);
                    //IF EMAIL IS INVALID
                    if(!matchIt.matches())
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(TA_EMAIL_INVALID_TITLE), props.getProperty(TA_EMAIL_INVALID_MESSAGE));
                        return;
                    }
                    //ELSE UPDATE THE GRID
                    /*
                    updateGrid(previousName, updatedName);
                    selectedTa.setName(updatedName);
                    selectedTa.setEmail(updatedEmail);
                    //SORT THE TABLE
                    Collections.sort(data.getTeachingAssistants());
                    //REFRESH THE TABLE
                    taTable.refresh();
                    //STUFF HAS BEEN CHANGED
                    if(previousName.compareTo(updatedName) != 0)
                    {
                        markWorkAsEdited();
                    }
                    */
                    jTPS_Transaction replaceState = new TAReplaceState(app);
                    jTPSThingy.addTransaction(replaceState);
                    checkUndoRedo();
                });
            }
    }
    
    public void handleEditRecitation()
    {
        //IN CASE THERE ARE ERRORS
        PropertiesManager props = PropertiesManager.getPropertiesManager();
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView recitationTable = workspace.getRecitationTable();
            //
            CSGData data = (CSGData)app.getDataComponent();
            // IS A RECITATION SELECTED IN THE TABLE?
            Object selectedItem = recitationTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null)
            {
                // GET THE REciTATION
                Recitation rec = (Recitation)selectedItem;
                String recitationPreviousSection = rec.getSection();
                String recitationPreviousInstructor = rec.getInstructor();
                String recitationPreviousTime = rec.getDayAndTime();
                String recitationPreviousLocation = rec.getLocation();
                String recitationPreviousTAOne = rec.getTaOne();
                String recitationPreviousTATwo = rec.getTaTwo();
                // PUT IT IN THE FIELDS
                TextField sectionTextField = workspace.getRecitationSectionField();
                TextField instructorTextField = workspace.getRecitationInstructorField();
                TextField timeTextField = workspace.getRecitationDayTimeField();
                TextField locationTextField = workspace.getRecitationLocationField();
                sectionTextField.setText(recitationPreviousSection);
                instructorTextField.setText(recitationPreviousInstructor);
                timeTextField.setText(recitationPreviousTime);
                locationTextField.setText(recitationPreviousLocation);
                Recitation selectedRecitation = data.getRecitation(recitationPreviousSection);
                //PUT IT IN THE COMBOBOXES
                if(recitationPreviousTAOne.compareTo("") != 0)
                {
                    workspace.getRecitationTA1().getSelectionModel().select(data.getTA(data.getRecitation(recitationPreviousSection).getTaOne()));
                }
                else
                {
                    workspace.getRecitationTA1().getSelectionModel().clearSelection();
                }
                if(recitationPreviousTATwo.compareTo("") != 0)
                {
                    workspace.getRecitationTA2().getSelectionModel().select(data.getTA(data.getRecitation(recitationPreviousSection).getTaTwo()));
                }
                else
                {
                    workspace.getRecitationTA2().getSelectionModel().clearSelection();
                }
                //CHANGE THE TEXT FROM "ADD RECITATION" TO "UPDATE RECITATION"
                workspace.getRecitationAddUpdateButton().setText(props.getProperty(CSGProp.UPDATE_RECITATION_BUTTON_TEXT.toString()));
                //SET THE BUTTON TO UPDATE RECITATION
                workspace.getRecitationAddUpdateButton().setOnAction(e -> 
                {
                    String previousSection = selectedRecitation.getSection();
                    //CHECK EVERYHING
                    TextField dayTimeTextField = workspace.getRecitationDayTimeField();
                    TextField instructorField = workspace.getRecitationInstructorField();
                    TextField locationField = workspace.getRecitationLocationField();
                    TextField sectionField = workspace.getRecitationSectionField();
                    String dayTime = dayTimeTextField.getText();
                    String instructor = instructorField.getText();
                    String location = locationField.getText();
                    String section = sectionField.getText();
                    if(workspace.getRecitationTA1().getValue() != null)
                    {
                        String taOne = workspace.getRecitationTA1().getValue().toString();
                    }
                    else
                    {
                        String taOne = "";
                    }
                    if(workspace.getRecitationTA2().getValue() != null)
                    {
                        String taTwo = workspace.getRecitationTA2().getValue().toString();
                    }
                    else
                    {
                        String taTwo = "";
                    }
                    // DID THE USER NEGLECT TO PROVIDE A RECITATION SECTION?
                    if (section.isEmpty()) {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_RECITATION_SECTION_TITLE), props.getProperty(MISSING_RECITATION_SECTION_MESSAGE));
                        return;
                    }
                    // DID THE USER NEGLECT TO PROVIDE A RECITATION LOCATION?
                    else if (location.isEmpty()) {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_RECITATION_LOCATION_TITLE), props.getProperty(MISSING_RECITATION_LOCATION_MESSAGE));
                        return;
                    }
                    // DID THE USER NEGLECT TO PROVIDE A RECITATION TIME?
                    else if (dayTime.isEmpty()) {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_RECITATION_DAYTIME_TITLE), props.getProperty(MISSING_RECITATION_DAYTIME_MESSAGE));
                        return;                        
                    }
                    //GET THE STUFF FROM THE INPUT
                    String updatedSection = workspace.getRecitationSectionField().getText();
                    if(updatedSection.compareTo(previousSection) != 0)
                    {
                        if(data.containsRecitation(updatedSection))
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(RECITATION_SECTION_NOT_UNIQUE_TITLE), props.getProperty(RECITATION_SECTION_NOT_UNIQUE_MESSAGE));
                            return;
                        }
                    }
                    jTPS_Transaction replaceRecitationState = new RecitationReplaceState(app);
                    jTPSThingy.addTransaction(replaceRecitationState);
                    checkUndoRedo();
                });
            }
    }
    
    public void handleEditSchedule()
    {
        //IN CASE THERE ARE ERRORS
        PropertiesManager props = PropertiesManager.getPropertiesManager();
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView scheduleTable = workspace.getScheduleTable();
            //
            CSGData data = (CSGData)app.getDataComponent();
            // IS A SCHEDULE SELECTED IN THE TABLE?
            Object selectedItem = scheduleTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null)
            {
                // GET THE SCHEDULE
                Schedule sch = (Schedule)selectedItem;
                String schedulePreviousType = sch.getType();
                LocalDate schedulePreviousDate = sch.getDate();
                String schedulePreviousTime = sch.getTime();
                String schedulePreviousTitle = sch.getTitle();
                String schedulePreviousTopic = sch.getTopic();
                String schedulePreviousLink = sch.getlink();
                String schedulePreviousCriteria = sch.getCriteria();
                // PUT IT IN THE FIELDS
                TextField scheduleTimeTextField = workspace.getScheduleTimeField();
                TextField scheduleTitleTextField = workspace.getScheduleTitleField();
                TextField scheduleTopicTextField = workspace.getScheduleTopicField();
                TextField scheduleLinkTextField = workspace.getScheduleLinkField();
                TextField scheduleCriteriaTextField = workspace.getScheduleCriteriaField();
                scheduleTimeTextField.setText(schedulePreviousTime);
                scheduleTitleTextField.setText(schedulePreviousTitle);
                scheduleTopicTextField.setText(schedulePreviousTopic);
                scheduleLinkTextField.setText(schedulePreviousLink);
                scheduleCriteriaTextField.setText(schedulePreviousCriteria);
                Schedule selectedSchedule = data.getSchedule(schedulePreviousType,schedulePreviousDate);
                //PUT IT IN THE COMBOBOXES
                if(schedulePreviousType.compareTo("") != 0)
                {
                    workspace.getScheduleTypeComboBox().getSelectionModel().select(schedulePreviousType);
                }
                else
                {
                    workspace.getScheduleTypeComboBox().getSelectionModel().clearSelection();
                }
                //PUT IT IN THE DATEPICKER
                workspace.getScheduleDateDatePicker().setValue(schedulePreviousDate);
                //CHANGE THE TEXT FROM "ADD SCHEDULE" TO "UPDATE SCHEDULE"
                workspace.getScheduleAddUpdateButton().setText(props.getProperty(CSGProp.UPDATE_SCHEDULE_BUTTON_TEXT.toString()));
                //SET THE BUTTON TO UPDATE SCHEDULE
                workspace.getScheduleAddUpdateButton().setOnAction(e -> 
                {
                    TextField timeTextField = workspace.getScheduleTimeField();
                    TextField titleTextField = workspace.getScheduleTitleField();
                    TextField topicTextField = workspace.getScheduleTopicField();
                    TextField linkTextField = workspace.getScheduleLinkField();
                    TextField criteriaTextField = workspace.getScheduleCriteriaField();
                    LocalDate date = workspace.getScheduleDateDatePicker().getValue();
                    String time = timeTextField.getText();
                    String title = titleTextField.getText();
                    String topic = topicTextField.getText();
                    String link = linkTextField.getText();
                    String criteria = criteriaTextField.getText();
                    String type = "";
                    if(workspace.getScheduleTypeComboBox().getValue() != null)
                    {
                        type = workspace.getScheduleTypeComboBox().getValue().toString();
                    }
                    // CHECK EVEEYTHING
                    // DID THE USER NEGLECT TO PROVIDE A SCHEDULE TYPE?
                    if(type.compareTo("") == 0)
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_SCHEDULE_TYPE_TITLE), props.getProperty(MISSING_SCHEDULE_TYPE_MESSAGE));
                        return;
                    }
                    // DID THE USER NEGLECT TO PROVIDE A SCHEDULE DATE?
                    if(date == null)
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_SCHEDULE_DATE_TITLE), props.getProperty(MISSING_SCHEDULE_DATE_MESSAGE));
                        return;
                    }
                    // DID THE USER NEGLECT TO PROVIDE VALID SCHEDULE DATA?
                    if(type.compareTo("Lecture") == 0)
                    {
                        if(title.isEmpty())
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                            return;
                        }
                        else
                        {
                            if(topic.isEmpty())
                            {
                                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                                return;
                            }
                            else
                            {
                                if(link.isEmpty())
                                {
                                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                    dialog.show(props.getProperty(MISSING_SCHEDULE_LINK_TITLE), props.getProperty(MISSING_SCHEDULE_LINK_MESSAGE));
                                    return;
                                }
                            }
                        }
                    }

                    if(type.compareTo("Reference") == 0)
                    {
                        if(title.isEmpty())
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                            return;
                        }
                        else
                        {
                            if(topic.isEmpty())
                            {
                                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                                return;
                            }
                            else
                            {
                                if(link.isEmpty())
                                {
                                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                    dialog.show(props.getProperty(MISSING_SCHEDULE_LINK_TITLE), props.getProperty(MISSING_SCHEDULE_LINK_MESSAGE));
                                    return;
                                }
                            }
                        }
                    }

                    if(type.compareTo("Recitation") == 0)
                    {
                        if(title.isEmpty())
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                            return;
                        }
                        else
                        {
                            if(topic.isEmpty())
                            {
                                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                                return;
                            }
                        }
                    }

                    if(type.compareTo("Homework") == 0)
                    {
                        if(title.isEmpty())
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(MISSING_SCHEDULE_TITLE_TITLE), props.getProperty(MISSING_SCHEDULE_TITLE_MESSAGE));
                            return;
                        }
                        else
                        {
                            if(topic.isEmpty())
                            {
                                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                dialog.show(props.getProperty(MISSING_SCHEDULE_TOPIC_TITLE), props.getProperty(MISSING_SCHEDULE_TOPIC_MESSAGE));
                                return;
                            }
                            else
                            {
                                if(link.isEmpty())
                                {
                                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                    dialog.show(props.getProperty(MISSING_SCHEDULE_LINK_TITLE), props.getProperty(MISSING_SCHEDULE_LINK_MESSAGE));
                                    return;
                                }
                                else
                                {
                                    if(time.isEmpty())
                                    {
                                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                        dialog.show(props.getProperty(MISSING_SCHEDULE_TIME_TITLE), props.getProperty(MISSING_SCHEDULE_TIME_MESSAGE));
                                        return;
                                    }
                                    else
                                    {
                                        if(criteria.isEmpty())
                                        {
                                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                            dialog.show(props.getProperty(MISSING_SCHEDULE_CRITERIA_TITLE), props.getProperty(MISSING_SCHEDULE_CRITERIA_MESSAGE));
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    String previousType = selectedSchedule.getType();
                    LocalDate previousDate = selectedSchedule.getDate();
                    //GET THE TYPE AND DATE FROM THE INPUT
                    String updatedType = workspace.getScheduleTypeComboBox().getValue().toString();
                    LocalDate updatedDate = workspace.getScheduleDateDatePicker().getValue();
                    if(updatedType.compareTo(previousType) != 0 || updatedDate.toString().compareTo(previousDate.toString()) != 0)
                    {
                        if(data.containsSchedule(updatedDate, updatedType))
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(SCHEDULE_NOT_UNIQUE_TITLE), props.getProperty(SCHEDULE_NOT_UNIQUE_MESSAGE));
                            return;
                        }
                    }
                    jTPS_Transaction replaceScheduleState = new ScheduleReplaceState(app);
                    jTPSThingy.addTransaction(replaceScheduleState);
                    checkUndoRedo();
                });
            }
    }
    
    public void handleEditTeam()
    {
        //IN CASE THERE ARE ERRORS
        PropertiesManager props = PropertiesManager.getPropertiesManager();
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView teamTable = workspace.getTeamTable();
            //
            CSGData data = (CSGData)app.getDataComponent();
            // IS A RECITATION SELECTED IN THE TABLE?
            Object selectedItem = teamTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null)
            {
                // GET THE REciTATION
                Team tm = (Team)selectedItem;
                String teamPreviousName = tm.getName();
                String teamPreviousLink = tm.getLink();
                Color teamPreviousColor = tm.getColor();
                Color teamPreviousTextColor = tm.getTextColor();
                // PUT IT IN THE FIELDS
                TextField nameTextField = workspace.getProjectTeamNameField();
                TextField linkTextField = workspace.getProjectTeamLinkField();
                nameTextField.setText(teamPreviousName);
                linkTextField.setText(teamPreviousLink);
                // PUT IT IN THE COLORPICKERS
                workspace.getProjectTeamColorPicker().setValue(teamPreviousColor);
                workspace.getProjectTeamTextColorPicker().setValue(teamPreviousTextColor);
                Team selectedTeam = data.getTeam(teamPreviousName);
                //CHANGE THE TEXT FROM "ADD RECITATION" TO "UPDATE RECITATION"
                workspace.getProjectTeamAddAndUpdateButton().setText(props.getProperty(CSGProp.UPDATE_TEAM_BUTTON_TEXT.toString()));
                //SET THE BUTTON TO UPDATE RECITATION
                workspace.getProjectTeamAddAndUpdateButton().setOnAction(e -> 
                {
                    String previousName = selectedTeam.getName();
                    //CHECK EVERYHING
                    TextField teamNameTextField = workspace.getProjectTeamNameField();
                    TextField teamLinkTextField = workspace.getProjectTeamLinkField();
                    String name = teamNameTextField.getText();
                    String link = teamLinkTextField.getText();
                    // CHECK EVERYTHING
                    // DID THE USER NEGLECT TO PROVIDE A TEAM NAME?
                    if(name.compareTo("") == 0)
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_TEAM_NAME_TITLE), props.getProperty(MISSING_TEAM_NAME_MESSAGE));
                        return;
                    }
                    // DID THE USER NEGLECT TO PROVIDE A TEAM LINK?
                    if(link.compareTo("") == 0)
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_TEAM_LINK_TITLE), props.getProperty(MISSING_TEAM_LINK_MESSAGE));
                        return;
                    }
                    //GET THE STUFF FROM THE INPUT
                    String updatedName = workspace.getProjectTeamNameField().getText();
                    if(updatedName.compareTo(previousName) != 0)
                    {
                        if(data.containsTeam(updatedName))
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(TEAM_NOT_UNIQUE_TITLE), props.getProperty(TEAM_NOT_UNIQUE_MESSAGE));
                            return;
                        }
                    }
                    jTPS_Transaction replaceTeamState = new TeamReplaceState(app);
                    jTPSThingy.addTransaction(replaceTeamState);
                    checkUndoRedo();
                });
            }
    }
    
    public void handleEditStudent()
    {
        //IN CASE THERE ARE ERRORS
        PropertiesManager props = PropertiesManager.getPropertiesManager();
            // GET THE TABLE
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            TableView studentTable = workspace.getStudentTable();
            //
            CSGData data = (CSGData)app.getDataComponent();
            // IS A RECITATION SELECTED IN THE TABLE?
            Object selectedItem = studentTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null)
            {
                // GET THE REciTATION
                Student st = (Student)selectedItem;
                String studentPreviousFirstName = st.getFirstName();
                String studentPreviousLastName = st.getLastName();
                String studentPreviousTeam = st.getTeam();
                String studentPreviousRole = st.getRole();
                // PUT IT IN THE FIELDS
                TextField firstNameTextField = workspace.getProjectStudentFirstNameField();
                TextField lastNameTextField = workspace.getProjectStudentLastNameField();
                TextField roleTextField = workspace.getProjectStudentRoleField();
                firstNameTextField.setText(studentPreviousFirstName);
                lastNameTextField.setText(studentPreviousLastName);
                roleTextField.setText(studentPreviousRole);
                // PUT IT IN THE COMBOBOX
                workspace.getProjectStudentTeamComboBox().setValue(data.getTeam(studentPreviousTeam));
                Student selectedStudent = data.getStudent(studentPreviousFirstName, studentPreviousLastName);
                //CHANGE THE TEXT FROM "ADD RECITATION" TO "UPDATE RECITATION"
                workspace.getProjectStudentAddAndUpdateButton().setText(props.getProperty(CSGProp.UPDATE_STUDENT_BUTTON_TEXT.toString()));
                //SET THE BUTTON TO UPDATE RECITATION
                workspace.getProjectStudentAddAndUpdateButton().setOnAction(e -> 
                {
                    String previousFirstName = selectedStudent.getFirstName();
                    String previousLastName = selectedStudent.getLastName();
                    if(workspace.getProjectStudentTeamComboBox().getValue() == null)
                    {
                        String team = "";
                    }
                    else
                    {
                        String team = workspace.getProjectStudentTeamComboBox().getValue().toString();
                    }
                    String firstName = firstNameTextField.getText();
                    String lastName = lastNameTextField.getText();
                    String role = roleTextField.getText();

                    // CHECK EVEEYTHING
                    // DID THE USER NEGLECT TO PROVIDE A NAME?
                    if(firstName.compareTo("") == 0)
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_STUDENT_FIRST_NAME_TITLE), props.getProperty(MISSING_STUDENT_FIRST_NAME_MESSAGE));
                        return;
                    }
                    // DID THE USER NEGLECT TO PROVIDE A LAST NAME?
                    if(lastName.compareTo("") == 0)
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_STUDENT_LAST_NAME_TITLE), props.getProperty(MISSING_STUDENT_LAST_NAME_MESSAGE));
                        return;
                    }
                    if(role.compareTo("Lead Programmer") == 0 || role.compareTo("Project Manager") == 0 || role.compareTo("Lead Designer") == 0 || role.compareTo("Data Designer") == 0)
                    {

                    }
                    else
                    {
                        AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                        dialog.show(props.getProperty(MISSING_STUDENT_ROLE_TITLE), props.getProperty(MISSING_STUDENT_ROLE_MESSAGE));
                        return;
                    }
                    //GET THE STUFF FROM THE INPUT
                    String updatedFirstName = workspace.getProjectStudentFirstNameField().getText();
                    String updatedLastName = workspace.getProjectStudentLastNameField().getText();
                    if(updatedFirstName.compareTo(previousFirstName) != 0 || updatedLastName.compareTo(previousLastName) != 0)
                    {
                        if(data.containsStudent(updatedFirstName, updatedLastName))
                        {
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(STUDENT_NOT_UNIQUE_TITLE), props.getProperty(STUDENT_NOT_UNIQUE_MESSAGE));
                            return;
                        }
                    }
                    jTPS_Transaction replaceStudentState = new StudentReplaceState(app);
                    jTPSThingy.addTransaction(replaceStudentState);
                    checkUndoRedo();
                });
            }
    }
    
    public void updateTACheck()
    {
        CSGData data = (CSGData)app.getDataComponent();
        jTPS_Transaction taCheckState = new TACheckState(app, data.getTeachingAssistants());
        jTPSThingy.addTransaction(taCheckState);
        markWorkAsEdited();
    }
                  
    
    public void changeStartingMonday()
    {
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        CSGData data = (CSGData)app.getDataComponent();
        int startYear = workspace.getStartingMonday().getValue().getYear();
        int endYear = workspace.getEndingFriday().getValue().getYear();
        int startMonth = workspace.getStartingMonday().getValue().getMonthValue();
        int endMonth = workspace.getEndingFriday().getValue().getMonthValue();
        int startDay = workspace.getStartingMonday().getValue().getDayOfMonth();
        int endDay = workspace.getEndingFriday().getValue().getDayOfMonth();
        if(startYear > endYear)
        {
            workspace.getStartingMonday().getEditor().setText(data.getStartingMonday().toString());
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
            return;
        }
        else
        {
            if(startYear == endYear)
            {
                if(startMonth > endMonth)
                {
                    workspace.getStartingMonday().getEditor().setText(data.getStartingMonday().toString());
                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                    dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
                    return;
                }
                else
                {
                    if(startMonth == endMonth)
                    {
                        if(startDay > endDay)
                        {
                            workspace.getStartingMonday().getEditor().setText(data.getStartingMonday().toString());
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
                            return;  
                        }
                        else
                        {
                            if(startDay == endDay)
                            {
                                workspace.getStartingMonday().getEditor().setText(data.getStartingMonday().toString());
                                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
                                return;
                            }
                        }
                    }
                }
            }
        }
        if(workspace.getStartingMonday().getValue().getDayOfWeek() != DayOfWeek.MONDAY)
        {
            workspace.getStartingMonday().getEditor().setText(data.getStartingMonday().toString());
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(INVALID_STARTING_MONDAY_TITLE), props.getProperty(INVALID_STARTING_MONDAY_MESSAGE));
            return;
        }
        jTPS_Transaction startingMondayChangeState = new ScheduleStartingMondayState(app);
        jTPSThingy.addTransaction(startingMondayChangeState);
        checkUndoRedo();
        markWorkAsEdited();
    }
    
    public void changeEndingFriday()
    {
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        CSGData data = (CSGData)app.getDataComponent();
        int startYear = workspace.getStartingMonday().getValue().getYear();
        int endYear = workspace.getEndingFriday().getValue().getYear();
        int startMonth = workspace.getStartingMonday().getValue().getMonthValue();
        int endMonth = workspace.getEndingFriday().getValue().getMonthValue();
        int startDay = workspace.getStartingMonday().getValue().getDayOfMonth();
        int endDay = workspace.getEndingFriday().getValue().getDayOfMonth();
        if(startYear > endYear)
        {
            workspace.getEndingFriday().getEditor().setText(data.getEndingFriday().toString());
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
            return;
        }
        else
        {
            if(startYear == endYear)
            {
                if(startMonth > endMonth)
                {
                    workspace.getEndingFriday().getEditor().setText(data.getEndingFriday().toString());
                    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                    dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
                    return;
                }
                else
                {
                    if(startMonth == endMonth)
                    {
                        if(startDay > endDay)
                        {
                            workspace.getEndingFriday().getEditor().setText(data.getEndingFriday().toString());
                            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                            dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
                            return;  
                        }
                        else
                        {
                            if(startDay == endDay)
                            {
                                workspace.getEndingFriday().getEditor().setText(data.getEndingFriday().toString());
                                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                                dialog.show(props.getProperty(START_OVER_END_DATE_TITLE), props.getProperty(START_OVER_END_DATE_MESSAGE));
                                return;
                            }
                        }
                    }
                }
            }
        }
        if(workspace.getEndingFriday().getValue().getDayOfWeek() != DayOfWeek.FRIDAY)
        {
            workspace.getEndingFriday().getEditor().setText(data.getEndingFriday().toString());
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(INVALID_ENDING_FRIDAY_TITLE), props.getProperty(INVALID_ENDING_FRIDAY_MESSAGE));
            return;
        }
        jTPS_Transaction endingFridayChangeState = new ScheduleEndingFridayState(app);
        jTPSThingy.addTransaction(endingFridayChangeState);
        checkUndoRedo();
        markWorkAsEdited();
    }
    
    public void updateSitesCheck()
    {
        CSGData data = (CSGData)app.getDataComponent();
        jTPS_Transaction siteState = new SiteCheckState(app, data.getSitePages());
        jTPSThingy.addTransaction(siteState);
        checkUndoRedo();
    }
    
    public void updateGrid(String previousName, String newName)
    {
            //GO THROUGH THE OFFICE HOURS GRID
            CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
            HashMap<String, Label> labels = workspace.getOfficeHoursGridTACellLabels();
            for (Label label : labels.values())
            {
                if (label.getText().equals(previousName)
                || (label.getText().contains(previousName + "\n"))
                || (label.getText().contains("\n" + previousName))) 
                {
                    String cellText = label.textProperty().getValue();
                    int beginningOfName = cellText.indexOf(previousName);
                    int endOfName = beginningOfName + previousName.length();
                    label.textProperty().setValue(cellText.substring(0,beginningOfName) + newName + cellText.substring(endOfName));
                }
            }
    }

    /**
     * This function provides a response for when the user clicks
     * on the office hours grid to add or remove a TA to a time slot.
     * 
     * @param pane The pane that was toggled.
     */
    public void handleCellToggle(Pane pane) {
        // GET THE TABLE
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView taTable = workspace.getTATable();
        
        // IS A TA SELECTED IN THE TABLE?
        Object selectedItem = taTable.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            // GET THE TA
            TeachingAssistant ta = (TeachingAssistant)selectedItem;
            String taName = ta.getName();
            CSGData data = (CSGData)app.getDataComponent();
            String cellKey = pane.getId();
            
            // AND TOGGLE THE OFFICE HOURS IN THE CLICKED CELL
            //data.toggleTAOfficeHours(cellKey, taName);
            jTPS_Transaction toggleTA = new TAToggleState(taName, cellKey, data);
            jTPSThingy.addTransaction(toggleTA);
            checkUndoRedo();
            
            // WE'VE CHANGED STUFF
            markWorkAsEdited();
        }
    }
    
    void handleGridCellMouseExited(Pane pane) {
        String cellKey = pane.getId();
        CSGData data = (CSGData)app.getDataComponent();
        int column = Integer.parseInt(cellKey.substring(0, cellKey.indexOf("_")));
        int row = Integer.parseInt(cellKey.substring(cellKey.indexOf("_") + 1));
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();

        Pane mousedOverPane = workspace.getTACellPane(data.getCellKey(column, row));
        mousedOverPane.getStyleClass().clear();
        mousedOverPane.getStyleClass().add(CLASS_OFFICE_HOURS_GRID_TA_CELL_PANE);

        // THE MOUSED OVER COLUMN HEADER
        Pane headerPane = workspace.getOfficeHoursGridDayHeaderPanes().get(data.getCellKey(column, 0));
        headerPane.getStyleClass().remove(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);

        // THE MOUSED OVER ROW HEADERS
        headerPane = workspace.getOfficeHoursGridTimeCellPanes().get(data.getCellKey(0, row));
        headerPane.getStyleClass().remove(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
        headerPane = workspace.getOfficeHoursGridTimeCellPanes().get(data.getCellKey(1, row));
        headerPane.getStyleClass().remove(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
        
        // AND NOW UPDATE ALL THE CELLS IN THE SAME ROW TO THE LEFT
        for (int i = 2; i < column; i++) {
            cellKey = data.getCellKey(i, row);
            Pane cell = workspace.getTACellPane(cellKey);
            cell.getStyleClass().remove(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
            cell.getStyleClass().add(CLASS_OFFICE_HOURS_GRID_TA_CELL_PANE);
        }

        // AND THE CELLS IN THE SAME COLUMN ABOVE
        for (int i = 1; i < row; i++) {
            cellKey = data.getCellKey(column, i);
            Pane cell = workspace.getTACellPane(cellKey);
            cell.getStyleClass().remove(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
            cell.getStyleClass().add(CLASS_OFFICE_HOURS_GRID_TA_CELL_PANE);
        }
    }

    void handleGridCellMouseEntered(Pane pane) {
        String cellKey = pane.getId();
        CSGData data = (CSGData)app.getDataComponent();
        int column = Integer.parseInt(cellKey.substring(0, cellKey.indexOf("_")));
        int row = Integer.parseInt(cellKey.substring(cellKey.indexOf("_") + 1));
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        
        // THE MOUSED OVER PANE
        Pane mousedOverPane = workspace.getTACellPane(data.getCellKey(column, row));
        mousedOverPane.getStyleClass().clear();
        mousedOverPane.getStyleClass().add(CLASS_HIGHLIGHTED_GRID_CELL);
        
        // THE MOUSED OVER COLUMN HEADER
        Pane headerPane = workspace.getOfficeHoursGridDayHeaderPanes().get(data.getCellKey(column, 0));
        headerPane.getStyleClass().add(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
        
        // THE MOUSED OVER ROW HEADERS
        headerPane = workspace.getOfficeHoursGridTimeCellPanes().get(data.getCellKey(0, row));
        headerPane.getStyleClass().add(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
        headerPane = workspace.getOfficeHoursGridTimeCellPanes().get(data.getCellKey(1, row));
        headerPane.getStyleClass().add(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
        
        // AND NOW UPDATE ALL THE CELLS IN THE SAME ROW TO THE LEFT
        for (int i = 2; i < column; i++) {
            cellKey = data.getCellKey(i, row);
            Pane cell = workspace.getTACellPane(cellKey);
            cell.getStyleClass().add(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
        }

        // AND THE CELLS IN THE SAME COLUMN ABOVE
        for (int i = 1; i < row; i++) {
            cellKey = data.getCellKey(column, i);
            Pane cell = workspace.getTACellPane(cellKey);
            cell.getStyleClass().add(CLASS_HIGHLIGHTED_GRID_ROW_OR_COLUMN);
        }
    }
}