/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.test_bed;

import csg.data.CSGData;
import csg.data.Page;
import csg.data.Recitation;
import csg.data.Schedule;
import csg.data.Student;
import csg.data.TeachingAssistant;
import csg.data.Team;
import csg.file.TimeSlot;
import java.time.LocalDate;
import java.time.Month;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.paint.Color;

/**
 *
 * @author David Xie
 */
public class TestSave {
    
    public static void generateDataOne(CSGData data)
    {
        data.setSubject("CSE");
        data.setSemester("Fall");
        data.setNumber(219);
        data.setYear(2017);
        data.setTitle("CSE 219 - Java");
        data.setInstructorName("Richard McKenna");
        data.setInstructorHome("http://www3.cs.stonybrook.edu/~cse219/Section02/syllabus.html");
        data.setExportDir("ExportDirString");
        data.setSiteTemplate("SiteTemplateDirString");
        data.setBannerSchoolImage("./work/brands/SBUDarkRedShieldLogo.png");
        data.setBannerLeftFooterImage("./work/brands/SBUWhiteShieldLogo.jpg");
        data.setBannerRightFooterImage("./work/brands/CSLogo.png");
        data.setStylesheet("sea_wolf");
        data.setStartingMonday(LocalDate.of(2017,4,10));
        data.setEndingFriday(LocalDate.of(2017,4,14));
        //SET THE PAGES
        ObservableList<Page> pagez = data.getSitePages();
        for(int i = 0; i < pagez.size(); i++)
        {
            pagez.get(i).setIsUsed(true);
        }
        //ADD THE TEACHING ASSISTANTS
        TeachingAssistant ta1 = new TeachingAssistant("Daniel", "Daniel@gmail.com", false);
        TeachingAssistant ta2 = new TeachingAssistant("John", "John@Stonybrook.edu", true);
        data.getTeachingAssistants().addAll(ta1, ta2);
        //ADD THE TIMESLOTS
        data.addOfficeHoursReservation("TUESDAY", "9_00am", "Daniel");
        data.addOfficeHoursReservation("THURSDAY", "5_00pm", "John");
        //ADD THE RECITATIONS
        Recitation recitation1 = new Recitation("section", "instrutor", "dayandtime", "location", "ta1", "ta2");
        Recitation recitation2 = new Recitation("sectionz", "instrutorz", "dayandtimez", "location", "taz1", "taz2");
        data.getRecitations().addAll(recitation1, recitation2);
        //ADD THE SCHEDULES
        Schedule schedule1 = new Schedule("Holiday", LocalDate.of(2017,4,11), "3:30 - 4:00", "SNOW DAY", "Nice Topic", "Nice Link", "Nice Criteria");
        Schedule schedule2 = new Schedule("Homework", LocalDate.of(2017,4,14), "3:00 - 4:00", "Homework", "Cool Topic", "Cool Link", "Cool Criteria");
        data.getSchedules().addAll(schedule1, schedule2);
        //ADD THE TEAMS
        Team team1 = new Team("Teal", Color.TEAL, Color.BLACK, "link");
        Team team2 = new Team("White", Color.WHITE, Color.BLACK, "link2");
        data.getTeams().addAll(team1, team2);
        //ADD THE STUDENTS
        Student student1 = new Student("Raymond", "Xue", "Teal", "Lead Programmer");
        Student student2 = new Student("Karl", "Jean Brice", "Teal", "Project Manager");
        Student student3 = new Student("Eric", "Li", "Teal", "Lead Designer");
        Student student4 = new Student("Xiangbin", "Zeng", "Teal", "Data Designer");
        Student student5 = new Student("Lee", "Aaron", "White", "Lead Programmer");
        Student student6 = new Student("Kamin", "Punjarojanakul", "White", "Project Manager");
        Student student7 = new Student("Wilson", "Tang", "White", "Lead Designer");
        Student student8 = new Student("David", "Lin", "White", "Data Designer");
        data.getStudents().addAll(student1, student2, student3, student4, student5, student6, student7, student8);
    }
}
