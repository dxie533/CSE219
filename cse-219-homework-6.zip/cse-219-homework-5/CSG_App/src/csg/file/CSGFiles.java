package csg.file;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import djf.components.AppDataComponent;
import djf.components.AppFileComponent;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javafx.collections.ObservableList;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonWriter;
import javax.json.JsonWriterFactory;
import javax.json.stream.JsonGenerator;
import csg.CSGApp;
import csg.CSGProp;
import csg.data.CSGData;
import csg.data.Page;
import csg.data.Recitation;
import csg.data.Schedule;
import csg.data.Student;
import csg.data.TeachingAssistant;
import csg.data.Team;
import java.io.File;
import java.time.format.DateTimeFormatter;
import csg.test_bed.TestSave;
import static djf.settings.AppStartupConstants.PATH_WORK;
import djf.ui.AppMessageDialogSingleton;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import javafx.scene.paint.Color;
import properties_manager.PropertiesManager;

/**
 * This class serves as the file component for the TA
 * manager app. It provides all saving and loading 
 * services for the application.
 * 
 * @author Richard McKenna
 */
public class CSGFiles implements AppFileComponent {
    // THIS IS THE APP ITSELF
    CSGApp app;
    
    // THESE ARE USED FOR IDENTIFYING JSON TYPES
    static final String JSON_START_HOUR = "startHour";
    static final String JSON_END_HOUR = "endHour";
    static final String JSON_START_HOUR_ONLY_HOUR = "startHourOnlyHour";
    static final String JSON_END_HOUR_ONLY_HOUR = "endHourOnlyHour";
    static final String JSON_OFFICE_HOURS = "officeHours";
    static final String JSON_DAY = "day";
    static final String JSON_TIME = "time";
    //COURSE INFO
    static final String JSON_SUBJECT = "subject";
    static final String JSON_NUMBER = "number";
    static final String JSON_SEMESTER = "semester";
    static final String JSON_YEAR = "year";
    static final String JSON_TITLE = "title";
    static final String JSON_INSTRUCTOR_NAME = "instructor_name";
    static final String JSON_INSTRUCTOR_HOME = "instructor_home";
    static final String JSON_EXPORT_DIR = "export_dir";
    static final String JSON_SITE_TEMPLATE_DIR = "site_template";
    static final String JSON_BANNER_SCHOOL_IMAGE = "banner_school_image";
    static final String JSON_LEFT_FOOTER_IMAGE = "left_footer_image";
    static final String JSON_RIGHT_FOOTER_IMAGE = "right_footer_image";
    static final String JSON_STYLESHEET = "stylesheet";
    //TAs
    static final String JSON_NAME = "name";
    static final String JSON_UNDERGRAD_TAS = "undergrad_tas";
    static final String JSON_EMAIL = "email";
    static final String JSON_UNDERGRAD = "undergrad";
    //PAGES
    static final String JSON_SITE_PAGES = "site_pages";
    static final String JSON_IN_USE = "use";
    static final String JSON_NAVBAR_TITLE = "navbar_title";
    static final String JSON_FILE_NAME = "file_name";
    static final String JSON_SCRIPT = "script";
    //RECITATIONS
    static final String JSON_RECITATIONS = "recitations";
    static final String JSON_SECTION = "section";
    static final String JSON_INSTRUCTOR = "instructor";
    static final String JSON_DAY_AND_TIME = "day_and_time";
    static final String JSON_LOCATION = "location";
    static final String JSON_TA_ONE = "ta_one";
    static final String JSON_TA_TWO = "ta_two";
    //SCHEDULE
    static final String JSON_STARTING_MONDAY = "starting_monday";
    static final String JSON_ENDING_FRIDAY = "ending_friday";
    static final String JSON_SCHEDULES = "schedules";
    static final String JSON_TYPE = "type";
    static final String JSON_DATE = "date";
    static final String JSON_TOPIC = "topic";
    static final String JSON_LINK = "link";
    static final String JSON_CRITERIA = "criteria";
    //TEAM
    static final String JSON_TEAMS = "teams";
    static final String JSON_COLOR = "color";
    static final String JSON_TEXT_COLOR = "text_color";
    //STUDENT
    static final String JSON_STUDENTS = "students";
    static final String JSON_FIRST_NAME = "first_name";
    static final String JSON_LAST_NAME = "last_name";
    static final String JSON_TEAM = "team";
    static final String JSON_ROLE = "role";
    //CUSTOM JSON NAMES
    static final String JSON_GRAD_TAS = "grad_tas";
    static final String JSON_TA_1 = "ta_1";
    static final String JSON_TA_2 = "ta_2";
    static final String JSON_DAY_TIME = "day_time";
    static final String JSON_STARTING_MONDAY_MONTH = "startingMondayMonth";
    static final String JSON_STARTING_MONDAY_DAY = "startingMondayDay";
    static final String JSON_ENDING_FRIDAY_MONTH = "endingFridayMonth";
    static final String JSON_ENDING_FRIDAY_DAY = "endingFridayDay";
    static final String JSON_HOLIDAYS = "holidays";
    static final String JSON_LECTURES = "lectures";
    static final String JSON_REFERENCES = "references";
    static final String JSON_HWS = "hws";
    static final String JSON_MONTH = "month";
    static final String JSON_RED = "red";
    static final String JSON_GREEN = "green";
    static final String JSON_BLUE = "blue";
    static final String JSON_LASTNAME = "lastName";
    static final String JSON_FIRSTNAME = "firstName";
    static final String JSON_WORK = "work";
    static final String JSON_SEMESTER_DATA = "semester_data";
    static final String JSON_PROJECTS = "projects";
    static final String HOME = "Home";
    static final String SYLLABUS = "Syllabus";
    static final String SCHEDULE = "Schedule";
    static final String HWS = "HWs";
    static final String PROJECTS = "Projects";
    
    //CUSTOM JSON FILE NAMES
    static final String OFFICE_HOURS_GRID_DATA = "TAsData.json";
    static final String RECITATIONS_DATA = "RecitationsData.json";
    static final String SCHEDULE_DATA = "ScheduleData.json";
    static final String TEAMS_AND_STUDENTS = "TeamsAndStudents.json";
    static final String PROJECTS_DATA = "ProjectsData.json";
    
    
    public CSGFiles(CSGApp initApp) {
        app = initApp;
    }

    @Override
    public void loadData(AppDataComponent data, String filePath) throws IOException {
	// CLEAR THE OLD DATA OUT
	CSGData dataManager = (CSGData)data;

	// LOAD THE JSON FILE WITH ALL THE DATA
	JsonObject json = loadJSONFile(filePath);

	// LOAD THE START AND END HOURS
	String startHour = json.getString(JSON_START_HOUR);
        String endHour = json.getString(JSON_END_HOUR);
        boolean startHourOnlyHour = json.getBoolean(JSON_START_HOUR_ONLY_HOUR);
        boolean endHourOnlyHour = json.getBoolean(JSON_END_HOUR_ONLY_HOUR);
        //dataManager.initHours(startHour, endHour);
        dataManager.newInitHours(startHour, endHour, startHourOnlyHour, endHourOnlyHour);
        dataManager.setSubject(json.getString(JSON_SUBJECT));
        dataManager.setSemester(json.getString(JSON_SEMESTER));
        dataManager.setNumber(json.getInt(JSON_NUMBER));
        dataManager.setYear(json.getInt(JSON_YEAR));
        dataManager.setTitle(json.getString(JSON_TITLE));
        dataManager.setInstructorName(json.getString(JSON_INSTRUCTOR_NAME));
        dataManager.setInstructorHome(json.getString(JSON_INSTRUCTOR_HOME));
        dataManager.setExportDir(json.getString(JSON_EXPORT_DIR));
        dataManager.setSiteTemplate(json.getString(JSON_SITE_TEMPLATE_DIR));
        dataManager.setBannerSchoolImage(json.getString(JSON_BANNER_SCHOOL_IMAGE));
        dataManager.setBannerLeftFooterImage(json.getString(JSON_LEFT_FOOTER_IMAGE));
        dataManager.setBannerRightFooterImage(json.getString(JSON_RIGHT_FOOTER_IMAGE));
        dataManager.setStylesheet(json.getString(JSON_STYLESHEET));
        dataManager.setStartingMonday(json.getString(JSON_STARTING_MONDAY));
        dataManager.setEndingFriday(json.getString(JSON_ENDING_FRIDAY));
        // NOW RELOAD THE WORKSPACE WITH THE LOADED DATA
        app.getWorkspaceComponent().reloadWorkspace(app.getDataComponent());

        // LOAD THE COURSE DETAILS
        JsonArray jsonPagesArray = json.getJsonArray(JSON_SITE_PAGES);
        dataManager.getSitePages().clear();
        for (int i = 0; i < jsonPagesArray.size(); i++) {
            JsonObject jsonPage = jsonPagesArray.getJsonObject(i);
            Boolean use = jsonPage.getBoolean(JSON_IN_USE);
            String title = jsonPage.getString(JSON_NAVBAR_TITLE);
            String file = jsonPage.getString(JSON_FILE_NAME);
            String script = jsonPage.getString(JSON_SCRIPT);
            //dataManager.addTA(name, email);
            //REMOVE OLD PAGES AND ADD NEW ONES
            dataManager.addPage(use, title, file, script);
        }
        
        // NOW LOAD ALL THE UNDERGRAD TAs
        JsonArray jsonTAArray = json.getJsonArray(JSON_UNDERGRAD_TAS);
        for (int i = 0; i < jsonTAArray.size(); i++) {
            JsonObject jsonTA = jsonTAArray.getJsonObject(i);
            String name = jsonTA.getString(JSON_NAME);
            String email = jsonTA.getString(JSON_EMAIL);
            Boolean undergrad = jsonTA.getBoolean(JSON_UNDERGRAD);
            //dataManager.addTA(name, email);
            dataManager.addTA(name, email, undergrad);
        }

        // AND THEN ALL THE OFFICE HOURS
        JsonArray jsonOfficeHoursArray = json.getJsonArray(JSON_OFFICE_HOURS);
        for (int i = 0; i < jsonOfficeHoursArray.size(); i++) {
            JsonObject jsonOfficeHours = jsonOfficeHoursArray.getJsonObject(i);
            String day = jsonOfficeHours.getString(JSON_DAY);
            String time = jsonOfficeHours.getString(JSON_TIME);
            String name = jsonOfficeHours.getString(JSON_NAME);
            dataManager.addOfficeHoursReservation(day, time, name);
        }
        
        //AND THE RECITATIONS
        JsonArray jsonRecitationArray = json.getJsonArray(JSON_RECITATIONS);
        for (int i = 0; i < jsonRecitationArray.size(); i++) {
            JsonObject jsonRec = jsonRecitationArray.getJsonObject(i);
            String section = jsonRec.getString(JSON_SECTION);
            String instructor = jsonRec.getString(JSON_INSTRUCTOR);
            String dayAndTime = jsonRec.getString(JSON_DAY_AND_TIME);
            String location = jsonRec.getString(JSON_LOCATION);
            String taOne = jsonRec.getString(JSON_TA_ONE);
            String taTwo = jsonRec.getString(JSON_TA_TWO);
            dataManager.addRecitation(section, instructor, dayAndTime, location, taOne, taTwo);
        }
        
        //AND THE SCHEDULES
        JsonArray jsonScheduleArray = json.getJsonArray(JSON_SCHEDULES);
        for (int i = 0; i < jsonScheduleArray.size(); i++) {
            JsonObject jsonSchedule = jsonScheduleArray.getJsonObject(i);
            String type = jsonSchedule.getString(JSON_TYPE);
            LocalDate date = dataManager.convertStringToLocalDate(jsonSchedule.getString(JSON_DATE));
            String time = jsonSchedule.getString(JSON_TIME);
            String title = jsonSchedule.getString(JSON_TITLE);
            String topic = jsonSchedule.getString(JSON_TOPIC);
            String link = jsonSchedule.getString(JSON_LINK);
            String criteria = jsonSchedule.getString(JSON_CRITERIA);
            dataManager.addSchedule(type, date, time, title, topic, link, criteria);
        }
        
        //AND THE TEAMS
        JsonArray jsonTeamArray = json.getJsonArray(JSON_TEAMS);
        for (int i = 0; i < jsonTeamArray.size(); i++) {
            JsonObject jsonTeam = jsonTeamArray.getJsonObject(i);
            String name = jsonTeam.getString(JSON_NAME);
            Color color = dataManager.convertStringToColor(jsonTeam.getString(JSON_COLOR));
            Color textColor = dataManager.convertStringToColor(jsonTeam.getString(JSON_TEXT_COLOR));
            String link = jsonTeam.getString(JSON_LINK);
            dataManager.addTeam(name, color, textColor, link);
        }
        
        //AND THE STUDENTS
        JsonArray jsonStudentArray = json.getJsonArray(JSON_STUDENTS);
        for (int i = 0; i < jsonStudentArray.size(); i++) {
            JsonObject jsonStudent = jsonStudentArray.getJsonObject(i);
            String firstName = jsonStudent.getString(JSON_FIRST_NAME);
            String lastName = jsonStudent.getString(JSON_LAST_NAME);
            String team = jsonStudent.getString(JSON_TEAM);
            String role = jsonStudent.getString(JSON_ROLE);
            dataManager.addStudent(firstName, lastName, team, role);
        }
    }
      
    // HELPER METHOD FOR LOADING DATA FROM A JSON FORMAT
    private JsonObject loadJSONFile(String jsonFilePath) throws IOException {
	InputStream is = new FileInputStream(jsonFilePath);
	JsonReader jsonReader = Json.createReader(is);
	JsonObject json = jsonReader.readObject();
	jsonReader.close();
	is.close();
	return json;
    }

    @Override
    public void saveData(AppDataComponent data, String filePath) throws IOException {
	// GET THE DATA
	CSGData dataManager = (CSGData)data;
        
        //NOW BUILD THE PAGE OBJECTS TO SAVE
        JsonArrayBuilder pageArrayBuilder = Json.createArrayBuilder();
	ObservableList<Page> pages = dataManager.getSitePages();
	for (Page page : pages) {	    
	    JsonObject pageJson = Json.createObjectBuilder()
		    .add(JSON_IN_USE, page.isUsed())
                    .add(JSON_NAVBAR_TITLE, page.getTitleName())
		    .add(JSON_FILE_NAME, page.getFileName())
                    .add(JSON_SCRIPT, page.getScriptName()).build();
	    pageArrayBuilder.add(pageJson);
	}
	JsonArray sitePagesArray = pageArrayBuilder.build();
        
	// NOW BUILD THE TA JSON OBJCTS TO SAVE
	JsonArrayBuilder taArrayBuilder = Json.createArrayBuilder();
	ObservableList<TeachingAssistant> tas = dataManager.getTeachingAssistants();
	for (TeachingAssistant ta : tas) {	    
	    JsonObject taJson = Json.createObjectBuilder()
		    .add(JSON_NAME, ta.getName())
                    .add(JSON_UNDERGRAD, ta.isUndergraduate())
		    .add(JSON_EMAIL, ta.getEmail()).build();
	    taArrayBuilder.add(taJson);
	}
	JsonArray undergradTAsArray = taArrayBuilder.build();

	// NOW BUILD THE TIME SLOT JSON OBJCTS TO SAVE
	JsonArrayBuilder timeSlotArrayBuilder = Json.createArrayBuilder();
	ArrayList<TimeSlot> officeHours = TimeSlot.buildOfficeHoursList(dataManager);
	for (TimeSlot ts : officeHours) {	    
	    JsonObject tsJson = Json.createObjectBuilder()
		    .add(JSON_DAY, ts.getDay())
		    .add(JSON_TIME, ts.getTime())
		    .add(JSON_NAME, ts.getName()).build();
	    timeSlotArrayBuilder.add(tsJson);
	}
	JsonArray timeSlotsArray = timeSlotArrayBuilder.build();
        
        //NOW BUILD THE RECITATION OBJECTS TO SAVE
        JsonArrayBuilder recitationArrayBuilder = Json.createArrayBuilder();
	ObservableList<Recitation> recitations = dataManager.getRecitations();
	for (Recitation rec : recitations) {	    
	    JsonObject recitationJson = Json.createObjectBuilder()
		    .add(JSON_SECTION, rec.getSection())
                    .add(JSON_INSTRUCTOR, rec.getInstructor())
		    .add(JSON_DAY_AND_TIME, rec.getDayAndTime())
                    .add(JSON_LOCATION, rec.getLocation())
                    .add(JSON_TA_ONE, rec.getTaOne())
                    .add(JSON_TA_TWO, rec.getTaTwo()).build();
	    recitationArrayBuilder.add(recitationJson);
	}
	JsonArray recitationsArray = recitationArrayBuilder.build();
        
        //NOW BUILD THE SCHEDULE OBJECTS TO SAVE
        JsonArrayBuilder scheduleArrayBuilder = Json.createArrayBuilder();
	ObservableList<Schedule> schedules = dataManager.getSchedules();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	for (Schedule sch : schedules) {	    
	    JsonObject scheduleJson = Json.createObjectBuilder()
		    .add(JSON_TYPE, sch.getType())
                    .add(JSON_DATE, dateFormatter.format(sch.getDate()))
		    .add(JSON_TIME, sch.getTime())
                    .add(JSON_TITLE, sch.getTitle())
                    .add(JSON_TOPIC, sch.getTopic())
                    .add(JSON_LINK, sch.getlink())
                    .add(JSON_CRITERIA, sch.getCriteria()).build();
	    scheduleArrayBuilder.add(scheduleJson);
	}
	JsonArray schedulesArray = scheduleArrayBuilder.build();
        
        //NOW BUILD THE TEAM OBJECTS TO SAVE
        JsonArrayBuilder teamArrayBuilder = Json.createArrayBuilder();
	ObservableList<Team> teams = dataManager.getTeams();
	for (Team team : teams) {	    
	    JsonObject teamJson = Json.createObjectBuilder()
		    .add(JSON_NAME, team.getName())
                    .add(JSON_COLOR, String.format("#%02X%02X%02X", (int)(team.getColor().getRed() * 255), (int)(team.getColor().getGreen() * 255), (int)(team.getColor().getBlue() * 255)))
		    .add(JSON_TEXT_COLOR, String.format("#%02X%02X%02X", (int)(team.getTextColor().getRed() * 255), (int)(team.getTextColor().getGreen() * 255), (int)(team.getTextColor().getBlue() * 255)))
                    .add(JSON_LINK, team.getLink()).build();
	    teamArrayBuilder.add(teamJson);
	}
	JsonArray teamsArray = teamArrayBuilder.build();
        
        //NOW BUILD THE STUDENT OBJECTS TO SAVE
        JsonArrayBuilder studentArrayBuilder = Json.createArrayBuilder();
	ObservableList<Student> students = dataManager.getStudents();
	for (Student st : students) {	    
	    JsonObject scheduleJson = Json.createObjectBuilder()
		    .add(JSON_FIRST_NAME, st.getFirstName())
		    .add(JSON_LAST_NAME, st.getLastName())
                    .add(JSON_TEAM, st.getTeam())
                    .add(JSON_ROLE, st.getRole()).build();
	    studentArrayBuilder.add(scheduleJson);
	}
	JsonArray studentsArray = studentArrayBuilder.build();
        
        //CHECK THE TEXTFIELDS BEFORE SAVING
	// THEN PUT IT ALL TOGETHER IN A JsonObject
	JsonObject dataManagerJSO = Json.createObjectBuilder()
		.add(JSON_START_HOUR, "" + dataManager.getStartHour())
		.add(JSON_END_HOUR, "" + dataManager.getEndHour())
                .add(JSON_START_HOUR_ONLY_HOUR, dataManager.getStartOnlyHour())
                .add(JSON_END_HOUR_ONLY_HOUR, dataManager.getEndOnlyHour())
                .add(JSON_SUBJECT, dataManager.getSubject())
                .add(JSON_NUMBER, dataManager.getNumber())
                .add(JSON_SEMESTER, dataManager.getSemester())
                .add(JSON_YEAR, dataManager.getYear())
                .add(JSON_TITLE, dataManager.getTitle())
                .add(JSON_INSTRUCTOR_NAME, dataManager.getInstructorName())
                .add(JSON_INSTRUCTOR_HOME, dataManager.getInstructorHome())
                .add(JSON_EXPORT_DIR, dataManager.getExportDir())
                .add(JSON_SITE_TEMPLATE_DIR, dataManager.getSiteTemplate())
                .add(JSON_BANNER_SCHOOL_IMAGE, dataManager.getBannerSchoolImage())
                .add(JSON_LEFT_FOOTER_IMAGE, dataManager.getBannerLeftFooterImage())
                .add(JSON_RIGHT_FOOTER_IMAGE, dataManager.getBannerRightFooterImage())
                .add(JSON_STYLESHEET, dataManager.getStylesheet())
                .add(JSON_STARTING_MONDAY, dateFormatter.format(dataManager.getStartingMonday()))
                .add(JSON_ENDING_FRIDAY, dateFormatter.format(dataManager.getEndingFriday()))
                .add(JSON_SITE_PAGES, sitePagesArray)
                .add(JSON_UNDERGRAD_TAS, undergradTAsArray)
                .add(JSON_OFFICE_HOURS, timeSlotsArray)
                .add(JSON_RECITATIONS, recitationsArray)
                .add(JSON_SCHEDULES, schedulesArray)
                .add(JSON_TEAMS, teamsArray)
                .add(JSON_STUDENTS, studentsArray)
		.build();
	
	// AND NOW OUTPUT IT TO A JSON FILE WITH PRETTY PRINTING
	Map<String, Object> properties = new HashMap<>(1);
	properties.put(JsonGenerator.PRETTY_PRINTING, true);
	JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
	StringWriter sw = new StringWriter();
	JsonWriter jsonWriter = writerFactory.createWriter(sw);
	jsonWriter.writeObject(dataManagerJSO);
	jsonWriter.close();

	// INIT THE WRITER
	OutputStream os = new FileOutputStream(filePath);
	JsonWriter jsonFileWriter = Json.createWriter(os);
	jsonFileWriter.writeObject(dataManagerJSO);
	String prettyPrinted = sw.toString();
	PrintWriter pw = new PrintWriter(filePath);
	pw.write(prettyPrinted);
	pw.close();
    }
    
    @Override
    public void createCustomOfficeHoursJson(String currentFile, String filePath) throws IOException {
	//LOAD THE JSON FILE WITH ALL THE DATA
	JsonObject json = loadJSONFile(currentFile);
        //CREATE THE GRAD AND UNDERGRAD TAS
        JsonArrayBuilder undergradArrayBuilder = Json.createArrayBuilder();
        JsonArrayBuilder gradArrayBuilder = Json.createArrayBuilder();
        JsonArray jsonUndergradArray = json.getJsonArray(JSON_UNDERGRAD_TAS);
        for (int i = 0; i < jsonUndergradArray.size(); i++) {
            JsonObject jsonUnder = jsonUndergradArray.getJsonObject(i);
            boolean undergrad = jsonUnder.getBoolean(JSON_UNDERGRAD);
            String name = jsonUnder.getString(JSON_NAME);
            String email = jsonUnder.getString(JSON_EMAIL);
            if(undergrad == true)
            {
                JsonObject finishedUndergradJson = Json.createObjectBuilder()
                    .add(JSON_NAME, name)
                    .add(JSON_EMAIL, email).build();
	    undergradArrayBuilder.add(finishedUndergradJson);
            }
            else
            {
                JsonObject finishedGradJson = Json.createObjectBuilder()
                    .add(JSON_NAME, name)
                    .add(JSON_EMAIL, email).build();
	    gradArrayBuilder.add(finishedGradJson);
            }
	}
	JsonArray finishedUndergradJsonArray = undergradArrayBuilder.build();
        JsonArray finishedGradJsonArray = gradArrayBuilder.build();
        //NOW LOAD THE OFFICE HOURS
        JsonArray jsonOfficeHoursArray = json.getJsonArray(JSON_OFFICE_HOURS);
        //CREATE THE OBJECT TO SAVE
        JsonObject dataManagerJSO = Json.createObjectBuilder()
                .add(JSON_START_HOUR, json.getString(JSON_START_HOUR))
		.add(JSON_END_HOUR, json.getString(JSON_END_HOUR))
                .add(JSON_SUBJECT, json.getString(JSON_SUBJECT))
                .add(JSON_NUMBER, json.getInt(JSON_NUMBER))
                .add(JSON_SEMESTER, json.getString(JSON_SEMESTER))
                .add(JSON_YEAR, json.getInt(JSON_YEAR))
                .add(JSON_TITLE, json.getString(JSON_TITLE))
                .add(JSON_INSTRUCTOR_NAME, json.getString(JSON_INSTRUCTOR_NAME))
                .add(JSON_INSTRUCTOR_HOME, json.getString(JSON_INSTRUCTOR_HOME))
                .add(JSON_BANNER_SCHOOL_IMAGE, json.getString(JSON_BANNER_SCHOOL_IMAGE).substring(json.getString(JSON_BANNER_SCHOOL_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_LEFT_FOOTER_IMAGE, json.getString(JSON_LEFT_FOOTER_IMAGE).substring(json.getString(JSON_LEFT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_RIGHT_FOOTER_IMAGE, json.getString(JSON_RIGHT_FOOTER_IMAGE).substring(json.getString(JSON_RIGHT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_STYLESHEET, json.getString(JSON_STYLESHEET))
                .add(JSON_UNDERGRAD_TAS, finishedUndergradJsonArray)
                .add(JSON_GRAD_TAS, finishedGradJsonArray)
                .add(JSON_OFFICE_HOURS, jsonOfficeHoursArray)
                .build();
        // AND NOW OUTPUT IT TO A JSON FILE WITH PRETTY PRINTING
	Map<String, Object> properties = new HashMap<>(1);
	properties.put(JsonGenerator.PRETTY_PRINTING, true);
	JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
	StringWriter sw = new StringWriter();
	JsonWriter jsonWriter = writerFactory.createWriter(sw);
	jsonWriter.writeObject(dataManagerJSO);
	jsonWriter.close();

	// INIT THE WRITER
        OutputStream os = new FileOutputStream(filePath + File.separator + OFFICE_HOURS_GRID_DATA);
	JsonWriter jsonFileWriter = Json.createWriter(os);
	jsonFileWriter.writeObject(dataManagerJSO);
	String prettyPrinted = sw.toString();
        PrintWriter pw = new PrintWriter(filePath + File.separator + OFFICE_HOURS_GRID_DATA);
	pw.write(prettyPrinted);
	pw.close();
    }
    
    @Override
    public void createCustomRecitationsJson(String currentFile, String filePath) throws IOException {
	//LOAD THE JSON FILE WITH ALL THE DATA
	JsonObject json = loadJSONFile(currentFile);
        //NOW BUILD THE RECITATIONS OBJECTS TO SAVE
        JsonArrayBuilder recitationArrayBuilder = Json.createArrayBuilder();
        JsonArray jsonRecitationArray = json.getJsonArray(JSON_RECITATIONS);
        for (int i = 0; i < jsonRecitationArray.size(); i++) {
            JsonObject jsonRec = jsonRecitationArray.getJsonObject(i);
            String section = "<strong>" + jsonRec.getString(JSON_SECTION) + "</strong>" + " (" + jsonRec.getString(JSON_INSTRUCTOR) + ")";
            String dayAndTime = jsonRec.getString(JSON_DAY_AND_TIME);
            String location = jsonRec.getString(JSON_LOCATION);
            String taOne = jsonRec.getString(JSON_TA_ONE);
            String taTwo = jsonRec.getString(JSON_TA_TWO);
            JsonObject finishedRecitationJson = Json.createObjectBuilder()
                    .add(JSON_SECTION, section)
                    .add(JSON_DAY_TIME, dayAndTime)
		    .add(JSON_LOCATION, location)
                    .add(JSON_TA_1, taOne)
                    .add(JSON_TA_2, taTwo).build();
	    recitationArrayBuilder.add(finishedRecitationJson);
	}
	JsonArray finishedRecitationJsonArray = recitationArrayBuilder.build();
        //CREATE THE OBJECT TO SAVE
        JsonObject dataManagerJSO = Json.createObjectBuilder()
                .add(JSON_RECITATIONS, finishedRecitationJsonArray)
                .build();
        // AND NOW OUTPUT IT TO A JSON FILE WITH PRETTY PRINTING
	Map<String, Object> properties = new HashMap<>(1);
	properties.put(JsonGenerator.PRETTY_PRINTING, true);
	JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
	StringWriter sw = new StringWriter();
	JsonWriter jsonWriter = writerFactory.createWriter(sw);
	jsonWriter.writeObject(dataManagerJSO);
	jsonWriter.close();

	// INIT THE WRITER
        OutputStream os = new FileOutputStream(filePath + File.separator + RECITATIONS_DATA);
	JsonWriter jsonFileWriter = Json.createWriter(os);
	jsonFileWriter.writeObject(dataManagerJSO);
	String prettyPrinted = sw.toString();
        PrintWriter pw = new PrintWriter(filePath + File.separator + RECITATIONS_DATA);
	pw.write(prettyPrinted);
	pw.close();
    }
    
    @Override
    public void createCustomSchedulesJson(String currentFile, String filePath) throws IOException {
	//LOAD THE JSON FILE WITH ALL THE DATA
	JsonObject json = loadJSONFile(currentFile);
        //CREATE THE DIFFERENT RECITATION ARRAYS
        JsonArrayBuilder schedulesHolidaysArrayBuilder = Json.createArrayBuilder();
        JsonArrayBuilder schedulesLecturesArrayBuilder = Json.createArrayBuilder();
        JsonArrayBuilder schedulesReferencesArrayBuilder = Json.createArrayBuilder();
        JsonArrayBuilder schedulesRecitationsArrayBuilder = Json.createArrayBuilder();
        JsonArrayBuilder schedulesHwsArrayBuilder = Json.createArrayBuilder();
        JsonArray jsonSchedulesArray = json.getJsonArray(JSON_SCHEDULES);
        for (int i = 0; i < jsonSchedulesArray.size(); i++) {
            JsonObject jsonsch = jsonSchedulesArray.getJsonObject(i);
            String type = jsonsch.getString(JSON_TYPE);
            String date = jsonsch.getString(JSON_DATE);
            String month = date.substring(0, 2);
            if(month.charAt(0) == '0')
            {
                month = month.substring(1);
            }
            String day = date.substring(3, 5);
            if(day.charAt(0) == '0')
            {
                day = day.substring(4);
            }
            String time = jsonsch.getString(JSON_TIME);
            String title = jsonsch.getString(JSON_TITLE);
            String topic = jsonsch.getString(JSON_TOPIC);
            String link = jsonsch.getString(JSON_LINK);
            String criteria = jsonsch.getString(JSON_CRITERIA);
            //SEPERATE THEM BY TYPE
            if(type.compareTo("Holiday") == 0)
            {
                JsonObject finishedScheduleJson = Json.createObjectBuilder()
                    .add(JSON_MONTH, month)
                    .add(JSON_DAY, day)
                    .add(JSON_TITLE, title)
                    .add(JSON_LINK, link).build();
                schedulesHolidaysArrayBuilder.add(finishedScheduleJson);
            }
            if(type.compareTo("Lecture") == 0)
            {
                JsonObject finishedScheduleJson = Json.createObjectBuilder()
                    .add(JSON_MONTH, month)
                    .add(JSON_DAY, day)
                    .add(JSON_TITLE, title)
                    .add(JSON_TOPIC, topic)
                    .add(JSON_LINK, link).build();
                schedulesLecturesArrayBuilder.add(finishedScheduleJson);
            }
            if(type.compareTo("Reference") == 0)
            {
                JsonObject finishedScheduleJson = Json.createObjectBuilder()
                    .add(JSON_MONTH, month)
                    .add(JSON_DAY, day)
                    .add(JSON_TITLE, title)
                    .add(JSON_TOPIC, topic)
                    .add(JSON_LINK, link).build();
                schedulesReferencesArrayBuilder.add(finishedScheduleJson);
            }
            if(type.compareTo("Recitation") == 0)
            {
                JsonObject finishedScheduleJson = Json.createObjectBuilder()
                    .add(JSON_MONTH, month)
                    .add(JSON_DAY, day)
                    .add(JSON_TITLE, title)
                    .add(JSON_TOPIC, topic).build();
                schedulesRecitationsArrayBuilder.add(finishedScheduleJson);
            }
            if(type.compareTo("Homework") == 0)
            {
                JsonObject finishedScheduleJson = Json.createObjectBuilder()
                    .add(JSON_MONTH, month)
                    .add(JSON_DAY, day)
                    .add(JSON_TITLE, title)
                    .add(JSON_TOPIC, topic)
                    .add(JSON_LINK, link)
                    .add(JSON_TIME, time)
                    .add(JSON_CRITERIA, criteria).build();
                schedulesHwsArrayBuilder.add(finishedScheduleJson);
            } 
	}
	JsonArray finishedScheduleHolidaysJsonArray = schedulesHolidaysArrayBuilder.build();
        JsonArray finishedScheduleLecturesJsonArray = schedulesLecturesArrayBuilder.build();
        JsonArray finishedScheduleReferencesJsonArray = schedulesReferencesArrayBuilder.build();
        JsonArray finishedScheduleRecittionsJsonArray = schedulesRecitationsArrayBuilder.build();
        JsonArray finishedScheduleHWsJsonArray = schedulesHwsArrayBuilder.build();
        //CREATE THE OBJECT TO SAVE
        JsonObject dataManagerJSO = Json.createObjectBuilder()
                .add(JSON_SUBJECT, json.getString(JSON_SUBJECT))
                .add(JSON_NUMBER, json.getInt(JSON_NUMBER))
                .add(JSON_SEMESTER, json.getString(JSON_SEMESTER))
                .add(JSON_YEAR, json.getInt(JSON_YEAR))
                .add(JSON_TITLE, json.getString(JSON_TITLE))
                .add(JSON_BANNER_SCHOOL_IMAGE, json.getString(JSON_BANNER_SCHOOL_IMAGE).substring(json.getString(JSON_BANNER_SCHOOL_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_LEFT_FOOTER_IMAGE, json.getString(JSON_LEFT_FOOTER_IMAGE).substring(json.getString(JSON_LEFT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_RIGHT_FOOTER_IMAGE, json.getString(JSON_RIGHT_FOOTER_IMAGE).substring(json.getString(JSON_RIGHT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_STYLESHEET, json.getString(JSON_STYLESHEET))
                .add(JSON_STARTING_MONDAY_MONTH, json.getString(JSON_STARTING_MONDAY).substring(0, 2))
                .add(JSON_STARTING_MONDAY_DAY, json.getString(JSON_STARTING_MONDAY).substring(3, 5))
                .add(JSON_ENDING_FRIDAY_MONTH, json.getString(JSON_ENDING_FRIDAY).substring(0, 2))
                .add(JSON_ENDING_FRIDAY_DAY, json.getString(JSON_ENDING_FRIDAY).substring(3, 5))
                .add(JSON_HOLIDAYS, finishedScheduleHolidaysJsonArray)
                .add(JSON_LECTURES, finishedScheduleLecturesJsonArray)
                .add(JSON_REFERENCES, finishedScheduleReferencesJsonArray)
                .add(JSON_RECITATIONS, finishedScheduleRecittionsJsonArray)
                .add(JSON_HWS, finishedScheduleHWsJsonArray).build();
        // AND NOW OUTPUT IT TO A JSON FILE WITH PRETTY PRINTING
	Map<String, Object> properties = new HashMap<>(1);
	properties.put(JsonGenerator.PRETTY_PRINTING, true);
	JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
	StringWriter sw = new StringWriter();
	JsonWriter jsonWriter = writerFactory.createWriter(sw);
	jsonWriter.writeObject(dataManagerJSO);
	jsonWriter.close();

	// INIT THE WRITER
        OutputStream os = new FileOutputStream(filePath + File.separator + SCHEDULE_DATA);
	JsonWriter jsonFileWriter = Json.createWriter(os);
	jsonFileWriter.writeObject(dataManagerJSO);
	String prettyPrinted = sw.toString();
        PrintWriter pw = new PrintWriter(filePath + File.separator + SCHEDULE_DATA);
	pw.write(prettyPrinted);
	pw.close();
    }
    
    @Override
    public void createCustomTeamAndStudentsJson(String currentFile, String filePath) throws IOException {
	//LOAD THE JSON FILE WITH ALL THE DATA
	JsonObject json = loadJSONFile(currentFile);
        //NOW BUILD THE RECITATIONS OBJECTS TO SAVE
        JsonArrayBuilder projectTeamsArrayBuilder = Json.createArrayBuilder();
        JsonArrayBuilder projectStudentsArrayBuilder = Json.createArrayBuilder();
        JsonArray jsonTeamArray = json.getJsonArray(JSON_TEAMS);
        JsonArray jsonStudentArray = json.getJsonArray(JSON_STUDENTS);
        for (int i = 0; i < jsonTeamArray.size(); i++) {
            JsonObject jsonTeam = jsonTeamArray.getJsonObject(i);
            String name = jsonTeam.getString(JSON_NAME);
            String colorRed = Integer.valueOf(jsonTeam.getString(JSON_COLOR).substring( 1, 3 ), 16) + "";
            String colorGreen = Integer.valueOf(jsonTeam.getString(JSON_COLOR).substring( 3, 5 ), 16) + "";
            String colorBlue = Integer.valueOf(jsonTeam.getString(JSON_COLOR).substring( 5, 7 ), 16) + "";
            String textColor = jsonTeam.getString(JSON_TEXT_COLOR);
            JsonObject finishedTeamJson = Json.createObjectBuilder()
                    .add(JSON_NAME, name)
                    .add(JSON_RED, colorRed)
		    .add(JSON_GREEN, colorGreen)
                    .add(JSON_BLUE, colorBlue)
                    .add(JSON_TEXT_COLOR, textColor).build();
	    projectTeamsArrayBuilder.add(finishedTeamJson);
	}
        for (int i = 0; i < jsonStudentArray.size(); i++) {
            JsonObject jsonStudent = jsonStudentArray.getJsonObject(i);
            String lastName = jsonStudent.getString(JSON_LAST_NAME);
            String firstName = jsonStudent.getString(JSON_FIRST_NAME);
            String team = jsonStudent.getString(JSON_TEAM);
            String role = jsonStudent.getString(JSON_ROLE);
            JsonObject finishedStudentJson = Json.createObjectBuilder()
                    .add(JSON_LASTNAME, lastName)
                    .add(JSON_FIRSTNAME, firstName)
		    .add(JSON_TEAM, team)
                    .add(JSON_ROLE, role).build();
	    projectStudentsArrayBuilder.add(finishedStudentJson);
	}
	JsonArray finishedProjectsArray = projectTeamsArrayBuilder.build();
        JsonArray finishedStudentsArray = projectStudentsArrayBuilder.build();
        //CREATE THE OBJECT TO SAVE
        JsonObject dataManagerJSO = Json.createObjectBuilder()
                .add(JSON_SUBJECT, json.getString(JSON_SUBJECT))
                .add(JSON_NUMBER, json.getInt(JSON_NUMBER))
                .add(JSON_SEMESTER, json.getString(JSON_SEMESTER))
                .add(JSON_YEAR, json.getInt(JSON_YEAR))
                .add(JSON_TITLE, json.getString(JSON_TITLE))
                .add(JSON_BANNER_SCHOOL_IMAGE, json.getString(JSON_BANNER_SCHOOL_IMAGE).substring(json.getString(JSON_BANNER_SCHOOL_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_LEFT_FOOTER_IMAGE, json.getString(JSON_LEFT_FOOTER_IMAGE).substring(json.getString(JSON_LEFT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_RIGHT_FOOTER_IMAGE, json.getString(JSON_RIGHT_FOOTER_IMAGE).substring(json.getString(JSON_RIGHT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_STYLESHEET, json.getString(JSON_STYLESHEET))
                .add(JSON_TEAMS, finishedProjectsArray)
                .add(JSON_STUDENTS, finishedStudentsArray)
                .build();
        // AND NOW OUTPUT IT TO A JSON FILE WITH PRETTY PRINTING
	Map<String, Object> properties = new HashMap<>(1);
	properties.put(JsonGenerator.PRETTY_PRINTING, true);
	JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
	StringWriter sw = new StringWriter();
	JsonWriter jsonWriter = writerFactory.createWriter(sw);
	jsonWriter.writeObject(dataManagerJSO);
	jsonWriter.close();

	// INIT THE WRITER
        OutputStream os = new FileOutputStream(filePath + File.separator + TEAMS_AND_STUDENTS);
	JsonWriter jsonFileWriter = Json.createWriter(os);
	jsonFileWriter.writeObject(dataManagerJSO);
	String prettyPrinted = sw.toString();
        PrintWriter pw = new PrintWriter(filePath + File.separator + TEAMS_AND_STUDENTS);
	pw.write(prettyPrinted);
	pw.close();
    }
    // IMPORTING/EXPORTING DATA IS USED WHEN WE READ/WRITE DATA IN AN
    // ADDITIONAL FORMAT USEFUL FOR ANOTHER PURPOSE, LIKE ANOTHER APPLICATION

    @Override
    public void createCustomProjectsJson(String currentFile, String filePath) throws IOException {
	//LOAD THE JSON FILE WITH ALL THE DATA
	JsonObject json = loadJSONFile(currentFile);
        //NOW BUILD THE RECITATIONS OBJECTS TO SAVE
        JsonArrayBuilder projectsArrayBuilder = Json.createArrayBuilder();
        JsonArrayBuilder workArrayBuilder = Json.createArrayBuilder();
        JsonArray jsonTeamsArray = json.getJsonArray(JSON_TEAMS);
        JsonArray jsonStudentsArray = json.getJsonArray(JSON_STUDENTS);
        for (int i = 0; i < jsonTeamsArray.size(); i++) {
            JsonObject jsonTeam = jsonTeamsArray.getJsonObject(i);
            String team = jsonTeam.getString(JSON_NAME);
            JsonArrayBuilder studentsArrayBuilder = Json.createArrayBuilder();
            //GET THE STUDENTS AND ADD THEM
            for (int j = 0; j < jsonStudentsArray.size(); j++)
            {
                String firstNameLastName = "";
                JsonObject jsonStudent = jsonStudentsArray.getJsonObject(j);
                if(team.compareTo(jsonStudent.getString(JSON_TEAM)) == 0)
                {
                    firstNameLastName = firstNameLastName + jsonStudent.getString(JSON_FIRST_NAME) + " " + jsonStudent.getString(JSON_LAST_NAME);
                    studentsArrayBuilder.add(firstNameLastName);
                }
            }
            JsonArray finishedStudentsArray = studentsArrayBuilder.build();
            String link = jsonTeam.getString(JSON_LINK);
            JsonObject finishedProjectJson = Json.createObjectBuilder()
                    .add(JSON_NAME, team)
                    .add(JSON_STUDENTS, finishedStudentsArray)
                    .add(JSON_LINK, link).build();
	    projectsArrayBuilder.add(finishedProjectJson);
	}
	JsonArray finishedProjectArray = projectsArrayBuilder.build();
        //PUT IT ALL IN 1 ARRAY
        JsonObject finishedWorkJson = Json.createObjectBuilder()
                .add(JSON_SEMESTER, json.getString(JSON_SEMESTER) + " " + json.getInt(JSON_YEAR))
                .add(JSON_PROJECTS, finishedProjectArray).build();
        workArrayBuilder.add(finishedWorkJson);
        JsonArray finishedWorkArray = workArrayBuilder.build();
        //CREATE THE OBJECT TO SAVE
        JsonObject dataManagerJSO = Json.createObjectBuilder()
                .add(JSON_SUBJECT, json.getString(JSON_SUBJECT))
                .add(JSON_NUMBER, json.getInt(JSON_NUMBER))
                .add(JSON_SEMESTER_DATA, json.getString(JSON_SEMESTER))
                .add(JSON_YEAR, json.getInt(JSON_YEAR))
                .add(JSON_TITLE, json.getString(JSON_TITLE))
                .add(JSON_BANNER_SCHOOL_IMAGE, json.getString(JSON_BANNER_SCHOOL_IMAGE).substring(json.getString(JSON_BANNER_SCHOOL_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_LEFT_FOOTER_IMAGE, json.getString(JSON_LEFT_FOOTER_IMAGE).substring(json.getString(JSON_LEFT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_RIGHT_FOOTER_IMAGE, json.getString(JSON_RIGHT_FOOTER_IMAGE).substring(json.getString(JSON_RIGHT_FOOTER_IMAGE).lastIndexOf('\\') + 1))
                .add(JSON_STYLESHEET, json.getString(JSON_STYLESHEET))
                .add(JSON_WORK, finishedWorkArray)
                .build();
        // AND NOW OUTPUT IT TO A JSON FILE WITH PRETTY PRINTING
	Map<String, Object> properties = new HashMap<>(1);
	properties.put(JsonGenerator.PRETTY_PRINTING, true);
	JsonWriterFactory writerFactory = Json.createWriterFactory(properties);
	StringWriter sw = new StringWriter();
	JsonWriter jsonWriter = writerFactory.createWriter(sw);
	jsonWriter.writeObject(dataManagerJSO);
	jsonWriter.close();

	// INIT THE WRITER
        OutputStream os = new FileOutputStream(filePath + File.separator + PROJECTS_DATA);
	JsonWriter jsonFileWriter = Json.createWriter(os);
	jsonFileWriter.writeObject(dataManagerJSO);
	String prettyPrinted = sw.toString();
        PrintWriter pw = new PrintWriter(filePath + File.separator + PROJECTS_DATA);
	pw.write(prettyPrinted);
	pw.close();
    }
    
    @Override
    public void importData(AppDataComponent data, String filePath) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void exportData(String currentFile, AppDataComponent data) throws IOException {
        CSGData dataManager = (CSGData)data;
        String filePath = dataManager.getExportDir();
        String fromPath = dataManager.getSiteTemplate();
        JsonObject json = loadJSONFile(currentFile);
        JsonArray jsonPageArray = json.getJsonArray(JSON_SITE_PAGES);
        for (int i = 0; i < jsonPageArray.size(); i++) 
        {
            JsonObject jsonPage = jsonPageArray.getJsonObject(i);
            String name = jsonPage.getString(JSON_NAVBAR_TITLE);
            boolean inUse = jsonPage.getBoolean(JSON_IN_USE);
            if(name.compareTo(HOME) == 0)
            {
                if(inUse == true)
                {
                    exportHome(currentFile, filePath, fromPath);
                }
            }
            if(name.compareTo(SYLLABUS) == 0)
            {
                if(inUse == true)
                {
                    exportSyllabus(currentFile, filePath, fromPath);
                }
            }
            if(name.compareTo(SCHEDULE) == 0)
            {
                if(inUse == true)
                {
                    exportSchedule(currentFile, filePath, fromPath);
                }
            }
            if(name.compareTo(HWS) == 0)
            {
                if(inUse == true)
                {
                    exportHws(currentFile, filePath, fromPath);
                }
            }
            if(name.compareTo(PROJECTS) == 0)
            {
                if(inUse == true)
                {
                    exportProjects(currentFile, filePath, fromPath);
                }
            }
        }
    }
    
    public void exportHome(String currentFile, String filePath, String fromPath) throws IOException
    {
        JsonObject json = loadJSONFile(currentFile);
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        //CHECK FOR A HOME FOLDER
        //CREATE DIRECTORIES IF THEY DO NOT EXIST
        File destHomeFolder = new File(filePath + File.separator + HOME);
        if(!destHomeFolder.exists())
        {
            try
            {
                destHomeFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destJsFolder = new File(filePath + File.separator + HOME + File.separator + "js");
        if(!destJsFolder.exists())
        {
            try
            {
                destJsFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destCssFolder = new File(filePath + File.separator + HOME + File.separator + "css");
        if(!destCssFolder.exists())
        {
            try
            {
                destCssFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destImageFolder = new File(filePath + File.separator + HOME + File.separator + "images");
        if(!destImageFolder.exists())
        {
            try
            {
                destImageFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        //GET THE INDEX FILE
        File fromFile = new File(fromPath + File.separator + HOME + File.separator + "index.htm");
        //MOVE IT TO THE DESTINATION
        File destFile = new File(filePath + File.separator + HOME + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE CSS
        fromFile = new File(PATH_WORK + File.separator + "css" + File.separator + json.getString(JSON_STYLESHEET));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HOME + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE BANNER IMAGE
        fromFile = new File(json.getString(JSON_BANNER_SCHOOL_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HOME + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_LEFT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HOME + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_RIGHT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HOME + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT CSS
        fromFile = new File(PATH_WORK + File.separator + "templates" + File.separator + "course_homepage_layout.css");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HOME + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT JS
        fromFile = new File(fromPath + File.separator + HOME + File.separator + "js" + File.separator + "TeamsBuilder.js");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HOME + File.separator + "js" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE NEW JSON LOCATION
        File newJson = new File(filePath + File.separator + HOME + File.separator + "js" + File.separator);
        createCustomTeamAndStudentsJson(currentFile, newJson.getAbsolutePath());
    }
    
    public void exportSyllabus(String currentFile, String filePath, String fromPath) throws IOException
    {
        JsonObject json = loadJSONFile(currentFile);
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        //CHECK FOR A HOME FOLDER
        //CREATE DIRECTORIES IF THEY DO NOT EXIST
        File destHomeFolder = new File(filePath + File.separator + SYLLABUS);
        if(!destHomeFolder.exists())
        {
            try
            {
                destHomeFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destJsFolder = new File(filePath + File.separator + SYLLABUS + File.separator + "js");
        if(!destJsFolder.exists())
        {
            try
            {
                destJsFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destCssFolder = new File(filePath + File.separator + SYLLABUS + File.separator + "css");
        if(!destCssFolder.exists())
        {
            try
            {
                destCssFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destImageFolder = new File(filePath + File.separator + SYLLABUS + File.separator + "images");
        if(!destImageFolder.exists())
        {
            try
            {
                destImageFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        //GET THE INDEX FILE
        File fromFile = new File(fromPath + File.separator + SYLLABUS + File.separator + "syllabus.html");
        //MOVE IT TO THE DESTINATION
        File destFile = new File(filePath + File.separator + SYLLABUS + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE CSS
        fromFile = new File(PATH_WORK + File.separator + "css" + File.separator + json.getString(JSON_STYLESHEET));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SYLLABUS + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE BANNER IMAGE
        fromFile = new File(json.getString(JSON_BANNER_SCHOOL_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SYLLABUS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_LEFT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SYLLABUS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_RIGHT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SYLLABUS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT CSS
        fromFile = new File(PATH_WORK + File.separator + "templates" + File.separator + "course_homepage_layout.css");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SYLLABUS + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT JS
        fromFile = new File(fromPath + File.separator + SYLLABUS + File.separator + "js" + File.separator + "OfficeHoursGridBuilder.js");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SYLLABUS + File.separator + "js" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        fromFile = new File(fromPath + File.separator + SYLLABUS + File.separator + "js" + File.separator + "RecitationsBuilder.js");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SYLLABUS + File.separator + "js" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE NEW JSON LOCATION
        File newJson = new File(filePath + File.separator + SYLLABUS + File.separator + "js" + File.separator);
        createCustomOfficeHoursJson(currentFile, newJson.getAbsolutePath());
        createCustomRecitationsJson(currentFile, newJson.getAbsolutePath());
    }
    
    public void exportSchedule(String currentFile, String filePath, String fromPath) throws IOException
    {
        JsonObject json = loadJSONFile(currentFile);
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        //CHECK FOR A HOME FOLDER
        //CREATE DIRECTORIES IF THEY DO NOT EXIST
        File destHomeFolder = new File(filePath + File.separator + SCHEDULE);
        if(!destHomeFolder.exists())
        {
            try
            {
                destHomeFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destJsFolder = new File(filePath + File.separator + SCHEDULE + File.separator + "js");
        if(!destJsFolder.exists())
        {
            try
            {
                destJsFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destCssFolder = new File(filePath + File.separator + SCHEDULE + File.separator + "css");
        if(!destCssFolder.exists())
        {
            try
            {
                destCssFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destImageFolder = new File(filePath + File.separator + SCHEDULE + File.separator + "images");
        if(!destImageFolder.exists())
        {
            try
            {
                destImageFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        //GET THE INDEX FILE
        File fromFile = new File(fromPath + File.separator + SCHEDULE + File.separator + "schedule.htm");
        //MOVE IT TO THE DESTINATION
        File destFile = new File(filePath + File.separator + SCHEDULE + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE CSS
        fromFile = new File(PATH_WORK + File.separator + "css" + File.separator + json.getString(JSON_STYLESHEET));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SCHEDULE + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE BANNER IMAGE
        fromFile = new File(json.getString(JSON_BANNER_SCHOOL_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SCHEDULE + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_LEFT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SCHEDULE + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_RIGHT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SCHEDULE + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT CSS
        fromFile = new File(PATH_WORK + File.separator + "templates" + File.separator + "course_homepage_layout.css");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SCHEDULE + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT JS
        fromFile = new File(fromPath + File.separator + SCHEDULE + File.separator + "js" + File.separator + "ScheduleBuilder.js");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + SCHEDULE + File.separator + "js" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE NEW JSON LOCATION
        File newJson = new File(filePath + File.separator + SCHEDULE + File.separator + "js" + File.separator);
        createCustomSchedulesJson(currentFile, newJson.getAbsolutePath());
    }
    public void exportHws(String currentFile, String filePath, String fromPath) throws IOException
    {
        JsonObject json = loadJSONFile(currentFile);
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        //CHECK FOR A HOME FOLDER
        //CREATE DIRECTORIES IF THEY DO NOT EXIST
        File destHomeFolder = new File(filePath + File.separator + HWS);
        if(!destHomeFolder.exists())
        {
            try
            {
                destHomeFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destJsFolder = new File(filePath + File.separator + HWS + File.separator + "js");
        if(!destJsFolder.exists())
        {
            try
            {
                destJsFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destCssFolder = new File(filePath + File.separator + HWS + File.separator + "css");
        if(!destCssFolder.exists())
        {
            try
            {
                destCssFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destImageFolder = new File(filePath + File.separator + HWS + File.separator + "images");
        if(!destImageFolder.exists())
        {
            try
            {
                destImageFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        //GET THE INDEX FILE
        File fromFile = new File(fromPath + File.separator + HWS + File.separator + "hws.htm");
        //MOVE IT TO THE DESTINATION
        File destFile = new File(filePath + File.separator + HWS + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE CSS
        fromFile = new File(PATH_WORK + File.separator + "css" + File.separator + json.getString(JSON_STYLESHEET));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HWS + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE BANNER IMAGE
        fromFile = new File(json.getString(JSON_BANNER_SCHOOL_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HWS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_LEFT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HWS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_RIGHT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HWS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT CSS
        fromFile = new File(PATH_WORK + File.separator + "templates" + File.separator + "course_homepage_layout.css");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HWS + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT JS
        fromFile = new File(fromPath + File.separator + HWS + File.separator + "js" + File.separator + "HWsBuilder.js");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + HWS + File.separator + "js" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE NEW JSON LOCATION
        File newJson = new File(filePath + File.separator + HWS + File.separator + "js" + File.separator);
        createCustomSchedulesJson(currentFile, newJson.getAbsolutePath());
    }
    
    public void exportProjects(String currentFile, String filePath, String fromPath) throws IOException
    {
        JsonObject json = loadJSONFile(currentFile);
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        //CHECK FOR A HOME FOLDER
        //CREATE DIRECTORIES IF THEY DO NOT EXIST
        File destHomeFolder = new File(filePath + File.separator + PROJECTS);
        if(!destHomeFolder.exists())
        {
            try
            {
                destHomeFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destJsFolder = new File(filePath + File.separator + PROJECTS + File.separator + "js");
        if(!destJsFolder.exists())
        {
            try
            {
                destJsFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destCssFolder = new File(filePath + File.separator + PROJECTS + File.separator + "css");
        if(!destCssFolder.exists())
        {
            try
            {
                destCssFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        File destImageFolder = new File(filePath + File.separator + PROJECTS + File.separator + "images");
        if(!destImageFolder.exists())
        {
            try
            {
                destImageFolder.mkdir();
            }
            catch(SecurityException se)
            {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(CSGProp.LOAD_ERROR_TITLE.toString()), props.getProperty(CSGProp.EXPORT_ERROR_MESSAGE.toString()));
            }
        }
        //GET THE INDEX FILE
        File fromFile = new File(fromPath + File.separator + PROJECTS + File.separator + "projects.htm");
        //MOVE IT TO THE DESTINATION
        File destFile = new File(filePath + File.separator + PROJECTS + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE CSS
        fromFile = new File(PATH_WORK + File.separator + "css" + File.separator + json.getString(JSON_STYLESHEET));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + PROJECTS + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE BANNER IMAGE
        fromFile = new File(json.getString(JSON_BANNER_SCHOOL_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + PROJECTS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_LEFT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + PROJECTS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE LEFT BANNER IMAGE
        fromFile = new File(json.getString(JSON_RIGHT_FOOTER_IMAGE));
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + PROJECTS + File.separator + "images" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT CSS
        fromFile = new File(PATH_WORK + File.separator + "templates" + File.separator + "course_homepage_layout.css");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + PROJECTS + File.separator + "css" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE DEFAULT JS
        fromFile = new File(fromPath + File.separator + PROJECTS + File.separator + "js" + File.separator + "ProjectsBuilder.js");
        //MOVE IT TO THE DESTINATION
        destFile = new File(filePath + File.separator + PROJECTS + File.separator + "js" + File.separator + fromFile.getName());
        Files.copy(fromFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //GET THE NEW JSON LOCATION
        File newJson = new File(filePath + File.separator + PROJECTS + File.separator + "js" + File.separator);
        createCustomProjectsJson(currentFile, newJson.getAbsolutePath());
    }
}