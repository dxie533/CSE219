/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.data;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author David Xie
 */
public class Recitation<E extends Comparable<E>> implements Comparable<E> {
    //THE TABLE WILL STORE RECITATIONS
    private final StringProperty section;
    private final StringProperty instructor;
    private final StringProperty dayAndTime;
    private final StringProperty location;
    private final StringProperty taOne;
    private final StringProperty taTwo;
    
    public Recitation(String initSection, String initInstructor, String initDayAndTime, String initLocation, String initTAOne, String initTATwo) {
        section = new SimpleStringProperty(initSection);
        instructor = new SimpleStringProperty(initInstructor);
        dayAndTime = new SimpleStringProperty(initDayAndTime);
        location = new SimpleStringProperty(initLocation);
        taOne = new SimpleStringProperty(initTAOne);
        taTwo = new SimpleStringProperty(initTATwo);
    }
    
    //ACCESSORS AND STUFF
    
    public String getSection()
    {
        return section.get();
    }
    
    public void setSection(String initSection) {
        section.set(initSection);
    }
    
    public String getInstructor()
    {
        return instructor.get();
    }
    
    public void setInstructor(String initInstructor) {
        instructor.set(initInstructor);
    }
    
    public String getDayAndTime()
    {
        return dayAndTime.get();
    }
    
    public void setDayAndTime(String initDayAndTime)
    {
        dayAndTime.set(initDayAndTime);
    }
    
    public String getLocation()
    {
        return location.get();
    }
    
    public void setLocation(String initLocation)
    {
        location.set(initLocation);
    }
    
    public String getTaOne()
    {
        return taOne.get();
    }
    
    public void setTAOne(String initTA)
    {
        taOne.set(initTA);
    }
    
    public String getTaTwo()
    {
        return taTwo.get();
    }
    
    public void setTATwo(String initTA)
    {
        taTwo.set(initTA);
    }
    
    @Override
    public int compareTo(E otherRecitation) {
        return getSection().compareTo(((Recitation)otherRecitation).getSection());
    }
    
    @Override
    public String toString() {
        return section.getValue();
    }
}
