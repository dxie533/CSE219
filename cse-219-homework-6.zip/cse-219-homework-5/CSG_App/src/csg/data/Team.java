/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.data;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.paint.Color;

/**
 *
 * @author David Xie
 */
public class Team<E extends Comparable<E>> implements Comparable<E> {
    private final StringProperty name;
    private final ObjectProperty<Color> color;
    private final ObjectProperty<Color> textColor;
    private final StringProperty link;
    
    public Team(String initName, Color initColor, Color initTextColor, String initLink)
    {
        name = new SimpleStringProperty(initName);
        color = new SimpleObjectProperty(initColor);
        textColor = new SimpleObjectProperty(initTextColor);
        link = new SimpleStringProperty(initLink);
    }
    
    public String getName()
    {
        return name.get();
    }
    
    public void setName(String initName) {
        name.set(initName);
    }
    
    public Color getColor()
    {
        return color.get();
    }
    
    public void setColor(Color initColor) {
        color.set(initColor);
    }
    
    public ObjectProperty colorProperty()
    {
        return color;
    }
    
    public Color getTextColor()
    {
        return textColor.get();
    }
    
    public void setTextColor(Color initTextColor) {
        textColor.set(initTextColor);
    }
    
    public ObjectProperty textColorProperty()
    {
        return textColor;
    }
    
    public String getLink()
    {
        return link.get();
    }
    
    public void setLink(String initLink) {
        link.set(initLink);
    }
    
    @Override
    public int compareTo(E otherTeam) {
        return getName().compareTo(((Team)otherTeam).getName());
    }
    
    @Override
    public String toString() {
        return name.getValue();
    }
}