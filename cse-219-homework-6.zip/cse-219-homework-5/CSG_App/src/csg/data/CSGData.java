package csg.data;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import djf.components.AppDataComponent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import javafx.beans.property.StringProperty;
import properties_manager.PropertiesManager;
import csg.CSGApp;
import csg.CSGProp;
import csg.file.TimeSlot;
import csg.workspace.CSGWorkspace;
import static djf.settings.AppStartupConstants.FILE_PROTOCOL;
import static djf.settings.AppStartupConstants.PATH_WORK;
import java.io.File;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

/**
 * This is the data component for CSGApp. It has all the data needed
 * to be set by the user via the User Interface and file I/O can set and get
 * all the data from this object
 * 
 * @author Richard McKenna
 */
public class CSGData implements AppDataComponent {

    // WE'LL NEED ACCESS TO THE APP TO NOTIFY THE GUI WHEN DATA CHANGES
    CSGApp app;

    // NOTE THAT THIS DATA STRUCTURE WILL DIRECTLY STORE THE
    // DATA IN THE ROWS OF THE TABLE VIEW
    ObservableList<TeachingAssistant> teachingAssistants;
    
    ObservableList<Page> sitePages;
    
    ObservableList<Recitation> recitations;
    
    ObservableList<Schedule> schedules;
    
    ObservableList<Team> teams;
    
    ObservableList<Student> students;

    // THIS WILL STORE ALL THE OFFICE HOURS GRID DATA, WHICH YOU
    // SHOULD NOTE ARE StringProperty OBJECTS THAT ARE CONNECTED
    // TO UI LABELS, WHICH MEANS IF WE CHANGE VALUES IN THESE
    // PROPERTIES IT CHANGES WHAT APPEARS IN THOSE LABELS
    HashMap<String, StringProperty> officeHours;
    
    // THESE ARE THE LANGUAGE-DEPENDENT VALUES FOR
    // THE OFFICE HOURS GRID HEADERS. NOTE THAT WE
    // LOAD THESE ONCE AND THEN HANG ON TO THEM TO
    // INITIALIZE OUR OFFICE HOURS GRID
    ArrayList<String> gridHeaders;

    // THESE ARE THE TIME BOUNDS FOR THE OFFICE HOURS GRID.
    int startHour;
    boolean startHourOnlyHour;
    int endHour;
    boolean endHourOnlyHour;
    
    //ALL THE POSSIBLE HOURS
    ArrayList<String> allHours;
    
    //ALL THE YEARS
    ArrayList<String> allSubjects;
    
    //ALL THE NUMBERS
    ArrayList<String> allNumbers;
    
    //ALL THE SEMESTERS
    ArrayList<String> allSemesters;
    
    //ALL THE YEARS
    ArrayList<String> allYears;
    
    //ALL THE CSS
    ArrayList<String> allCSS;
    
    //ALL THE TYPES
    ArrayList<String> allTypes;
    
    // DEFAULT VALUES FOR START AND END HOURS IN MILITARY HOURS
    public static final int MIN_START_HOUR = 9;
    public static final int MAX_END_HOUR = 20;
    public static final boolean DEFAULT_START_HOUR_ONLY_HOUR = true;
    public static final boolean DEFAULT_END_HOUR_ONLY_HOUR = true;

    //DEFAULT VALUES FOR THE BANNER IMAGES
    /*
    public static final String DEFAULT_BANNER = FILE_PROTOCOL + PATH_WORK + File.separator + "brands" + File.separator + "SBUDarkRedShieldLogo.png";
    public static final String DEFAULT_LEFT_FOOTER = FILE_PROTOCOL + PATH_WORK + File.separator + "brands" + File.separator + "SBUWhiteShieldLogo.jpg";
    public static final String DEFAULT_RIGHT_FOOTER = FILE_PROTOCOL + PATH_WORK + File.separator + "brands"  + File.separator + "CSLogo.png";
    */
    /*
    public static final String DEFAULT_BANNER = "file:./work/brands/SBUDarkRedShieldLogo.png";
    public static final String DEFAULT_LEFT_FOOTER = "file:./work/brands/SBUWhiteShieldLogo.jpg";
    public static final String DEFAULT_RIGHT_FOOTER = "file:./work/brands/CSLogo.png";
    */
    public static final String DEFAULT_BANNER = System.getProperty("user.dir") + File.separator + "work" + File.separator + "brands" + File.separator + "SBUDarkRedShieldLogo.png";
    public static final String DEFAULT_LEFT_FOOTER = System.getProperty("user.dir") + File.separator + "work" + File.separator + "brands" + File.separator + "SBUWhiteShieldLogo.jpg";
    public static final String DEFAULT_RIGHT_FOOTER = System.getProperty("user.dir") + File.separator + "work" + File.separator + "brands" + File.separator + "CSLogo.png";
    
    //DEFAULT VALUES FOR DIRECTORIES
    public static final String DEFAULT_TEMPLATE_DIR = System.getProperty("user.dir") + File.separator + "work" + File.separator + "templates";
    public static final String DEFAULT_STYLESHEET = "sea_wolf.css";
    //DEFAULT VALUES FOR COURSE PAGE
    public static final String DEFAULT_SUBJECT = "CSE";
    public static final String DEFAULT_SEMESTER = "Fall";
    public static final int DEFAULT_NUMBER = 219;
    public static final String DEFAULT_TITLE = "Computer Science";
    public static final String DEFAULT_INSTRUCTOR_NAME = "Richard McKenna";
    public static final String DEFAULT_INSTRUCTOR_HOME = "http://www3.cs.stonybrook.edu/~cse219/Section02/syllabus.html";
    public static final String DEFAULT_EXPORT_DIR = System.getProperty("user.home") + File.separator + "Desktop";
    //DEFAULT VALUE FOR STARTING AND ENDING DATES
    public static final LocalDate DEFAULT_STARTING_MONDAY = LocalDate.of(2017, 1, 23);
    public static final LocalDate DEFAULT_ENDING_FRIDAY = LocalDate.of(2017, 5, 19);
    
    ArrayList<String> startAndEndHours;
    
    //EVERYTHING IN COURSE DETAILS TAB
    //COURSE INFO SECTION
    String subject;
    String semester;
    int number;
    int year;
    String title;
    String instructorName;
    String instructorHome;
    String exportDir;
    //SITE TEMPLATE
    String siteTemplateDir;
    //PAGE STYLE
    String bannerSchoolImage;
    String bannerLeftFooterImage;
    String bannerRightFooterImage;
    String stylesheet;
    //Schedule
    LocalDate startingMonday;
    LocalDate endingFriday;
    
    /**
     * This constructor will setup the required data structures for
     * use, but will have to wait on the office hours grid, since
     * it receives the StringProperty objects from the Workspace.
     * 
     * @param initApp The application this data manager belongs to. 
     */
    public CSGData(CSGApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;

        // CONSTRUCT THE LIST OF TAs FOR THE TABLE
        teachingAssistants = FXCollections.observableArrayList();
        
        //CONSTRUCT THE PAGES
        sitePages = FXCollections.observableArrayList();
        Page homePage = new Page("Home", "index.html", "TeamsBuilder.js", false);
        Page syllabusPage = new Page("Syllabus", "syllabus.html", "SyllabusBuilder.js", false);
        Page schedulePage = new Page("Schedule", "schedule.html", "ScheduleBuilder.js", false);
        Page homeworkPage = new Page("HWs", "hws.html", "HWsBuilder.js", false);
        Page projectPage = new Page("Projects", "projects.html", "ProjectsBuilder.js", false);
        sitePages.addAll(homePage, syllabusPage, schedulePage, homeworkPage, projectPage);
        
        //CONSTRUCT THE RECITATIONS FOR THE TABLE
        recitations = FXCollections.observableArrayList();
        
        //CONSTRUCT THE SCHEDULES FOR THE TABLE
        schedules = FXCollections.observableArrayList();
        
        //CONSTRUCT THE TEAMS
        teams = FXCollections.observableArrayList();
        
        //CONSTRUCT THE STUDENTS
        students = FXCollections.observableArrayList();
        
        // THESE ARE THE DEFAULT OFFICE HOURS
        startHour = MIN_START_HOUR;
        endHour = MAX_END_HOUR;
        startHourOnlyHour = DEFAULT_START_HOUR_ONLY_HOUR;
        endHourOnlyHour = DEFAULT_END_HOUR_ONLY_HOUR;
        
        //DEFAULTS FOR THE COURSE PAGE
        subject = DEFAULT_SUBJECT;
        semester = DEFAULT_SEMESTER;
        number = DEFAULT_NUMBER;
        year = LocalDate.now().getYear();
        title = DEFAULT_TITLE;
        instructorName = DEFAULT_INSTRUCTOR_NAME;
        instructorHome = DEFAULT_INSTRUCTOR_HOME;
        exportDir = DEFAULT_EXPORT_DIR;
        siteTemplateDir = DEFAULT_TEMPLATE_DIR;
        stylesheet = DEFAULT_STYLESHEET;
        
        //DEFAULT BANNERS
        bannerSchoolImage = DEFAULT_BANNER;
        bannerLeftFooterImage = DEFAULT_LEFT_FOOTER;
        bannerRightFooterImage = DEFAULT_RIGHT_FOOTER;
        
        //DEFAULT STARTING AND ENDING DATES
        startingMonday= DEFAULT_STARTING_MONDAY;
        endingFriday = DEFAULT_ENDING_FRIDAY;
        
        //THIS WILL STORE OUR OFFICE HOURS
        officeHours = new HashMap();
        
        //THIS WILL STORE THE CSS FILES
        allCSS = new ArrayList();
        File[] cssFiles = new File(PATH_WORK + File.separator + "css").listFiles();
        for(int i = 0; i < cssFiles.length; i++)
        {
            allCSS.add(cssFiles[i].getName());
        }
        
        // THESE ARE THE LANGUAGE-DEPENDENT OFFICE HOURS GRID HEADERS
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        ArrayList<String> timeHeaders = props.getPropertyOptionsList(CSGProp.OFFICE_HOURS_TABLE_HEADERS);
        ArrayList<String> dowHeaders = props.getPropertyOptionsList(CSGProp.DAYS_OF_WEEK);
        ArrayList<String> allTheHours = props.getPropertyOptionsList(CSGProp.ALL_HOURS);
        ArrayList<String> allTheSubjects = props.getPropertyOptionsList(CSGProp.ALL_SUBJECTS);
        ArrayList<String> allTheNumbers = props.getPropertyOptionsList(CSGProp.ALL_NUMBERS);
        ArrayList<String> allTheSemesters = props.getPropertyOptionsList(CSGProp.ALL_SEMESTERS);
        ArrayList<String> allTheTypes = props.getPropertyOptionsList(CSGProp.All_TYPES);
        gridHeaders = new ArrayList();
        gridHeaders.addAll(timeHeaders);
        gridHeaders.addAll(dowHeaders);
        //CREATE THE LISTS
        allHours = new ArrayList();
        allHours.addAll(allTheHours);
        allSubjects = new ArrayList();
        allSubjects.addAll(allTheSubjects);
        allSemesters = new ArrayList();
        allSemesters.addAll(allTheSemesters);
        allTypes = new ArrayList();
        allTypes.addAll(allTheTypes);
        allNumbers = new ArrayList();
        allNumbers.addAll(allTheNumbers);
        allYears = new ArrayList();
        for(int i = 0; i < 4 ; i ++)
        {
            allYears.add(LocalDate.now().getYear() + i + "");
        }
        /*
        HOW TO CONSTRUcT A LOCALDATE
        LocalDate.of(2017, 12, 2);
        */
    }
    
    /**
     * Called each time new work is created or loaded, it resets all data
     * and data structures such that they can be used for new values.
     */
    @Override
    public void resetData() {
        startHour = MIN_START_HOUR;
        endHour = MAX_END_HOUR;
        startHourOnlyHour = DEFAULT_START_HOUR_ONLY_HOUR;
        endHourOnlyHour = DEFAULT_END_HOUR_ONLY_HOUR;
        teachingAssistants.clear();
        for(int i = 0; i < sitePages.size(); i++)
        {
            sitePages.get(i).setIsUsed(false);
        }
        recitations.clear();
        schedules.clear();
        officeHours.clear();
        teams.clear();
        students.clear();
        
        //FOR COURSE PAGE
        subject = DEFAULT_SUBJECT;
        semester = DEFAULT_SEMESTER;
        number = DEFAULT_NUMBER;
        year = LocalDate.now().getYear();
        title = DEFAULT_TITLE;
        instructorName = DEFAULT_INSTRUCTOR_NAME;
        instructorHome = DEFAULT_INSTRUCTOR_HOME;
        exportDir = DEFAULT_EXPORT_DIR;
        siteTemplateDir = DEFAULT_TEMPLATE_DIR;
        stylesheet = DEFAULT_STYLESHEET;
        
        //DEFAULT BANNERS
        bannerSchoolImage = DEFAULT_BANNER;
        bannerLeftFooterImage = DEFAULT_LEFT_FOOTER;
        bannerRightFooterImage = DEFAULT_RIGHT_FOOTER;
        
        //DEFAULT STARTING AND ENDING DATES
        startingMonday= DEFAULT_STARTING_MONDAY;
        endingFriday = DEFAULT_ENDING_FRIDAY;
        //SORT THE STUFF
        Collections.sort(sitePages);
    }
    
    // ACCESSOR METHODS

    public int getStartHour() {
        return startHour;
    }
    
    public void setStartHour(int hour)
    {
        startHour = hour;
    }

    public int getEndHour() {
        return endHour;
    }
    
    public void setEndHour(int hour)
    {
        endHour = hour;
    }
    
    public boolean getStartOnlyHour()
    {
        return startHourOnlyHour;
    }
    
    public void setStartOnlyHour(boolean onlyHour)
    {
        startHourOnlyHour = onlyHour;
    }
    
    public boolean getEndOnlyHour()
    {
        return endHourOnlyHour;
    }
    
    public void setEndOnlyHour(boolean onlyHour)
    {
        endHourOnlyHour = onlyHour;
    }
    
    public ArrayList<String> getAllHours() {
        return allHours;
    }
    
    public ArrayList<String> getAllSemesters() {
        return allSemesters;
    }
    
    public ArrayList<String> getAllSubjects() {
        return allSubjects;
    }
    
    public ArrayList<String> getAllNumbers() {
        return allNumbers;
    }
    
    public ArrayList<String> getAllYears() {
        return allYears;
    }
    
    public ArrayList<String> getAllTypes() {
        return allTypes;
    }
    
    public ArrayList<String> getGridHeaders() {
        return gridHeaders;
    }
    
    public ArrayList<String> getAllCss() {
        return allCSS;
    }
    public ObservableList getTeachingAssistants() {
        return teachingAssistants;
    }
    
    public ObservableList getSitePages() {
        return sitePages;
    }
    
    public ObservableList getSchedules() {
        return schedules;
    }
    
    public ObservableList getRecitations() {
        return recitations;
    }
    
    public ObservableList getTeams() {
        return teams;
    }
    
    public ObservableList getStudents() {
        return students;
    }
    
    public String getSubject()
    {
        return subject;
    }
    
    public void setSubject(String newSubject)
    {
        subject = newSubject;
    }
    
    public String getSemester()
    {
        return semester;
    }
    
    public void setSemester(String newSemester)
    {
        semester = newSemester;
    }
    
    public int getNumber()
    {
        return number;
    }
    
    public void setNumber(int newNumber)
    {
        number = newNumber;
    }
    
    public int getYear()
    {
        return year;
    }
    
    public void setYear(int newYear)
    {
        year = newYear;
    }
    
    public String getTitle()
    {
        return title;
    }
    
    public void setTitle(String newTitle)
    {
        title = newTitle;
    }
    
    public String getInstructorName()
    {
        return instructorName;
    }
    
    public void setInstructorName(String newInstructorName)
    {
        instructorName = newInstructorName;
    }
    
    public String getInstructorHome()
    {
        return instructorHome;
    }
    
    public void setInstructorHome(String newInstructorHome)
    {
        instructorHome = newInstructorHome;
    }
    
    public String getExportDir()
    {
        return exportDir;
    }
    
    public void setExportDir(String newExportDir)
    {
        exportDir = newExportDir;
    }
    
    public String getSiteTemplate()
    {
        return siteTemplateDir;
    }
    
    public void setSiteTemplate(String newSiteTemplate)
    {
        siteTemplateDir = newSiteTemplate;
    }
    
    public String getBannerSchoolImage()
    {
        return bannerSchoolImage;
    }
    
    public void setBannerSchoolImage(String newBannerSchoolImage)
    {
        bannerSchoolImage = newBannerSchoolImage;
    }
    
    public String getBannerLeftFooterImage()
    {
        return bannerLeftFooterImage;
    }
    
    public void setBannerLeftFooterImage(String newBannerLeftFooterImage)
    {
        bannerLeftFooterImage = newBannerLeftFooterImage;
    }
    
    public String getBannerRightFooterImage()
    {
        return bannerRightFooterImage;
    }
    
    public void setBannerRightFooterImage(String newBannerRightFooterImage)
    {
        bannerRightFooterImage = newBannerRightFooterImage;
    }
    
    public String getStylesheet()
    {
        return stylesheet;
    }
    
    public void setStylesheet(String newStylesheet)
    {
        stylesheet = newStylesheet;
    }
    
    public LocalDate getStartingMonday()
    {
        return startingMonday;
    }
    
    public void setStartingMonday(LocalDate newStartingMonday)
    {
        startingMonday = newStartingMonday;
    }
    
    public void setStartingMonday(String newStartingMonday)
    {
        startingMonday = convertStringToLocalDate(newStartingMonday);
    }
    
    public LocalDate convertStringToLocalDate(String date)
    {
        String[] arrayDate = date.split("/");
        int year = Integer.parseInt(arrayDate[2]);
        int month = Integer.parseInt(arrayDate[0]);
        int day = Integer.parseInt(arrayDate[1]);
        return LocalDate.of(year, month, day);
    }
    public String convertColorToString(Color color)
    {
        return String.format("#%02X%02X%02X", (int)(color.getRed() * 255), (int)(color.getGreen() * 255), (int)(color.getBlue() * 255));
    }
    
    public Color convertStringToColor(String color)
    {
        return Color.web(color);
    }
    
    public LocalDate getEndingFriday()
    {
        return endingFriday;
    }
    
    public void setEndingFriday(String newEndingFriday)
    {
        endingFriday = convertStringToLocalDate(newEndingFriday);
    }
    
    public void setEndingFriday(LocalDate newEndingFriday)
    {
        endingFriday = newEndingFriday;
    }
    
    public String getCellKey(int col, int row) {
        return col + "_" + row;
    }

    public StringProperty getCellTextProperty(int col, int row) {
        String cellKey = getCellKey(col, row);
        return officeHours.get(cellKey);
    }

    public HashMap<String, StringProperty> getOfficeHours() {
        return officeHours;
    }
    
    public int getNumRows() {
        //return ((endHour - startHour) * 2) + 1;
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        ArrayList<String> allTheHours = props.getPropertyOptionsList(CSGProp.ALL_HOURS);
        String startTime = getTimeString(startHour, startHourOnlyHour);
        String endTime = getTimeString(endHour, endHourOnlyHour);
        int startInt = 0;
        int endInt = 0;
        for(int i = 0; i < allTheHours.size(); i++)
        {
            if(allTheHours.get(i).compareTo(startTime) == 0)
            {
                startInt = i;
            }
            if(allTheHours.get(i).compareTo(endTime) == 0)
            {
                endInt = i;
            }
        }
        return endInt - startInt + 1;
    }

    public String getTimeString(int militaryHour, boolean onHour) {
        String minutesText = "00";
        if (!onHour) {
            minutesText = "30";
        }

        // FIRST THE START AND END CELLS
        int hour = militaryHour;
        if (hour > 12) {
            hour -= 12;
        }
        String cellText = "" + hour + ":" + minutesText;
        if (militaryHour < 12) {
            cellText += "am";
        } else {
            cellText += "pm";
        }
        if(hour == 0)
        {
            cellText = "12" + ":" + minutesText + "am";
        }
        return cellText;
    }
    
    public int getMilitaryTime(String timeString)
    {
        int hour = Integer.parseInt(timeString.substring(0, timeString.indexOf(":")));
        if(timeString.contains("pm"))
        {
            hour = hour + 12;
        }
        if(timeString.contains("am") && hour == 12)
        {
            hour = 0;
        }
        return hour;
    }
    
    public boolean getHourOnly(String timeString)
    {
        if(timeString.substring(timeString.indexOf(":")).contains("30"))
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    public String getCellKey(String day, String time) {
        /*
        int col = gridHeaders.indexOf(day);
        int row = 1;
        int hour = Integer.parseInt(time.substring(0, time.indexOf("_")));
        int milHour = hour;
        if (hour < startHour)
            milHour += 12;
        row += (milHour - startHour) * 2;
        if (time.contains("_30"))
            row += 1;
        return getCellKey(col, row);
        */
        int col = gridHeaders.indexOf(day);
        String timeString = time.replace("_", ":");
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        ArrayList<String> alltheHours = props.getPropertyOptionsList(CSGProp.ALL_HOURS);
        int startHourIndex = 0;
        int currentHourIndex = 0;
        for(int i = 0; i < alltheHours.size(); i++)
        {
            if(alltheHours.get(i).compareTo(getTimeString(startHour, startHourOnlyHour)) == 0)
            {
                startHourIndex = i;
            }
            if(alltheHours.get(i).compareTo(timeString) == 0)
            {
                currentHourIndex = i;
            }
        }
        int row = currentHourIndex - startHourIndex + 1;
        return getCellKey(col, row);
    }
    
    public TeachingAssistant getTA(String testName) {
        for (TeachingAssistant ta : teachingAssistants) {
            if (ta.getName().equals(testName)) {
                return ta;
            }
        }
        return null;
    }
    
    public Recitation getRecitation(String testSection) {
        for (Recitation rec : recitations) {
            if (rec.getSection().equals(testSection)) {
                return rec;
            }
        }
        return null;
    }
    
    public Schedule getSchedule(String testType, LocalDate testDate) {
        for (Schedule sch : schedules) {
            if (sch.getType().equals(testType) && sch.getDate().toString().compareTo(testDate.toString()) == 0) {
                return sch;
            }
        }
        return null;
    }
    
    public Team getTeam(String testName) {
        for (Team tm : teams) {
            if (tm.getName().equals(testName)) {
                return tm;
            }
        }
        return null;
    }
    
    public Student getStudent(String testFirstName, String testLastName) {
        for (Student st : students) {
            if (st.getFirstName().equals(testFirstName) && st.getLastName().equals(testLastName)) {
                return st;
            }
        }
        return null;
    }
    
    /**
     * This method is for giving this data manager the string property
     * for a given cell.
     */
    public void setCellProperty(int col, int row, StringProperty prop) {
        String cellKey = getCellKey(col, row);
        officeHours.put(cellKey, prop);
    }    
    
    /**
     * This method is for setting the string property for a given cell.
     */
    public void setGridProperty(ArrayList<ArrayList<StringProperty>> grid,
                                int column, int row, StringProperty prop) {
        grid.get(row).set(column, prop);
    }
    

    public void newInitHours(String startHourText, String endHourText, boolean startHourOnly, boolean endHourOnly)
    {
        int initStartHour = Integer.parseInt(startHourText);
        int initEndHour = Integer.parseInt(endHourText);
        initOfficeHours(initStartHour, initEndHour);
        startHourOnlyHour = startHourOnly;
        endHourOnlyHour = endHourOnly;
        initOfficeHours(initStartHour, initEndHour);
    }
    
    private void initOfficeHours(int initStartHour, int initEndHour) {
        // NOTE THAT THESE VALUES MUST BE PRE-VERIFIED
        startHour = initStartHour;
        endHour = initEndHour;
        
        // EMPTY THE CURRENT OFFICE HOURS VALUES
        officeHours.clear();
            
        // WE'LL BUILD THE USER INTERFACE COMPONENT FOR THE
        // OFFICE HOURS GRID AND FEED THEM TO OUR DATA
        // STRUCTURE AS WE GO
        CSGWorkspace workspaceComponent = (CSGWorkspace)app.getWorkspaceComponent();
        workspaceComponent.reloadOfficeHoursGrid(this);
        workspaceComponent.comboBoxUpdateOfficeHoursGrid(this);
    }
    
    
    public void initHours(String startHourText, String endHourText) {
        int initStartHour = Integer.parseInt(startHourText);
        int initEndHour = Integer.parseInt(endHourText);
        if ((initStartHour >= MIN_START_HOUR)
                && (initEndHour <= MAX_END_HOUR)
                && (initStartHour <= initEndHour)) {
            // THESE ARE VALID HOURS SO KEEP THEM
            initOfficeHours(initStartHour, initEndHour);
        }
    }

    public boolean containsTA(String testName, String testEmail) {
        for (TeachingAssistant ta : teachingAssistants) {
            if (ta.getName().equals(testName)) {
                return true;
            }
            if (ta.getEmail().equals(testEmail)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean containsRecitation(String testSection) {
        for (Recitation rec : recitations) {
            if (rec.getSection().equals(testSection)) {
                return true;
            }
        }
        return false;
    }


    public void addPage(Boolean initUse, String initTitle, String initFile, String initScript) {
        // MAKE THE TA
        Page pg = new Page(initTitle, initTitle, initScript, initUse);

        // ADD THE TA
            sitePages.add(pg);

        // SORT THE TAS
        Collections.sort(sitePages);
    }

    public void addTA(String initName, String initEmail, boolean initUndergrad) {
        // MAKE THE TA
        TeachingAssistant ta = new TeachingAssistant(initName, initEmail, initUndergrad);

        // ADD THE TA
        if (!containsTA(initName, initEmail)) {
            teachingAssistants.add(ta);
        }

        // SORT THE TAS
        Collections.sort(teachingAssistants);
    }
    
    public void addRecitation(String initSection, String initInstructor, String initDayAndTime, String initLocation, String initTaOne, String initTaTwo) {
        // MAKE THE RECITATION
        Recitation rec = new Recitation(initSection, initInstructor, initDayAndTime, initLocation,initTaOne, initTaTwo);

        // ADD THE RECITATION
        if (!containsRecitation(initSection)) {
            recitations.add(rec);
        }

        // SORT THE RECITATIONS
        Collections.sort(recitations);
    }
    
    public boolean containsSchedule(LocalDate testDate, String testType) {
        for (Schedule sch : schedules) {
            if (sch.getDate().toString().compareTo(testDate.toString()) == 0 && sch.getType().compareTo(testType) == 0) 
            {
                return true;
            }
        }
        return false;
    }
    
    public void addSchedule(String initType, LocalDate initDate, String initTime, String initTitle, String initTopic, String initLink, String initCriteria) {
        // MAKE THE SCHEDULE
        Schedule sch = new Schedule(initType, initDate, initTime, initTitle, initTopic, initLink, initCriteria);

        // ADD THE SCHEDULE
        if (!containsSchedule(initDate, initType)) {
            schedules.add(sch);
        }

        // SORT THE SCHEDULE
        Collections.sort(schedules);
    }
    
    public boolean containsTeam(String testName) {
        for (Team tm : teams) {
            if (tm.getName().equals(testName)) {
                return true;
            }
        }
        return false;
    }
    
    public void addTeam(String initName, Color initColor, Color initTextColor, String initLink) {
        // MAKE THE SCHEDULE
        Team tm = new Team(initName, initColor, initTextColor, initLink);
        // ADD THE SCHEDULE
        if (!containsTeam(initName)) {
            teams.add(tm);
        }

        // SORT THE SCHEDULE
        Collections.sort(teams);
    }
    
    public boolean containsStudent(String testFirstName, String testLastName) {
        for (Student st : students) {
            if (st.getFirstName().equals(testFirstName) && st.getLastName().equals(testLastName)) {
                return true;
            }
        }
        return false;
    }
    
    public void addStudent(String initFirstName, String initLastName, String initTeam, String initRole) {
        // MAKE THE STUDENT
        Student st = new Student(initFirstName, initLastName, initTeam, initRole);
        // ADD THE STUDENT
        if (!containsStudent(initFirstName, initLastName)) {
            students.add(st);
        }

        // SORT THE SCHEDULE
        Collections.sort(students);
    }
    
    public void replaceTAName(String name, String newName){
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        for(Pane p : workspace.getOfficeHoursGridTACellPanes().values()){
            String cellKey = p.getId();
            StringProperty cellProp = officeHours.get(cellKey);
            String cellText = cellProp.getValue();
            if (cellText.contains(name)) {
                toggleTAOfficeHours(cellKey, name);
                toggleTAOfficeHours(cellKey, newName);
            }
        }
    }

    public void removeTA(String name) {
        for (TeachingAssistant ta : teachingAssistants) {
            if (name.equals(ta.getName())) {
                teachingAssistants.remove(ta);
                return;
            }
        }
    }
    
    public void removeRecitation(String section) {
        for (Recitation rec : recitations) {
            if (section.equals(rec.getSection())) {
                recitations.remove(rec);
                return;
            }
        }
    }
    
    public void removeSchedule(LocalDate date, String type) {
        for (Schedule sc : schedules) {
            if (date.toString().compareTo(sc.getDate().toString()) == 0 && type.equals(sc.getType())) {
                schedules.remove(sc);
                return;
            }
        }
    }
    
    public void removeTeam(String name) {
        for (Team tm : teams) {
            if (name.equals(tm.getName())) {
                teams.remove(tm);
                return;
            }
        }
    }
    
    public void removeStudent(String firstName, String lastName) {
        for (Student st : students) {
            if (firstName.equals(st.getFirstName()) && lastName.equals(st.getLastName())) {
                students.remove(st);
                return;
            }
        }
    }
    
    public void addOfficeHoursReservation(String day, String time, String taName) {
        String cellKey = getCellKey(day, time);
        toggleTAOfficeHours(cellKey, taName);
    }
    
    public void setWorkPlaceGrid(ArrayList<TimeSlot> Reservations)
    {
        CSGWorkspace workspaceComponent = (CSGWorkspace)app.getWorkspaceComponent();
        workspaceComponent.comboBoxUpdateOfficeHoursGrid(this);
    }
    
    public void setTeachingAssistants(ObservableList<TeachingAssistant> TeachingAssis)
    {
        teachingAssistants = TeachingAssis;
    }
    


    /**
     * This function toggles the taName in the cell represented
     * by cellKey. Toggle means if it's there it removes it, if
     * it's not there it adds it.
     */
    public void toggleTAOfficeHours(String cellKey, String taName) {
        StringProperty cellProp = officeHours.get(cellKey);
        String cellText = cellProp.getValue();

        // IF IT ALREADY HAS THE TA, REMOVE IT
        if (cellText.contains(taName)) {
            removeTAFromCell(cellProp, taName);
        } // OTHERWISE ADD IT
        else if (cellText.length() == 0) {
            cellProp.setValue(taName);
        } else {
            cellProp.setValue(cellText + "\n" + taName);
        }
    }
    
    /**
     * This method removes taName from the office grid cell
     * represented by cellProp.
     */
    public void removeTAFromCell(StringProperty cellProp, String taName) {
        // GET THE CELL TEXT
        String cellText = cellProp.getValue();
        // IS IT THE ONLY TA IN THE CELL?
        if (cellText.equals(taName)) {
            cellProp.setValue("");
        }
        // IS IT THE FIRST TA IN A CELL WITH MULTIPLE TA'S?
        else if (cellText.indexOf(taName) == 0) {
            int startIndex = cellText.indexOf("\n") + 1;
            cellText = cellText.substring(startIndex);
            cellProp.setValue(cellText);
        }
        // IS IT IN THE MIDDLE OF A LIST OF TAs
        else if (cellText.indexOf(taName) < cellText.indexOf("\n", cellText.indexOf(taName))) {
            int startIndex = cellText.indexOf("\n" + taName);
            int endIndex = startIndex + taName.length() + 1;
            cellText = cellText.substring(0, startIndex) + cellText.substring(endIndex);
            cellProp.setValue(cellText);
        }
        // IT MUST BE THE LAST TA
        else {
            int startIndex = cellText.indexOf("\n" + taName);
            cellText = cellText.substring(0, startIndex);
            cellProp.setValue(cellText);
        }
    }
    public void updateTAFromCell(StringProperty cellProp, String previousTaName, String newName)
    {
        String cellText = cellProp.getValue();
        int startIndex = cellText.indexOf("\n" + previousTaName);
        int endIndex = startIndex + previousTaName.length() + 1;
        cellText = cellText.substring(0, startIndex) + newName + cellText.substring(endIndex);
        cellProp.setValue(cellText);
    }
}