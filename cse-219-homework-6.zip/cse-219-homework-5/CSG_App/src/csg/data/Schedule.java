/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.data;

import java.time.LocalDate;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author David Xie
 */
public class Schedule<E extends Comparable<E>> implements Comparable<E> {
    private final StringProperty type;
    private final ObjectProperty<LocalDate> date;
    private final StringProperty time;
    private final StringProperty title;
    private final StringProperty topic;
    private final StringProperty link;
    private final StringProperty criteria;
    
    public Schedule(String initType, LocalDate initDate, String initTime, String initTitle, String initTopic, String initLink, String initCriteria) {
        type = new SimpleStringProperty(initType);
        date = new SimpleObjectProperty(initDate);
        time = new SimpleStringProperty(initTime);
        title = new SimpleStringProperty(initTitle);
        topic = new SimpleStringProperty(initTopic);
        link = new SimpleStringProperty(initLink);
        criteria = new SimpleStringProperty(initCriteria);
    }
    
    //ACCESSORS AND STUFF
    public String getType()
    {
        return type.get();
    }
    
    public void setType(String initType) {
        type.set(initType);
    }
    public LocalDate getDate()
    {
        return date.get();
    }
    
    public void setDate(LocalDate initDate) {
        date.set(initDate);
    }
    
    public ObjectProperty dateProperty()
    {
        return date;
    }
    
    public String getTime()
    {
        return time.get();
    }
    
    public void setTime(String initTime) {
        time.set(initTime);
    }
    
    public String getTitle()
    {
        return title.get();
    }
    
    public void setTitle(String initTitle) {
        title.set(initTitle);
    }
    
    public String getTopic()
    {
        return topic.get();
    }
    
    public void setTopic(String initTopic) {
        topic.set(initTopic);
    }
    
    public String getlink()
    {
        return link.get();
    }
    
    public void setLink(String initLink) {
        link.set(initLink);
    }
    
    public String getCriteria()
    {
        return criteria.get();
    }
    
    public void setCriteria(String initCriteria) {
        criteria.set(initCriteria);
    }
    
    @Override
    public int compareTo(E otherSchedule) {
        return getDate().compareTo(((Schedule)otherSchedule).getDate());
    }
    
    @Override
    public String toString() {
        return topic.getValue();
    }
}
