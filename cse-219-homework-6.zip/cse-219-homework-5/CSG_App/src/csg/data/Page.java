/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.data;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author David Xie
 */
public class Page <E extends Comparable<E>> implements Comparable<E>{
    private final StringProperty titleName;
    private final StringProperty fileName;
    private final StringProperty scriptName;
    private BooleanProperty isUsed;
    
    public Page(String initTitleName, String initFileName, String initScriptName, boolean initUsed)
    {
        titleName = new SimpleStringProperty(initTitleName);
        fileName = new SimpleStringProperty(initFileName);
        scriptName = new SimpleStringProperty(initScriptName);
        isUsed = new SimpleBooleanProperty(initUsed);
    }
    
    // ACCESSORS AND MUTATORS FOR THE PROPERTIES
    
    public String getTitleName() 
    {
        return titleName.get();
    }
    
    public void setName(String initTitleName) 
    {
        titleName.set(initTitleName);
    }
    
    public String getFileName()
    {
        return fileName.get();
    }
    
    public void setFileName(String initFileName)
    {
        fileName.set(initFileName);
    }
    
    public String getScriptName()
    {
        return scriptName.get();
    }
    
    public void setScriptName(String initScriptName)
    {
        scriptName.set(initScriptName);
    }
    
    public BooleanProperty beingUsed()
    {
        return isUsed;
    }
    
    public void setIsUsed(boolean isBeingUsed)
    {
        isUsed.set(isBeingUsed);
    }
    
    public boolean isUsed()
    {
        return isUsed.get();
    }
    
    @Override
    public int compareTo(E otherPage) {
        return getTitleName().compareTo(((Page)otherPage).getTitleName());
    }
    
    @Override
    public String toString() {
        return titleName.getValue();
    }
}
