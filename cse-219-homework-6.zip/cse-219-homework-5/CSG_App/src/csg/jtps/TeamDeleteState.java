/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import javafx.scene.paint.Color;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class TeamDeleteState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private String name;
    private String link;
    private Color primaryColor;
    private Color textColor;
    
    public TeamDeleteState(CSGApp app, String teamName){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        name = teamName;
        link = data.getTeam(name).getLink();
        primaryColor = data.getTeam(name).getColor();
        textColor = data.getTeam(name).getTextColor();
    }
    
    @Override
    public void doTransaction() {
        data.removeTeam(name);
    }

    @Override
    public void undoTransaction() {
        data.addTeam(name, primaryColor, textColor, link);
    }
}
