/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import java.io.File;
import java.net.MalformedURLException;
import javafx.scene.image.Image;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class BannerRightImageChangeState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private File newBanner;
    private File oldBanner;
    
    public BannerRightImageChangeState(CSGApp app, File banner){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        oldBanner = new File(data.getBannerRightFooterImage());
        newBanner = banner;
    }
    
    @Override
    public void doTransaction() {
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data.setBannerRightFooterImage(newBanner.getAbsolutePath());
        try {
            workspace.getRightbannerImageView().setImage(new Image(newBanner.toURI().toURL().toExternalForm()));
        } catch (MalformedURLException ex) {
            System.out.print("malformedURL");
        }
    }

    @Override
    public void undoTransaction() {
       CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data.setBannerRightFooterImage(oldBanner.getAbsolutePath());
        try {
            workspace.getRightbannerImageView().setImage(new Image(oldBanner.toURI().toURL().toExternalForm()));
        } catch (MalformedURLException ex) {
            System.out.print("malformedURL");
        }
    }
}
