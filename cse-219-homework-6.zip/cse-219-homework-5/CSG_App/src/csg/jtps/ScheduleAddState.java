/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import java.time.LocalDate;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class ScheduleAddState implements jTPS_Transaction{
    private String scheduleType;
    private LocalDate scheduleDate;
    private String scheduleTime;
    private String scheduleTitle;
    private String scheduleTopic;
    private String scheduleLink;
    private String scheduleCriteria;
    private CSGApp app;
    private CSGWorkspace workspace;
    
    public ScheduleAddState(CSGApp app){
        this.app = app;
        workspace = (CSGWorkspace)app.getWorkspaceComponent();
        scheduleType = workspace.getScheduleTypeComboBox().getValue().toString();
        scheduleDate = workspace.getScheduleDateDatePicker().getValue();
        scheduleTime = workspace.getScheduleTimeField().getText();
        scheduleTitle = workspace.getScheduleTitleField().getText();
        scheduleTopic = workspace.getScheduleTopicField().getText();
        scheduleLink = workspace.getScheduleLinkField().getText();
        scheduleCriteria = workspace.getScheduleCriteriaField().getText();
    }
    
    @Override
    public void doTransaction() {
        ((CSGData)app.getDataComponent()).addSchedule(scheduleType, scheduleDate, scheduleTime, scheduleTitle, scheduleTopic, scheduleLink, scheduleCriteria);
    }

    @Override
    public void undoTransaction() {
        ((CSGData)app.getDataComponent()).removeSchedule(scheduleDate, scheduleType);
    }
}
