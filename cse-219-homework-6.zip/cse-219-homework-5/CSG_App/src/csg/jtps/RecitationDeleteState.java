/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class RecitationDeleteState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private String section;
    private String instructor;
    private String time;
    private String location;
    private String taOne;
    private String taTwo;
    
    public RecitationDeleteState(CSGApp app, String recitationSection){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        section = recitationSection;
        instructor = data.getRecitation(recitationSection).getInstructor();
        time = data.getRecitation(recitationSection).getDayAndTime();
        location = data.getRecitation(recitationSection).getLocation();
        taOne = data.getRecitation(recitationSection).getTaOne();
        taTwo = data.getRecitation(recitationSection).getTaTwo();
    }
    
    @Override
    public void doTransaction() {
        data.removeRecitation(section);
    }

    @Override
    public void undoTransaction() {
        data.addRecitation(section, instructor, time, location, taOne, taTwo);
    }
}
