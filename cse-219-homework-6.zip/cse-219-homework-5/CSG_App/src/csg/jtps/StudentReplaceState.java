/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.data.Student;
import csg.workspace.CSGWorkspace;
import javafx.scene.control.TableView;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class StudentReplaceState implements jTPS_Transaction{
    private String studentFirstName;
    private String studentLastName;
    private String studentTeam;
    private String studentRole;
    private String newFirstName;
    private String newLastName;
    private String newTeam;
    private String newRole;
    private CSGApp app;
    private CSGData data;
    
    public StudentReplaceState(CSGApp app){
        this.app = app;
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data = (CSGData)app.getDataComponent();
        newFirstName = workspace.getProjectStudentFirstNameField().getText();
        newLastName = workspace.getProjectStudentLastNameField().getText();
        if(workspace.getProjectStudentTeamComboBox().getValue() != null)
        {
            newTeam = workspace.getProjectStudentTeamComboBox().getValue().toString();
        }
        else
        {
            newTeam = "";
        }
        newRole = workspace.getProjectStudentRoleField().getText();
        //
        TableView stTable = workspace.getStudentTable();
        Object selectedItem = stTable.getSelectionModel().getSelectedItem();
        Student st = (Student)selectedItem;
        studentFirstName = st.getFirstName();
        studentLastName = st.getLastName();
        studentTeam = st.getTeam();
        studentRole = st.getRole();
    }
    
    @Override
    public void doTransaction() {
        Student selectedStudent = data.getStudent(studentFirstName, studentLastName);
        selectedStudent.setFirstName(newFirstName);
        selectedStudent.setLastName(newLastName);
        selectedStudent.setTeam(newTeam);
        selectedStudent.setRole(newRole);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView stTable = workspace.getStudentTable();
        stTable.getSelectionModel().select(data.getStudent(newFirstName, newLastName));
        stTable.refresh();
    }

    @Override
    public void undoTransaction() {
        Student selectedStudent = data.getStudent(newFirstName, newLastName);
        selectedStudent.setFirstName(studentFirstName);
        selectedStudent.setLastName(studentLastName);
        selectedStudent.setTeam(studentTeam);
        selectedStudent.setRole(studentRole);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView stTable = workspace.getStudentTable();
        stTable.getSelectionModel().select(data.getStudent(studentFirstName, studentLastName));
        stTable.refresh();
    }
}
