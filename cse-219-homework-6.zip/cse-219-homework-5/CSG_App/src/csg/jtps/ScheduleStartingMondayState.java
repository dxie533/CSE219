/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import java.time.LocalDate;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class ScheduleStartingMondayState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private LocalDate newDate;
    private LocalDate oldDate;
    
    public ScheduleStartingMondayState(CSGApp app) {
        this.app = app;
        data = (CSGData)app.getDataComponent();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        oldDate = data.getStartingMonday();
        newDate = workspace.getStartingMonday().getValue();
    }
    
    @Override
    public void doTransaction() {
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data.setStartingMonday(newDate);
        //workspace.getStartingMonday().setValue(newDate);
        workspace.getStartingMonday().getEditor().setText(data.getStartingMonday().toString());
    }

    @Override
    public void undoTransaction() {
       CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
       data.setStartingMonday(oldDate);
       //workspace.getStartingMonday().setValue(oldDate);
       workspace.getStartingMonday().getEditor().setText(data.getStartingMonday().toString());
    }
}
