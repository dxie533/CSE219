/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class TemplateDirectoryChangeState implements jTPS_Transaction{
    private String newTemplate;
    private String oldTemplate;
    private CSGApp app;
    private CSGData data;
    
     public TemplateDirectoryChangeState(CSGApp app, String template){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        oldTemplate = data.getSiteTemplate();
        newTemplate = template;
    }
     
    @Override
    public void doTransaction() {
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        // CHANGE THE EXPORT DIRECTORY
        data.setSiteTemplate(newTemplate);
        // SET THE LABEL
        workspace.getCourseSiteTemplateDirectoryLocationLabel().setText(data.getSiteTemplate());
    }

    @Override
    public void undoTransaction() {
       CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
       // CHANGE THE EXPORT DIRECTORY
       data.setSiteTemplate(oldTemplate);
       // SET THE LABEL
       workspace.getCourseSiteTemplateDirectoryLocationLabel().setText(data.getSiteTemplate());
    }
}
