/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import java.io.File;
import java.net.MalformedURLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.image.Image;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class BannerImageChangeState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private File newBanner;
    private File oldBanner;
    
    public BannerImageChangeState(CSGApp app, File banner) {
        this.app = app;
        data = (CSGData)app.getDataComponent();
        oldBanner = new File(data.getBannerSchoolImage());
        newBanner = banner;
    }
    
    @Override
    public void doTransaction() {
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data.setBannerSchoolImage(newBanner.getAbsolutePath());
        try {
            workspace.getBannerImageView().setImage(new Image(newBanner.toURI().toURL().toExternalForm()));
        } catch (MalformedURLException ex) {
            System.out.print("malformedURL");
        }
    }

    @Override
    public void undoTransaction() {
       CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data.setBannerSchoolImage(oldBanner.getAbsolutePath());
        try {
            workspace.getBannerImageView().setImage(new Image(oldBanner.toURI().toURL().toExternalForm()));
        } catch (MalformedURLException ex) {
            System.out.print("malformedURL");
        }
    }
}
