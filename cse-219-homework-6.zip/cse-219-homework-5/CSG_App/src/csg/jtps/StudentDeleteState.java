/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class StudentDeleteState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private String firstName;
    private String lastName;
    private String role;
    private String team;
    
    public StudentDeleteState(CSGApp app, String firstNameParam, String lastNameParam){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        firstName = firstNameParam;
        lastName = lastNameParam;
        role = data.getStudent(firstName, lastName).getRole();
        team = data.getStudent(firstName, lastName).getTeam();
    }
    
    @Override
    public void doTransaction() {
        data.removeStudent(firstName,lastName);
    }

    @Override
    public void undoTransaction() {
        data.addStudent(firstName, lastName, team, role);
    }
}
