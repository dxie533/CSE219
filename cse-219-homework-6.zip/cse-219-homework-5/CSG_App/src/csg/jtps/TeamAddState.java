/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import javafx.scene.paint.Color;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class TeamAddState implements jTPS_Transaction{
    private String teamName;
    private String teamLink;
    private Color teamColor;
    private Color teamTextColor;
    private CSGApp app;
    private CSGWorkspace workspace;
    
    public TeamAddState(CSGApp app){
        this.app = app;
        workspace = (CSGWorkspace)app.getWorkspaceComponent();
        teamName = workspace.getProjectTeamNameField().getText();
        teamLink = workspace.getProjectTeamLinkField().getText();
        teamColor = workspace.getProjectTeamColorPicker().getValue();
        teamTextColor = workspace.getProjectTeamTextColorPicker().getValue();
    }
    
    @Override
    public void doTransaction() {
        ((CSGData)app.getDataComponent()).addTeam(teamName, teamColor, teamTextColor, teamLink);
    }

    @Override
    public void undoTransaction() {
        ((CSGData)app.getDataComponent()).removeTeam(teamName);
    }
}
