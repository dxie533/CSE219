/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.data.Team;
import csg.workspace.CSGWorkspace;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class StudentAddState implements jTPS_Transaction{
    private String studentFirstName;
    private String studentLastName;
    private String studentRole;
    private String studentTeam;
    private CSGApp app;
    private CSGWorkspace workspace;
    
    public StudentAddState(CSGApp app){
        this.app = app;
        workspace = (CSGWorkspace)app.getWorkspaceComponent();
        studentFirstName = workspace.getProjectStudentFirstNameField().getText();
        studentLastName = workspace.getProjectStudentLastNameField().getText();
        studentRole = workspace.getProjectStudentRoleField().getText();
        if(workspace.getProjectStudentTeamComboBox().getValue() != null)
        {
            studentTeam = workspace.getProjectStudentTeamComboBox().getValue().toString();
        }
        else
        {
            studentTeam = "";
        }
    }
    
    @Override
    public void doTransaction() {
        ((CSGData)app.getDataComponent()).addStudent(studentFirstName, studentLastName, studentTeam, studentRole);
    }

    @Override
    public void undoTransaction() {
        ((CSGData)app.getDataComponent()).removeStudent(studentFirstName, studentLastName);
    }
}
