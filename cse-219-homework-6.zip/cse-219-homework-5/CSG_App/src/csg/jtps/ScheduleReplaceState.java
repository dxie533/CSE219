/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.data.Schedule;
import csg.workspace.CSGWorkspace;
import java.time.LocalDate;
import javafx.scene.control.TableView;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class ScheduleReplaceState implements jTPS_Transaction{
    private String scheduleType;
    private LocalDate scheduleDate;
    private String scheduleTime;
    private String scheduleTitle;
    private String scheduleTopic;
    private String scheduleLink;
    private String scheduleCriteria;
    private String newType;
    private LocalDate newDate;
    private String newTime;
    private String newTitle;
    private String newTopic;
    private String newLink;
    private String newCriteria;
    private CSGApp app;
    private CSGData data;
    
    public ScheduleReplaceState(CSGApp app){
        this.app = app;
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data = (CSGData)app.getDataComponent();
        newType = workspace.getScheduleTypeComboBox().getValue().toString();
        newDate = workspace.getScheduleDateDatePicker().getValue();
        newTime = workspace.getScheduleTimeField().getText();
        newTitle = workspace.getScheduleTitleField().getText();
        newTopic = workspace.getScheduleTopicField().getText();
        newLink = workspace.getScheduleLinkField().getText();
        newCriteria = workspace.getScheduleCriteriaField().getText();
        //
        TableView schTable = workspace.getScheduleTable();
        Object selectedItem = schTable.getSelectionModel().getSelectedItem();
        Schedule sch = (Schedule)selectedItem;
        scheduleType = sch.getType();
        scheduleDate = sch.getDate();
        scheduleTime = sch.getTime();
        scheduleTitle = sch.getTitle();
        scheduleTopic = sch.getTopic();
        scheduleLink = sch.getlink();
        scheduleCriteria = sch.getCriteria();
    }
    
    @Override
    public void doTransaction() {
        Schedule selectedSchedule = data.getSchedule(scheduleType, scheduleDate);
        selectedSchedule.setType(newType);
        selectedSchedule.setDate(newDate);
        selectedSchedule.setTime(newTime);
        selectedSchedule.setTitle(newTitle);
        selectedSchedule.setTopic(newTopic);
        selectedSchedule.setLink(newLink);
        selectedSchedule.setCriteria(newCriteria);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView schTable = workspace.getScheduleTable();
        schTable.getSelectionModel().select(data.getSchedule(newType, newDate));
        schTable.refresh();
    }

    @Override
    public void undoTransaction() {
        Schedule selectedSchedule = data.getSchedule(newType, newDate);
        selectedSchedule.setType(scheduleType);
        selectedSchedule.setDate(scheduleDate);
        selectedSchedule.setTime(scheduleTime);
        selectedSchedule.setTitle(scheduleTitle);
        selectedSchedule.setTopic(scheduleTopic);
        selectedSchedule.setLink(scheduleLink);
        selectedSchedule.setCriteria(scheduleCriteria);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView schTable = workspace.getScheduleTable();
        schTable.getSelectionModel().select(data.getSchedule(scheduleType, scheduleDate));
        schTable.refresh();
    }
}
