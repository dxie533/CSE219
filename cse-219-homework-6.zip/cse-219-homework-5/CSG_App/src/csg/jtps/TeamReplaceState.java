/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.data.Team;
import csg.workspace.CSGWorkspace;
import javafx.scene.control.TableView;
import javafx.scene.paint.Color;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class TeamReplaceState implements jTPS_Transaction{
    private String teamName;
    private String teamLink;
    private Color teamColor;
    private Color teamTextColor;
    private String newName;
    private String newLink;
    private Color newColor;
    private Color newTextColor;
    private CSGApp app;
    private CSGData data;
    
    public TeamReplaceState(CSGApp app){
        this.app = app;
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data = (CSGData)app.getDataComponent();
        newName = workspace.getProjectTeamNameField().getText();
        newLink = workspace.getProjectTeamLinkField().getText();
        newColor = workspace.getProjectTeamColorPicker().getValue();
        newTextColor = workspace.getProjectTeamTextColorPicker().getValue();
        //
        TableView tmTable = workspace.getTeamTable();
        Object selectedItem = tmTable.getSelectionModel().getSelectedItem();
        Team tm = (Team)selectedItem;
        teamName = tm.getName();
        teamLink = tm.getLink();
        teamColor = tm.getColor();
        teamTextColor = tm.getTextColor();
    }
    
    @Override
    public void doTransaction() {
        Team selectedTeam = data.getTeam(teamName);
        selectedTeam.setName(newName);
        selectedTeam.setLink(newLink);
        selectedTeam.setColor(newColor);
        selectedTeam.setTextColor(newTextColor);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView tmTable = workspace.getTeamTable();
        tmTable.getSelectionModel().select(data.getTeam(newName));
        tmTable.refresh();
    }

    @Override
    public void undoTransaction() {
        Team selectedTeam = data.getTeam(newName);
        selectedTeam.setName(teamName);
        selectedTeam.setLink(teamLink);
        selectedTeam.setColor(teamColor);
        selectedTeam.setTextColor(teamTextColor);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView tmTable = workspace.getTeamTable();
        tmTable.getSelectionModel().select(data.getTeam(teamName));
        tmTable.refresh();
    }
}
