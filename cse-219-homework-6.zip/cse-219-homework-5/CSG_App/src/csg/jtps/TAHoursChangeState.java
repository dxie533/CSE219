/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.CSGProp;
import csg.data.CSGData;
import csg.file.TimeSlot;
import csg.workspace.CSGController;
import csg.workspace.CSGWorkspace;
import djf.ui.AppMessageDialogSingleton;
import java.util.ArrayList;
import javafx.scene.control.ComboBox;
import jtps.jTPS_Transaction;
import properties_manager.PropertiesManager;

/**
 *
 * @author David Xie
 */
public class TAHoursChangeState implements jTPS_Transaction{
    private CSGApp app;
    private CSGController controller;
    private int startTime;
    private int endTime;
    private boolean startTimeOnly;
    private boolean endTimeOnly;
    private int newStartTime;
    private int newEndTime;
    private boolean newStartTimeOnly;
    private boolean newEndTimeOnly;
    private ArrayList<TimeSlot> officeHoursOld;
    
    public TAHoursChangeState(CSGApp app, CSGController controller){
        this.app = app;
        this.controller = controller;
        CSGData data = (CSGData)app.getDataComponent();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        /*
        startTime = data.getStartHour();
        endTime = data.getEndHour();
        startTimeOnly = data.getStartOnlyHour();
        endTimeOnly = data.getEndOnlyHour();
        newStartTime = newStartHour;
        newEndTime = newEndHour;
        newStartTimeOnly = newStartHourOnly;
        newEndTimeOnly = newEndHourOnly;
        officeHoursOld = officeHoursOriginal;
        */
        startTime = data.getStartHour();
        endTime = data.getEndHour();
        startTimeOnly = data.getStartOnlyHour();
        endTimeOnly = data.getEndOnlyHour();
        ComboBox comboBox1 = workspace.getOfficeHour(true);
        ComboBox comboBox2 = workspace.getOfficeHour(false);
        String selectedStartText = (String)comboBox1.getValue();
        String selectedEndText = (String)comboBox2.getValue();
        newStartTime = data.getMilitaryTime(selectedStartText);
        newEndTime = data.getMilitaryTime(selectedEndText);
        newStartTimeOnly = data.getHourOnly(selectedStartText);
        newEndTimeOnly = data.getHourOnly(selectedEndText);
        officeHoursOld = TimeSlot.buildOfficeHoursList(data);
        if(controller.checkValidHours() == false)
        {
            workspace.getOfficeHour(true).getSelectionModel().select(data.getTimeString(data.getStartHour(), data.getStartOnlyHour()));
            workspace.getOfficeHour(false).getSelectionModel().select(data.getTimeString(data.getEndHour(), data.getEndOnlyHour()));
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(props.getProperty(CSGProp.START_OVER_END_TITLE.toString()), props.getProperty(CSGProp.START_OVER_END_MESSAGE.toString()));
            return;
        }
        else
        {
                comboBox1.getSelectionModel().select(data.getTimeString(data.getStartHour(), data.getStartOnlyHour()));
                comboBox2.getSelectionModel().select(data.getTimeString(data.getEndHour(), data.getEndOnlyHour()));
        }
    }

    @Override
    public void doTransaction() {
        ((CSGWorkspace)app.getWorkspaceComponent()).getOfficeHoursGridPane().getChildren().clear();
        CSGData data = (CSGData)app.getDataComponent();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        //controller.changeTimeAfter(newStartTime, newEndTime, newStartTimeOnly, newEndTimeOnly, officeHoursOld);
        //SET THE VALUE OF THE START TIME AS WELL AS THE BOOLEAN
            data.setStartHour(newStartTime);
            data.setStartOnlyHour(newStartTimeOnly);
            data.setEndHour(newEndTime);
            data.setEndOnlyHour(newEndTimeOnly);
            //CLEAR THE GRID
            workspace.getOfficeHoursGridPane().getChildren().clear();
            workspace.comboReloadWorkspace(app.getDataComponent());
            //CREATE NEW GRIDS FOR THE NEW OFFICEHOUR
            workspace.comboBoxUpdateOfficeHoursGrid(data);
            //ADD THE RESERVATIONS
            for(int i = 0; i < officeHoursOld.size(); i++)
            {
                String day = officeHoursOld.get(i).getDay();
                String time = officeHoursOld.get(i).getTime();
                String timeFormatted = time.replace("_", ":");
                String name = officeHoursOld.get(i).getName();
                //VERIFY RESERVATION
                if(controller.validateReservation(timeFormatted) == true)
                {
                    data.addOfficeHoursReservation(day, time, name);
                }
            }
            //MARK AS EDITED
            app.getGUI().getFileController().markAsEdited(app.getGUI());
            }

    @Override
    public void undoTransaction() {
        ((CSGWorkspace)app.getWorkspaceComponent()).getOfficeHoursGridPane().getChildren().clear();
        //controller.changeTimeAfter(startTime, endTime, startTimeOnly, endTimeOnly, officeHoursOld);
        ((CSGWorkspace)app.getWorkspaceComponent()).getOfficeHoursGridPane().getChildren().clear();
        CSGData data = (CSGData)app.getDataComponent();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        //controller.changeTimeAfter(newStartTime, newEndTime, newStartTimeOnly, newEndTimeOnly, officeHoursOld);
        //SET THE VALUE OF THE START TIME AS WELL AS THE BOOLEAN
            data.setStartHour(startTime);
            data.setStartOnlyHour(startTimeOnly);
            data.setEndHour(endTime);
            data.setEndOnlyHour(endTimeOnly);
            //CLEAR THE GRID
            workspace.getOfficeHoursGridPane().getChildren().clear();
            workspace.comboReloadWorkspace(app.getDataComponent());
            //CREATE NEW GRIDS FOR THE NEW OFFICEHOUR
            workspace.comboBoxUpdateOfficeHoursGrid(data);
            //ADD THE RESERVATIONS
            for(int i = 0; i < officeHoursOld.size(); i++)
            {
                String day = officeHoursOld.get(i).getDay();
                String time = officeHoursOld.get(i).getTime();
                String timeFormatted = time.replace("_", ":");
                String name = officeHoursOld.get(i).getName();
                //VERIFY RESERVATION
                if(controller.validateReservation(timeFormatted) == true)
                {
                    data.addOfficeHoursReservation(day, time, name);
                }
            }
            //MARK AS EDITED
            app.getGUI().getFileController().markAsEdited(app.getGUI());
            }
}
