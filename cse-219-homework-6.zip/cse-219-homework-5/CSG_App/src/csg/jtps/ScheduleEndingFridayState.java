/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import java.time.LocalDate;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class ScheduleEndingFridayState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private LocalDate newDate;
    private LocalDate oldDate;
    
    public ScheduleEndingFridayState(CSGApp app) {
        this.app = app;
        data = (CSGData)app.getDataComponent();
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        oldDate = data.getEndingFriday();
        newDate = workspace.getEndingFriday().getValue();
    }
    
    @Override
    public void doTransaction() {
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data.setEndingFriday(newDate);
        //workspace.getEndingFriday().setValue(newDate);
        workspace.getEndingFriday().getEditor().setText(data.getEndingFriday().toString());
    }

    @Override
    public void undoTransaction() {
       CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
       data.setEndingFriday(oldDate);
       //workspace.getEndingFriday().setValue(oldDate);
       workspace.getEndingFriday().getEditor().setText(data.getEndingFriday().toString());
    }
}
