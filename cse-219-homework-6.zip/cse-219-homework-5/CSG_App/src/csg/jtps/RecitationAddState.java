/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class RecitationAddState implements jTPS_Transaction{
    private String recitationSection;
    private String recitationInstructor;
    private String recitationTime;
    private String recitationLocation;
    private String recitationTAOne;
    private String recitationTATwo;
    private CSGApp app;
    private CSGWorkspace workspace;
    
    public RecitationAddState(CSGApp app){
        this.app = app;
        workspace = (CSGWorkspace)app.getWorkspaceComponent();
        recitationSection = workspace.getRecitationSectionField().getText();
        recitationInstructor = workspace.getRecitationInstructorField().getText();
        recitationTime = workspace.getRecitationDayTimeField().getText();
        recitationLocation = workspace.getRecitationLocationField().getText();
        if(workspace.getRecitationTA1().getValue() != null)
        {
            recitationTAOne = workspace.getRecitationTA1().getValue().toString();
        }
        else
        {
            recitationTAOne = "";
        }
        if(workspace.getRecitationTA2().getValue() != null)
        {
            recitationTATwo = workspace.getRecitationTA2().getValue().toString();
        }
        else
        {
            recitationTATwo = "";
        }
    }
    
    @Override
    public void doTransaction() {
        ((CSGData)app.getDataComponent()).addRecitation(recitationSection, recitationInstructor, recitationTime, recitationLocation, recitationTAOne, recitationTATwo);
    }

    @Override
    public void undoTransaction() {
        ((CSGData)app.getDataComponent()).removeRecitation(recitationSection);
    }
}
