/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.data.Page;
import java.util.Collections;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class SiteCheckState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private ObservableList<Page> newSites;
    private ObservableList<Page> oldSites;
    
    public SiteCheckState(CSGApp app, ObservableList<Page> sites){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        newSites = FXCollections.observableArrayList();
        oldSites = FXCollections.observableArrayList();
        for(int i = 0; i < sites.size(); i++)
        {
            newSites.add(sites.get(i));
        }
        for(int i = 0; i < sites.size(); i++)
        {
            Page newSite = new Page(sites.get(i).getTitleName(), sites.get(i).getFileName(), sites.get(i).getScriptName(), sites.get(i).isUsed());
            oldSites.add(newSite);
        }
    }
    
    public void doTransaction() {
        data.getSitePages().setAll(newSites);
        Collections.sort(data.getSitePages());
    }
    
    @Override
    public void undoTransaction() {
        data.getSitePages().setAll(oldSites);
        Collections.sort(data.getSitePages());
    }
}
