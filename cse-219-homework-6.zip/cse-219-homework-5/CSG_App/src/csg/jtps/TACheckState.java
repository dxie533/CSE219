/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.data.TeachingAssistant;
import csg.workspace.CSGWorkspace;
import java.util.Collections;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class TACheckState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private ObservableList<TeachingAssistant> newTeachingAssistants;
    private ObservableList<TeachingAssistant> oldTeachingAssistants;
    
    public TACheckState(CSGApp app, ObservableList<TeachingAssistant> teaching){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        newTeachingAssistants = FXCollections.observableArrayList();
        oldTeachingAssistants = FXCollections.observableArrayList();
        for(int i = 0; i < teaching.size(); i++)
        {
            newTeachingAssistants.add(teaching.get(i));
        }
        for(int i = 0; i < teaching.size(); i++)
        {
            TeachingAssistant newTa = new TeachingAssistant(teaching.get(i).getName(), teaching.get(i).getEmail(), teaching.get(i).isUndergraduate());
            oldTeachingAssistants.add(newTa);
        }
    }
    
    public void doTransaction() {
        data.getTeachingAssistants().setAll(newTeachingAssistants);
        Collections.sort(data.getTeachingAssistants());
    }
    
    @Override
    public void undoTransaction() {
        data.getTeachingAssistants().setAll(oldTeachingAssistants);
        Collections.sort(data.getTeachingAssistants());
    }
}
