/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.workspace.CSGWorkspace;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class TAAddState implements jTPS_Transaction{
    private String TAName;
    private String TAEmail;
    private boolean TAUndergrad;
    private CSGApp app;
    private CSGWorkspace workspace;
    
    public TAAddState(CSGApp app){
        this.app = app;
        workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TAName = workspace.getNameTextField().getText();
        TAEmail = workspace.getEmailTextField().getText();
    }

    @Override
    public void doTransaction() {
        ((CSGData)app.getDataComponent()).addTA(TAName, TAEmail, TAUndergrad);
    }

    @Override
    public void undoTransaction() {
        ((CSGData)app.getDataComponent()).removeTA(TAName);
    }
}
