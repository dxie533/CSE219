/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import java.time.LocalDate;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class ScheduleDeleteState implements jTPS_Transaction{
    private CSGApp app;
    private CSGData data;
    private String type;
    private LocalDate date;
    private String time;
    private String title;
    private String topic;
    private String link;
    private String criteria;
    
    public ScheduleDeleteState(CSGApp app, String scheduleType, LocalDate scheduleDate){
        this.app = app;
        data = (CSGData)app.getDataComponent();
        type = scheduleType;
        date = scheduleDate;
        time = data.getSchedule(type, date).getTime();
        title = data.getSchedule(type, date).getTitle();
        topic = data.getSchedule(type, date).getTopic();
        link = data.getSchedule(type, date).getlink();
        criteria = data.getSchedule(type, date).getCriteria();
    }
    
    @Override
    public void doTransaction() {
        data.removeSchedule(date, type);
    }

    @Override
    public void undoTransaction() {
        data.addSchedule(type, date, time, title, topic, link, criteria);
    }
}
