/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.jtps;

import csg.CSGApp;
import csg.data.CSGData;
import csg.data.Recitation;
import csg.workspace.CSGWorkspace;
import javafx.scene.control.TableView;
import jtps.jTPS_Transaction;

/**
 *
 * @author David Xie
 */
public class RecitationReplaceState implements jTPS_Transaction{
    private String RecitationSection;
    private String RecitationInstructor;
    private String RecitationTime;
    private String RecitationLocation;
    private String RecitationTAOne;
    private String RecitationTATwo;
    private String newSection;
    private String newInstructor;
    private String newTime;
    private String newLocation;
    private String newTAOne;
    private String newTATwo;
    private CSGApp app;
    private CSGData data;
    
    public RecitationReplaceState(CSGApp app){
        this.app = app;
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        data = (CSGData)app.getDataComponent();
        newSection = workspace.getRecitationSectionField().getText();
        newInstructor = workspace.getRecitationInstructorField().getText();
        newTime = workspace.getRecitationDayTimeField().getText();
        newLocation = workspace.getRecitationLocationField().getText();
        if(workspace.getRecitationTA1().getValue() != null)
        {
            newTAOne = workspace.getRecitationTA1().getValue().toString();
        }
        else
        {
            newTAOne = "";
        }
        if(workspace.getRecitationTA2().getValue() != null)
        {
            newTATwo = workspace.getRecitationTA2().getValue().toString();
        }
        else
        {
            newTATwo = "";
        }
        TableView recTable = workspace.getRecitationTable();
        Object selectedItem = recTable.getSelectionModel().getSelectedItem();
        Recitation rec = (Recitation)selectedItem;
        RecitationSection = rec.getSection();
        RecitationInstructor = rec.getInstructor();
        RecitationTime = rec.getDayAndTime();
        RecitationLocation = rec.getLocation();
        RecitationTAOne = rec.getTaOne();
        RecitationTATwo = rec.getTaTwo();
    }
    
    @Override
    public void doTransaction() {
        Recitation selectedRecitation = data.getRecitation(RecitationSection);
        selectedRecitation.setSection(newSection);
        selectedRecitation.setInstructor(newInstructor);
        selectedRecitation.setDayAndTime(newTime);
        selectedRecitation.setLocation(newLocation);
        selectedRecitation.setTAOne(newTAOne);
        selectedRecitation.setTATwo(newTATwo);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView recTable = workspace.getRecitationTable();
        recTable.getSelectionModel().select(data.getRecitation(newSection));
        recTable.refresh();
    }

    @Override
    public void undoTransaction() {
        Recitation selectedRecitation = data.getRecitation(newSection);
        selectedRecitation.setSection(RecitationSection);
        selectedRecitation.setInstructor(RecitationInstructor);
        selectedRecitation.setDayAndTime(RecitationTime);
        selectedRecitation.setLocation(RecitationLocation);
        selectedRecitation.setTAOne(RecitationTAOne);
        selectedRecitation.setTATwo(RecitationTATwo);
        CSGWorkspace workspace = (CSGWorkspace)app.getWorkspaceComponent();
        TableView recTable = workspace.getRecitationTable();
        recTable.getSelectionModel().select(data.getRecitation(RecitationSection));
        recTable.refresh();
    }
}
